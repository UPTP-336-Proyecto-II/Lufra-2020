<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion</title>
    <link rel="stylesheet" href="assets/css/styleLogin.css">
</head>
<body>
    <a id="btn-back-home-top" href="index.php" class="btn-back-top" aria-label="Volver al Inicio">Volver al Inicio</a>
    <div class="bg-animate" aria-hidden="true"></div>

    <main class="login-wrapper" role="main">
        <!-- Columna izquierda: imagen/ilustración decorativa -->
        <aside class="hero" aria-hidden="false" role="img" aria-label="Imagen decorativa">
            
            <img src="assets/img/lufra.jpg" alt="Ilustración decorativa - Lufra">
        </aside>

        <div class="form-column">
        <section class="login-card" aria-labelledby="loginTitle">
            <h1 id="loginTitle">Bienvenido</h1>
       <!-- <p class="demo-note">Usuario demo: <strong>admin</strong> / <strong>admin</strong></p> -->

            <form id="loginForm" class="form" novalidate>
                <div class="field">
                    <label for="username">Usuario</label>
                    <div class="input-row">
                        <input type="text" id="username" name="username" required autocomplete="username" />
                    </div>
                </div>

                <div class="field">
                    <label for="password">Contraseña</label>
                    <div class="input-row">
                        <input type="password" id="password" name="password" required autocomplete="current-password" />
                        <button type="button" class="toggle-pass" aria-label="Mostrar contraseña">👁️</button>
                    </div>
                    <ul class="pw-criteria" id="pwCriteria" aria-live="polite">
                        <li data-rule="length">Al menos 8 caracteres</li>
                        <li data-rule="lower">Al menos una letra minúscula</li>
                        <li data-rule="upper">Al menos una letra mayúscula</li>
                        <li data-rule="number">Al menos un número</li>
                        <li data-rule="special">Al menos un carácter especial (!@#$%^&*)</li>
                    </ul>
                </div>

                <div class="actions">
                    <button class="btn primary" type="submit">
                        <span class="btn-text">Ingresar</span>
                        <span class="spinner" aria-hidden="true"></span>
                    </button>
                </div>
            </form>

            <div id="message" role="status" aria-live="polite"></div>



            <div class="success" id="successCard" aria-hidden="true" style="display:none;">
                <div class="check">✓</div>
                <h2>Inicio de sesión exitoso</h2>
                <p>Redirigiendo...</p>
            </div>
        </section>

    <script src="assets/js/ScriptLogin.js" defer></script>

</body>
</html>
