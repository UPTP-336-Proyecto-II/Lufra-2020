// --- Autenticación basada en sesión del servidor ---
let sessionUser = null;
async function checkSessionAsync(){
    try{
        const res = await fetch('./includes/auth/check_session.php', { credentials: 'same-origin', cache: 'no-store' });
        if(!res.ok) return null;
        const json = await res.json();
        return json;
    }catch(e){
        return null;
    }
}
function logout(){
    // Logout explícito por parte del usuario: no mostrar "sesión expirada" en la página de login
    fetch('./includes/auth/logout.php', { method: 'POST', credentials: 'same-origin' })
        .finally(()=> window.location.replace('Login.php'));
}

// --- 1. Definición de Módulos por Rol ---
const roleModules = {
    "SuperUsuario": {
        name: "SuperUsuario",
        description: "Acceso total para mantenimiento y configuración del sistema.",
        modules: [
            "Gestión de Usuarios y Roles"
        ]
    },
    "Administrativo": {
        name: "Administrativo",
        description: "Módulos principales para el proceso de cálculo y gestión de la nómina.",
        modules: [
            "Registro de Trabajadores",
            "Pago de Nómina",
            "Tipo de Nomina",
            "gestion de conceptos",
            "gestion de Cargos"

        ]
    },
    "Trabajador": {
        name: "Trabajador",
        description: "Módulos de autoservicio para la consulta de información personal.",
        modules: [
            "Mi Perfil",
            "Historial de Pagos y Recibos",
            "Solicitud de Vacaciones"
        ]
    }
};

// Nota: el mismo script se carga en `login.html` y en `Index.html`.
// Detectamos la página por la presencia de elementos y actuamos en consecuencia.

function initPayrollPage(){
    const sidebarNav = document.getElementById('module-navigation');
    const contentHeader = document.getElementById('content-header');
    const contentDetails = document.getElementById('content-details');
    const roleTabs = document.querySelectorAll('.role-tab');

    // Event listeners para las pestañas de rol (se ejecutan dentro de initPayrollPage para tener acceso a loadRoleView)
    if(roleTabs && roleTabs.length){
        roleTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                const role = this.getAttribute('data-role');
                loadRoleView(role);
            });
        });
    }

    function loadRoleView(roleName) {
        // Normalize role name and try to match case-insensitively if exact key is not present
        const desiredRole = (roleName || '').toString().trim();
        let roleData = roleModules[desiredRole] || roleModules[Object.keys(roleModules).find(k => k.toLowerCase() === desiredRole.toLowerCase())];
        if(!roleData){
            console.warn('Rol no reconocido:', roleName, ' - mostrando vista por defecto (Administrativo)');
            roleData = roleModules['Administrativo'];
        }

        // guardar rol actual (usar la clave real encontrada)
        currentRole = Object.keys(roleModules).find(k => roleModules[k] === roleData) || 'Administrativo';

        // 1. Actualizar la barra lateral (Módulos) y agregar handlers
        if(sidebarNav) sidebarNav.innerHTML = '';
        roleData.modules.forEach((moduleName, index) => {
            const link = document.createElement('a');
            link.href = "#";
            link.className = "nav-link";
            link.textContent = moduleName;
            if (index === 0) link.classList.add('active');
            link.addEventListener('click', (e) => {
                e.preventDefault();
                // marcar activo
                sidebarNav.querySelectorAll('.nav-link').forEach(n => n.classList.remove('active'));
                link.classList.add('active');
                renderModule(moduleName);
            });
            if(sidebarNav) sidebarNav.appendChild(link);
        });

        // 2. Actualizar el contenido principal resumen
        if(contentHeader) contentHeader.innerHTML = `<h4>Rol Actual: ${roleData.name}</h4>`;
        if(contentDetails) contentDetails.innerHTML = `
            <p>${roleData.description}</p>
            <p><strong>Funcionalidades visibles en el menú:</strong></p>
            <ul class="module-list">
                ${roleData.modules.map(m => `<li>${m}</li>`).join('')}
            </ul>
            <p class="alert-info">
                <strong>Resumen:</strong> El usuario **${roleData.name}** solo tiene acceso a las funcionalidades listadas arriba y no puede ver los módulos de otros roles.
            </p>
        `;

        // 3. Activar la pestaña correcta (visual)
        if(roleTabs) roleTabs.forEach(tab => {
            tab.classList.remove('active');
            if (tab.getAttribute('data-role') === roleName) tab.classList.add('active');
        });

        // renderizar primer módulo por defecto
        if(roleData.modules && roleData.modules.length) renderModule(roleData.modules[0]);
    }

    // Exponer la función globalmente para evitar errores si se invoca desde fuera (compatibilidad)
    window.loadRoleView = loadRoleView;

    // --- variables y helpers para módulos ---
    let currentRole = 'Administrativo';

    function renderModule(moduleName){
        const role = currentRole;
        if(contentHeader) contentHeader.innerHTML = `<h4>${role} - ${moduleName}</h4>`;
        if(role === 'Administrativo') return renderAdminModule(moduleName);
        if(role === 'Trabajador') return renderWorkerModule(moduleName);
        if(role === 'SuperUsuario') return renderSuperModule(moduleName);
        if(contentDetails) contentDetails.innerHTML = `<p>Módulo no implementado.</p>`;
    }

    /* Helpers comunes */
    // Empleados ahora se gestionan en backend (settings.php key: payroll_employees)
    function getEmployees(){ return []; }
    function saveEmployees(list){ /* use settings.php via UI */ }

    // --- Implementaciones Administrativo ---
    function renderAdminModule(name){
        if(!contentDetails) return;
        
        // Registro de Trabajadores
        if(name.toLowerCase().includes('registro') && name.toLowerCase().includes('trabajador')){
            renderWorkerRegistration();
            return;
        }
        
        // Pago de Nómina
        if(name.toLowerCase().includes('pago') && name.toLowerCase().includes('nómina')){
            renderPayrollPayment();
            return;
        }

        // Tipo de Nomina
        if(name.toLowerCase().includes('tipo') && name.toLowerCase().includes('nomina')){
            renderTipoNominaModule();
            return;
        }
        
        if(name.toLowerCase().includes('cálcul') || name.toLowerCase().includes('calcul')){
            contentDetails.innerHTML = `
                <div>
                    <h4>Calculadora de Nómina</h4>
                    <label>Salario bruto: <input id="pay-gross" type="number" value="1000"/></label>
                    <label>Impuesto %: <input id="pay-tax" type="number" value="10"/></label>
                    <button id="calc-pay" class="primary">Calcular</button>
                    <div id="pay-result" style="margin-top:10px"></div>
                </div>`;
            document.getElementById('calc-pay').addEventListener('click', ()=>{
                const gross = Number(document.getElementById('pay-gross').value)||0;
                const tax = Number(document.getElementById('pay-tax').value)||0;
                const net = gross * (1 - tax/100);
                document.getElementById('pay-result').textContent = `Salario neto: $${net.toFixed(2)}`;
            });
            return;
        }
        if(name.toLowerCase().includes('emplead')){
            // Gestión simple de empleados guardada en settings.php (key: payroll_employees)
            contentDetails.innerHTML = `<div><h4>Gestión de Empleados</h4><button id="add-emp" class="primary">Agregar</button><div id="emp-list" style="margin-top:12px"></div></div>`;
            const listEl = document.getElementById('emp-list');
            async function loadEmployees(){ try{ const r = await fetch('./includes/settings.php?key=payroll_employees', { cache: 'no-store' }); if(!r.ok) return []; const txt = await r.text(); try{ return JSON.parse(txt) || []; }catch(e){ return []; } }catch(e){ return []; } }
            async function saveEmployeesToServer(list){ try{ await fetch('./includes/settings.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ key: 'payroll_employees', value: list }) }); }catch(e){ /* ignore */ } }
            async function refresh(){ const a = await loadEmployees(); if(!a || a.length===0){ listEl.innerHTML = '<p>No hay empleados.</p>'; return; } listEl.innerHTML = `<table><thead><tr><th>ID</th><th>Nombre</th><th>Cargo</th><th></th></tr></thead><tbody>${a.map((e,i)=>`<tr><td>${i+1}</td><td>${e.name}</td><td>${e.role||''}</td><td><button data-i="${i}" class="del-emp">Eliminar</button></td></tr>`).join('')}</tbody></table>`; listEl.querySelectorAll('.del-emp').forEach(b=> b.addEventListener('click', async ()=>{ const idx = Number(b.getAttribute('data-i')); const arr = await loadEmployees(); arr.splice(idx,1); await saveEmployeesToServer(arr); refresh(); })); }
            document.getElementById('add-emp').addEventListener('click', async ()=>{ const name = prompt('Nombre'); if(!name) return; const role = prompt('Cargo')||''; const arr = await loadEmployees(); arr.push({name,role}); await saveEmployeesToServer(arr); refresh(); });
            refresh();
            return;
        }
        if(name.toLowerCase().includes('novedad')){
            contentDetails.innerHTML = `<div><h4>Registro de Novedades</h4><label>Empleado: <input id="n-emp"/></label><label>Tipo: <input id="n-type"/></label><label>Monto: <input id="n-amt" type="number"/></label><button id="n-save" class="primary">Guardar</button><div id="n-list" style="margin-top:12px"></div></div>`;
            // Novedades ahora en backend
            async function loadNovedades(){
                try{
                    const res = await fetch('./includes/reports/novedades.php', { cache: 'no-store' });
                    if(!res.ok) return [];
                    return await res.json();
                }catch(e){ return []; }
            }
            document.getElementById('n-save').addEventListener('click', async ()=>{
                const emp=document.getElementById('n-emp').value.trim();
                const type=document.getElementById('n-type').value.trim();
                const amt=Number(document.getElementById('n-amt').value)||0;
                if(!emp||!type) return alert('Empleado y tipo requeridos');
                try{
                    const r = await fetch('./includes/reports/novedades.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ emp, tipo: type, amt }) });
                    if(!r.ok) throw new Error('Error al guardar');
                    renderNovedades();
                }catch(e){ alert('Error al guardar la novedad'); }
            });
            async function renderNovedades(){
                const arr = await loadNovedades();
                document.getElementById('n-list').innerHTML = arr.length? arr.map(n=>`<div>${n.fecha} - ${n.emp} - ${n.tipo} - $${n.monto}</div>`).join('') : '<p>No hay novedades.</p>';
            }
            renderNovedades();
            return;
        }
        if(name.toLowerCase().includes('reporte')){
            contentDetails.innerHTML = `<div><h4>Generar Reportes</h4><button id="gen-rep" class="primary">Generar CSV</button></div>`;
            document.getElementById('gen-rep').addEventListener('click', async ()=>{
                const emps = await loadWorkersFromServer();
                const nov = await loadNovedades();
                let csv='id,name,role\n';
                emps.forEach((e,i)=> csv += `${i+1},"${e.Nombre_Completo|| (e.name||'')}","${e.Nombre_rol|| (e.role||'') }"\n`);
                csv += '\nNOVEDADES\ndate,emp,type,amt\n';
                nov.forEach(n=> csv += `${n.fecha},"${n.emp}","${n.tipo}",${n.monto}\n`);
                const blob=new Blob([csv],{type:'text/csv'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='reporte.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
            });
            return;
        }
        if(name.toLowerCase().includes('concept')){
            renderConceptosModule();
            return;
        }
        if(name.toLowerCase().includes('cargo')){
            renderCargosModule();
            return;
        }
        contentDetails.innerHTML = `<p>Módulo '${name}' no implementado (Administrativo).</p>`;
    }

    // --- Funciones para Trabajadores ---
    function getWorkers() { return []; }

    function saveWorkers(workers) { /* workers are persisted via backend endpoints (add_worker/update_worker) */ }

    // --- Funciones para Registro de Trabajadores ---
    function renderWorkerRegistration() {
        if (!contentDetails) return;

        // New: fetch server-side options and workers
        let cargos = [];
        let niveles = [];
        let tiposNomina = [];

        async function loadOptions() {
            try {
                const [cRes, nRes, tRes] = await Promise.all([
                    fetch('./includes/nomina/list_cargos.php'),
                    fetch('./includes/users/list_niveles.php'),
                    fetch('./includes/nomina/list_tipo_nomina.php')
                ]);
                const [cData, nData, tData] = await Promise.all([cRes.json().catch(()=>({})), nRes.json().catch(()=>({})), tRes.json().catch(()=>({}))]);
                cargos = cData.cargos || [];
                niveles = nData.niveles || [];
                tiposNomina = tData.tipos || [];
            } catch (e) {
                // keep arrays empty as fallback
                cargos = [];
                niveles = [];
                tiposNomina = [];
            }
        }

        async function loadWorkersFromServer() {
            try {
                const res = await fetch('./includes/workers/list_workers.php', { cache: 'no-store' });
                const data = await res.json();
                if (res.ok && data.workers) return data.workers;
                return [];
            } catch (e) {
                return [];
            }
        }

        function buildFormHTML() {
            return `
            <div class="worker-registration">
                <h4>Registro de Trabajadores</h4>
                <div style="margin-bottom: 20px;">
                    <button id="add-worker-btn" class="primary">➕ Registrar Nuevo Trabajador</button>
                </div>
                <div id="worker-form-container" style="display: none; background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h5>Datos del Trabajador</h5>
                    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:10px;">
                        <div class="form-row"><label class="form-label">Nombres <span class="required">*</span></label><input id="w-nombre" class="form-input" type="text" /></div>
                        <div class="form-row"><label class="form-label">Apellidos <span class="required">*</span></label><input id="w-apellidos" class="form-input" type="text" /></div>

                        <div class="form-row"><label class="form-label">Documento de identidad <span class="required">*</span></label>
                            <div style="display:flex;gap:5px;align-items:center;">
                                <select id="w-cedula-prefijo" style="padding:8px;border:1px solid #ddd;border-radius:4px;background:#fff;width:60px;">
                                    <option value="V">V-</option>
                                    <option value="E">E-</option>
                                </select>
                                <input id="w-cedula" class="form-input" type="text" placeholder="12345678" style="flex:1;" />
                            </div>
                        </div>
                        <div class="form-row"><label class="form-label">Fecha de nacimiento</label><input id="w-fecha-nac" class="form-input" type="date" max="" /></div>

                        <div class="form-row"><label class="form-label">Género</label><select id="w-genero" class="form-input"><option value="">Seleccione</option><option value="M">M</option><option value="F">F</option><option value="O">Otro</option></select></div>
                        <div class="form-row"><label class="form-label">Cargo <span class="required">*</span></label><select id="w-cargo" class="form-input"><option value="">Cargo (seleccione)</option>${cargos.map(c=>`<option value="${c.Id_Cargo}">${c.Nombre_profesión}</option>`).join('')}</select></div>

                        <div class="form-row"><label class="form-label">Nivel educativo <span class="required">*</span></label><select id="w-nivel" class="form-input"><option value="">Nivel educativo (seleccione)</option>${niveles.map(n=>`<option value="${n.Id_Nivel_Educativo}">${n.Nombre_Nivel}</option>`).join('')}</select></div>
                        <div class="form-row"><label class="form-label">Correo electrónico</label><input id="w-correo" class="form-input" type="email" /></div>

                        <div class="form-row"><label class="form-label">Teléfono móvil</label><input id="w-telefono" class="form-input" type="text" placeholder="0412-1234567" /></div>
                        <div class="form-row"><label class="form-label">Dirección</label><input id="w-direccion" class="form-input" type="text" /></div>

                        <div class="form-row"><label class="form-label">Estado civil</label>
                            <select id="w-estado-civil" class="form-input">
                                <option value="">Seleccione</option>
                                <option value="Soltero">Soltero</option>
                                <option value="Casado">Casado</option>
                                <option value="Divorciado">Divorciado</option>
                                <option value="Viudo">Viudo</option>
                                <option value="Unión Libre">Unión Libre</option>
                            </select>
                        </div>
                        <div class="form-row"><label class="form-label">Ingreso anterior</label><input id="w-ingreso-anterior" class="form-input" type="text" placeholder="(Opcional)" /></div>

                        <div class="form-row" style="grid-column:1/3"><label class="form-label">Fecha de ingreso <span class="required">*</span></label><input id="w-fecha-ingreso" class="form-input" type="date" /></div>
                    </div>

                    <h5>Contrato</h5>
                    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:10px;">
                        <div class="form-row"><label class="form-label">Tipo de nómina <span class="required">*</span></label><select id="w-tipo-nomina" class="form-input"><option value="">Tipo de nómina</option>${tiposNomina.map(t=>`<option value="${t.Id_Tipo_Nomina}">${t.Frecuencia}</option>`).join('')}</select></div>
                        <div class="form-row"><label class="form-label">Estado</label><select id="w-estado" class="form-input"><option value="Activo">Activo</option><option value="Inactivo">Inactivo</option></select></div>
                        <div class="form-row" style="grid-column:1/3"><label class="form-label">Observaciones</label><textarea id="w-observaciones" class="form-input" placeholder="Observaciones"></textarea></div>
                    </div>

                    <div style="display:flex;gap:10px;margin-top:8px;align-items:center;">
                        <button id="save-worker-btn" class="primary">💾 Guardar Trabajador</button>
                        <button id="cancel-worker-btn" style="padding: 10px 20px; border-radius: 5px; border: 1px solid #ddd; background: #fff; cursor: pointer;">Cancelar</button>
                        <div id="worker-msg"></div>
                    </div>
                </div>
                <div id="workers-list"><h5 style="margin-top:20px">Trabajadores Registrados</h5><div id="workers-table"></div></div>
            </div>
            `;
        }

        // Funciones de validación para trabajadores
        function validarSoloLetrasTrabajador(texto) {
            if (!texto) return false;
            const regex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s\-\']+$/;
            return regex.test(texto);
        }

        function validarSoloNumerosTrabajador(valor) {
            if (!valor || valor === '') return false;
            // Permite números y guiones (para formato de teléfono)
            const regex = /^[0-9\-\s]+$/;
            return regex.test(valor);
        }

        function validarCedula(cedula) {
            if (!cedula) return false;
            // Solo números, entre 6 y 10 dígitos
            const regex = /^[0-9]{6,10}$/;
            return regex.test(cedula);
        }

        function validarFecha(fecha, tipo) {
            if (!fecha) return { valido: true }; // Fechas opcionales son válidas
            
            // Parsear fecha input (YYYY-MM-DD) a fecha local para evitar problemas de zona horaria
            const partes = fecha.split('-');
            const fechaObj = new Date(partes[0], partes[1] - 1, partes[2]);
            
            const hoy = new Date();
            hoy.setHours(0, 0, 0, 0);
            
            if (tipo === 'nacimiento') {
                // Fecha de nacimiento no puede ser futura
                if (fechaObj > hoy) {
                    return { valido: false, mensaje: 'La fecha de nacimiento no puede ser futura' };
                }
                // Validar mayoría de edad (18 años)
                const fechaMayorEdad = new Date();
                fechaMayorEdad.setHours(0,0,0,0);
                fechaMayorEdad.setFullYear(hoy.getFullYear() - 18);
                
                if (fechaObj > fechaMayorEdad) {
                    return { valido: false, mensaje: 'El trabajador debe ser mayor de edad (18 años)' };
                }

                // No puede ser mayor a 120 años
                const edadMaxima = new Date();
                edadMaxima.setFullYear(edadMaxima.getFullYear() - 120);
                if (fechaObj < edadMaxima) {
                    return { valido: false, mensaje: 'La fecha de nacimiento no es válida' };
                }
            } else if (tipo === 'ingreso') {
                // Fecha de ingreso no puede ser futura (o puede ser hoy)
                if (fechaObj > hoy) {
                    return { valido: false, mensaje: 'La fecha de ingreso no puede ser futura' };
                }
            }
            
            return { valido: true };
        }

        function setupWorkerFormValidations() {
            // Validación en tiempo real para nombres (solo letras)
            const nombreInput = document.getElementById('w-nombre');
            const apellidosInput = document.getElementById('w-apellidos');
            
            [nombreInput, apellidosInput].forEach(input => {
                if (input && !input.dataset.validacionConfigurada) {
                    input.dataset.validacionConfigurada = 'true';
                    input.addEventListener('keypress', function(e) {
                        const char = String.fromCharCode(e.which);
                        if (!/[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s\-\']/.test(char) && !e.ctrlKey && !e.metaKey && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') {
                            e.preventDefault();
                        }
                    });
                }
            });

            // Validación para cédula (solo números)
            const cedulaInput = document.getElementById('w-cedula');
            if (cedulaInput && !cedulaInput.dataset.validacionConfigurada) {
                cedulaInput.dataset.validacionConfigurada = 'true';
                cedulaInput.addEventListener('keypress', function(e) {
                    const char = String.fromCharCode(e.which);
                    if (!/[0-9]/.test(char) && !e.ctrlKey && !e.metaKey && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') {
                        e.preventDefault();
                    }
                });
            }

            // Validación para teléfono (números, guiones y espacios)
            const telefonoInput = document.getElementById('w-telefono');
            if (telefonoInput && !telefonoInput.dataset.validacionConfigurada) {
                telefonoInput.dataset.validacionConfigurada = 'true';
                telefonoInput.addEventListener('keypress', function(e) {
                    const char = String.fromCharCode(e.which);
                    if (!/[0-9\-\s]/.test(char) && !e.ctrlKey && !e.metaKey && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') {
                        e.preventDefault();
                    }
                });
            }
        }

        // cache for current workers to allow viewing details
        let workersCache = [];

        function renderWorkersTable(workers) {
            workersCache = workers || [];
            const el = document.getElementById('workers-table');
            if(!el) return;
            if(!workers.length) { el.innerHTML = '<p style="color:#7f8c8d;padding:12px">No hay trabajadores registrados.</p>'; return; }
            el.innerHTML = `<table style="width:100%;border-collapse:collapse"><thead><tr style="background:#3498db;color:#fff"><th style="padding:8px">ID</th><th style="padding:8px">Nombre</th><th style="padding:8px">Cédula</th><th style="padding:8px">Cargo</th><th style="padding:8px">Nivel</th><th style="padding:8px">Ingreso</th><th style="padding:8px">Estado</th><th style="padding:8px">Acciones</th></tr></thead><tbody>${workers.map(w=>`<tr><td style="padding:8px">${w.Id_Trabajador}</td><td style="padding:8px">${w.Nombre_Completo} ${w.Apellidos}</td><td style="padding:8px">${w.Documento_Identidad}</td><td style="padding:8px">${w.Cargo||''}</td><td style="padding:8px">${w.Nivel_Educativo||''}</td><td style="padding:8px">${new Date(w.Fecha_de_Ingreso).toLocaleDateString('es-VE')}</td><td style="padding:8px"><span style="background:${w.Contrato_Estado==='Activo'?'#2ecc71':'#e74c3c'};color:#fff;padding:2px 8px;border-radius:10px;font-size:0.85em;">${w.Contrato_Estado||''}</span></td><td style="padding:8px"><button class="view-worker-btn" data-id="${w.Id_Trabajador}" style="background:#3498db;color:#fff;border:none;padding:6px 8px;border-radius:4px;cursor:pointer;margin-right:6px">Ver</button>
                            ${w.Contrato_Estado==='Activo'
                                ? `<button class="deactivate-worker-btn" data-id="${w.Id_Trabajador}" data-name="${w.Nombre_Completo} ${w.Apellidos}" style="background:#f39c12;color:#fff;border:none;padding:6px 8px;border-radius:4px;cursor:pointer">Desactivar</button>`
                                : `<button class="activate-worker-btn" data-id="${w.Id_Trabajador}" data-name="${w.Nombre_Completo} ${w.Apellidos}" style="background:#2ecc71;color:#fff;border:none;padding:6px 8px;border-radius:4px;cursor:pointer">Activar</button>`
                            }</td></tr>`).join('')}</tbody></table>`;
            attachWorkerTableListeners();
        }

        function attachWorkerTableListeners(){
            document.querySelectorAll('.deactivate-worker-btn').forEach(b=>{
                b.addEventListener('click', async ()=>{
                    const id = b.getAttribute('data-id');
                    const nombre = b.getAttribute('data-name');
                    if(!confirm(`¿Está seguro de desactivar al trabajador "${nombre}"?\n\nEl trabajador será marcado como inactivo pero no se eliminará de la base de datos.`)) return;
                    try{
                        const res = await fetch('./includes/auth/deactivate_worker.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id }) });
                        const data = await res.json();
                        if(res.ok){ document.getElementById('worker-msg').textContent = 'Trabajador desactivado exitosamente'; document.getElementById('worker-msg').style.color = '#27ae60'; loadAndRender(); if(window.loadWorkersForUsers) window.loadWorkersForUsers(); } else { document.getElementById('worker-msg').textContent = data.error || 'Error al desactivar'; document.getElementById('worker-msg').style.color = '#e74c3c'; }
                    }catch(e){ document.getElementById('worker-msg').textContent = 'Error de conexión'; document.getElementById('worker-msg').style.color = '#e74c3c'; }
                });
            });

            document.querySelectorAll('.activate-worker-btn').forEach(b=>{
                b.addEventListener('click', async ()=>{
                    const id = b.getAttribute('data-id');
                    const nombre = b.getAttribute('data-name');
                    if(!confirm(`¿Está seguro de activar al trabajador "${nombre}"?`)) return;
                    try{
                        const res = await fetch('./includes/workers/activate_worker.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id }) });
                        const data = await res.json();
                        if(res.ok){ document.getElementById('worker-msg').textContent = 'Trabajador activado exitosamente'; document.getElementById('worker-msg').style.color = '#27ae60'; loadAndRender(); if(window.loadWorkersForUsers) window.loadWorkersForUsers(); } else { document.getElementById('worker-msg').textContent = data.error || 'Error al activar'; document.getElementById('worker-msg').style.color = '#e74c3c'; }
                    }catch(e){ document.getElementById('worker-msg').textContent = 'Error de conexión'; document.getElementById('worker-msg').style.color = '#e74c3c'; }
                });
            });

            document.querySelectorAll('.view-worker-btn').forEach(b=>{
                b.addEventListener('click', ()=>{
                    const id = b.getAttribute('data-id');
                    const worker = workersCache.find(w => String(w.Id_Trabajador) === String(id));
                    if(worker) showWorkerDetails(worker);
                });
            });
        }

        function genderLabel(g){
            if(!g) return '-';
            if(g === 'M') return 'Masculino';
            if(g === 'F') return 'Femenino';
            if(g === 'O') return 'Otro';
            return g;
        }

        function showWorkerDetails(worker){
            // create overlay
            const overlay = document.createElement('div');
            overlay.className = 'modal-overlay';
            overlay.innerHTML = `
                <div class="modal-content">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                        <h4 style="margin:0">Detalle Trabajador</h4>
                        <button class="modal-close" aria-label="Cerrar">✖</button>
                    </div>
                    <div class="detail-list">
                        <div class="detail-row"><strong>ID:</strong> ${worker.Id_Trabajador}</div>
                        <div class="detail-row"><strong>Nombre:</strong> ${worker.Nombre_Completo} ${worker.Apellidos}</div>
                        <div class="detail-row"><strong>Documento:</strong> ${worker.Documento_Identidad}</div>
                        <div class="detail-row"><strong>Correo:</strong> ${worker.Correo || '-'}</div>
                        <div class="detail-row"><strong>Teléfono:</strong> ${worker.Telefono_Movil || '-'}</div>
                        <div class="detail-row"><strong>Dirección:</strong> ${worker.Direccion || '-'}</div>
                        <div class="detail-row"><strong>Fecha Nacimiento:</strong> ${worker.Fecha_Nacimiento ? new Date(worker.Fecha_Nacimiento).toLocaleDateString('es-VE') : '-'}</div>
                        <div class="detail-row"><strong>Género:</strong> ${genderLabel(worker.Genero)}</div>
                        <div class="detail-row"><strong>Estado Civil:</strong> ${worker.Estado_Civil || '-'}</div>
                        <div class="detail-row"><strong>Fecha Ingreso:</strong> ${worker.Fecha_de_Ingreso ? new Date(worker.Fecha_de_Ingreso).toLocaleDateString('es-VE') : '-'}</div>
                        <div class="detail-row"><strong>Cargo:</strong> ${worker.Cargo || '-'}</div>
                        <div class="detail-row"><strong>Nivel Educativo:</strong> ${worker.Nivel_Educativo || '-'}</div>
                        <hr />
                        <div class="detail-row"><strong>Contrato ID:</strong> ${worker.Id_registro || '-'}</div>
                        <div class="detail-row"><strong>Tipo Nómina:</strong> ${worker.Frecuencia || '-'}</div>
                        <div class="detail-row"><strong>Fecha Registro Contrato:</strong> ${worker.Fecha_registro ? new Date(worker.Fecha_registro).toLocaleString('es-VE') : '-'}</div>
                        <div class="detail-row"><strong>Estado Contrato:</strong> ${worker.Contrato_Estado || '-'}</div>
                        <div class="detail-row"><strong>Observaciones:</strong> ${worker.Observaciones || '-'}</div>
                    </div>
                </div>
            `;

            document.body.appendChild(overlay);

            const closeBtn = overlay.querySelector('.modal-close');
            function removeModal(){ overlay.remove(); }
            closeBtn.addEventListener('click', removeModal);
            overlay.addEventListener('click', (e)=>{ if(e.target === overlay) removeModal(); });
        }

        function setWorkerMsg(m, type='info'){ const el = document.getElementById('worker-msg'); if(!el) return; el.textContent = m; el.style.color = type==='error' ? '#e74c3c' : type==='success' ? '#27ae60' : '#7f8c8d'; }
        async function loadAndRender(){
            await loadOptions();
            contentDetails.innerHTML = buildFormHTML();

            // hookup buttons
            const addBtn = document.getElementById('add-worker-btn');
            const formContainer = document.getElementById('worker-form-container');
            const saveBtn = document.getElementById('save-worker-btn');
            const cancelBtn = document.getElementById('cancel-worker-btn');

            addBtn.addEventListener('click', ()=>{ 
                formContainer.style.display = formContainer.style.display==='none' ? 'block' : 'none'; 
                setWorkerMsg('');
                // remove validation highlights on open
                ['w-nombre','w-apellidos','w-cedula','w-fecha-ingreso','w-cargo','w-nivel','w-tipo-nomina','w-telefono','w-fecha-nac'].forEach(id=>{ const el=document.getElementById(id); if(el) el.classList.remove('input-error'); });
                
                // Configurar fecha máxima para fecha de nacimiento (18 años atrás)
                const fechaNacInput = document.getElementById('w-fecha-nac');
                if (fechaNacInput) {
                    const hoy = new Date();
                    const maxEdad = new Date(hoy.getFullYear() - 18, hoy.getMonth(), hoy.getDate());
                    const m = String(maxEdad.getMonth() + 1).padStart(2, '0');
                    const d = String(maxEdad.getDate()).padStart(2, '0');
                    fechaNacInput.setAttribute('max', `${maxEdad.getFullYear()}-${m}-${d}`);
                }

                // Configurar fecha máxima para fecha de ingreso (hoy)
                const fechaIngresoInput = document.getElementById('w-fecha-ingreso');
                if (fechaIngresoInput) {
                    const hoy = new Date();
                    const m = String(hoy.getMonth() + 1).padStart(2, '0');
                    const d = String(hoy.getDate()).padStart(2, '0');
                    fechaIngresoInput.setAttribute('max', `${hoy.getFullYear()}-${m}-${d}`);
                }
                
                // Configurar validaciones en tiempo real
                setupWorkerFormValidations();
            });
            cancelBtn.addEventListener('click', ()=>{ formContainer.style.display='none'; setWorkerMsg(''); });

            saveBtn.addEventListener('click', async ()=>{
                setWorkerMsg('Guardando...');

                // clear previous errors
                ['w-nombre','w-apellidos','w-cedula','w-fecha-ingreso','w-cargo','w-nivel','w-tipo-nomina','w-telefono','w-fecha-nac'].forEach(id=>{ const el=document.getElementById(id); if(el) el.classList.remove('input-error'); });

                // Obtener valores
                const nombre = document.getElementById('w-nombre').value.trim();
                const apellidos = document.getElementById('w-apellidos').value.trim();
                const cedulaPrefijo = document.getElementById('w-cedula-prefijo').value;
                const cedula = document.getElementById('w-cedula').value.trim();
                const fechaNac = document.getElementById('w-fecha-nac').value;
                const fechaIngreso = document.getElementById('w-fecha-ingreso').value;
                const telefono = document.getElementById('w-telefono').value.trim();

                // Validaciones
                let errores = [];

                // Validar nombres (solo letras)
                if (!nombre) {
                    errores.push({ campo: 'w-nombre', mensaje: 'El nombre es obligatorio' });
                } else if (!validarSoloLetrasTrabajador(nombre)) {
                    errores.push({ campo: 'w-nombre', mensaje: 'El nombre solo puede contener letras, espacios y acentos' });
                } else if (nombre.length < 2) {
                    errores.push({ campo: 'w-nombre', mensaje: 'El nombre debe tener al menos 2 caracteres' });
                }

                // Validar apellidos (solo letras)
                if (!apellidos) {
                    errores.push({ campo: 'w-apellidos', mensaje: 'Los apellidos son obligatorios' });
                } else if (!validarSoloLetrasTrabajador(apellidos)) {
                    errores.push({ campo: 'w-apellidos', mensaje: 'Los apellidos solo pueden contener letras, espacios y acentos' });
                } else if (apellidos.length < 2) {
                    errores.push({ campo: 'w-apellidos', mensaje: 'Los apellidos deben tener al menos 2 caracteres' });
                }

                // Validar cédula (solo números)
                if (!cedula) {
                    errores.push({ campo: 'w-cedula', mensaje: 'La cédula es obligatoria' });
                } else if (!validarCedula(cedula)) {
                    errores.push({ campo: 'w-cedula', mensaje: 'La cédula debe contener solo números (entre 6 y 10 dígitos)' });
                }

                // Validar teléfono (si se proporciona)
                if (telefono && !validarSoloNumerosTrabajador(telefono)) {
                    errores.push({ campo: 'w-telefono', mensaje: 'El teléfono solo puede contener números, guiones y espacios' });
                }

                // Validar fechas
                if (fechaNac) {
                    const validacionNac = validarFecha(fechaNac, 'nacimiento');
                    if (!validacionNac.valido) {
                        errores.push({ campo: 'w-fecha-nac', mensaje: validacionNac.mensaje });
                    }
                }

                if (!fechaIngreso) {
                    errores.push({ campo: 'w-fecha-ingreso', mensaje: 'La fecha de ingreso es obligatoria' });
                } else {
                    const validacionIngreso = validarFecha(fechaIngreso, 'ingreso');
                    if (!validacionIngreso.valido) {
                        errores.push({ campo: 'w-fecha-ingreso', mensaje: validacionIngreso.mensaje });
                    }
                }

                // Validar campos select obligatorios
                const cargo = parseInt(document.getElementById('w-cargo').value) || null;
                const nivel = parseInt(document.getElementById('w-nivel').value) || null;
                const tipoNomina = parseInt(document.getElementById('w-tipo-nomina').value) || null;

                if (!cargo) errores.push({ campo: 'w-cargo', mensaje: 'Debe seleccionar un cargo' });
                if (!nivel) errores.push({ campo: 'w-nivel', mensaje: 'Debe seleccionar un nivel educativo' });
                if (!tipoNomina) errores.push({ campo: 'w-tipo-nomina', mensaje: 'Debe seleccionar un tipo de nómina' });

                // Mostrar errores
                if (errores.length > 0) {
                    errores.forEach(err => {
                        const el = document.getElementById(err.campo);
                        if (el) el.classList.add('input-error');
                    });
                    setWorkerMsg(errores[0].mensaje, 'error');
                    return;
                }

                // Construir payload con cédula completa (prefijo + número)
                const documentoCompleto = `${cedulaPrefijo}-${cedula}`;

                const payload = {
                    Id_Cargo: cargo,
                    Id_Nivel_Educativo: nivel,
                    Nombre_Completo: nombre,
                    Apellidos: apellidos,
                    Fecha_Nacimiento: fechaNac || null,
                    Genero: document.getElementById('w-genero').value || null,
                    Documento_Identidad: documentoCompleto,
                    Correo: document.getElementById('w-correo').value.trim() || null,
                    Telefono_Movil: telefono || null,
                    Direccion: document.getElementById('w-direccion').value.trim() || null,
                    Estado_Civil: document.getElementById('w-estado-civil').value || null,
                    Ingreso_Anterior: document.getElementById('w-ingreso-anterior').value.trim() || null,
                    Fecha_de_Ingreso: fechaIngreso,
                    Id_Tipo_Nomina: tipoNomina,
                    Observaciones: document.getElementById('w-observaciones').value.trim() || null,
                    Estado: document.getElementById('w-estado').value || 'Activo'
                };

                try{
                    const res = await fetch('./includes/workers/add_worker.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
                    const data = await res.json();
                    if(res.ok){ setWorkerMsg('Trabajador registrado', 'success'); formContainer.style.display='none'; loadAndRender(); if(window.loadWorkersForUsers) window.loadWorkersForUsers(); } else { setWorkerMsg(data.error || 'Error al guardar', 'error'); }
                }catch(e){ setWorkerMsg('Error de conexión', 'error'); }
            });

            // initial workers load
            const workers = await loadWorkersFromServer();
            renderWorkersTable(workers);

            // remove error highlight when user edits fields
            ['w-nombre','w-apellidos','w-cedula','w-fecha-ingreso','w-cargo','w-nivel','w-tipo-nomina','w-correo','w-telefono','w-direccion'].forEach(id=>{ const el=document.getElementById(id); if(el) el.addEventListener('input', ()=> el.classList.remove('input-error')); });
        }

        loadAndRender();
    }

    // --- Funciones para Pago de Nómina ---
    async function renderPayrollPayment() {
        if (!contentDetails) return;

        // State for the module
        let workers = [];
        let allConcepts = [];
        let addedConcepts = [];

        // --- Helper function to fetch concepts ---
        async function fetchConceptos() {
            try {
                const res = await fetch('./includes/nomina/list_conceptos.php', { cache: 'no-store' });
                if (!res.ok) return [];
                const data = await res.json();
                return data.conceptos || [];
            } catch (e) {
                console.error("Error fetching conceptos:", e);
                return [];
            }
        }

        // --- Load initial data (workers and concepts) ---
        try {
            const res = await fetch('./includes/workers/list_workers.php', { cache: 'no-store' });
            if (res.ok) {
                const data = await res.json();
                if (data.workers && data.workers.length) {
                    workers = data.workers.map(w => ({
                        id: w.Id_Trabajador,
                        nombres: w.Nombre_Completo,
                        apellidos: w.Apellidos,
                        cedula: w.Documento_Identidad
                    }));
                }
            }
        } catch (e) { /* ignore and keep workers empty */ }

        allConcepts = await fetchConceptos();

        // --- Main HTML structure ---
        if (workers.length === 0) {
            contentDetails.innerHTML = `
                <div class="payroll-payment">
                    <h4>Pago de Nómina</h4>
                    <div class="alert-info">
                        <p>⚠️ No hay trabajadores registrados. Por favor, registre trabajadores primero en el módulo "Registro de Trabajadores".</p>
                    </div>
                </div>
            `;
            return;
        }
        
        let html = `
            <div class="payroll-payment">
                <h4>Pago de Nómina</h4>
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h5>Datos del Pago</h5>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div>
                            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Trabajador *</label>
                            <select id="payment-worker" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" required>
                                <option value="">Seleccione un trabajador</option>
                                ${workers.map(w => `<option value="${w.id}" data-cedula="${w.cedula}" data-nombres="${w.nombres}" data-apellidos="${w.apellidos}">${w.cedula} - ${w.nombres} ${w.apellidos}</option>`).join('')}
                            </select>
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Período *</label>
                            <input type="text" id="payment-periodo" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" placeholder="Ej: Enero 2024" required>
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div>
                            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Fecha de Pago *</label>
                            <input type="date" id="payment-fecha-pago" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" required>
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Fecha Inicio Período</label>
                            <input type="date" id="payment-fecha-inicio" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Fecha Fin Período</label>
                            <input type="date" id="payment-fecha-fin" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        </div>
                    </div>
                    <div style="background: #fff; padding: 15px; border-radius: 4px; margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600;">Salario Base (Bs.)</label>
                        <input type="number" id="payment-salario-base" value="130" step="0.01" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" required>
                    </div>

                    <div id="conceptos-section" style="margin-top: 20px;">
                        <h5>Conceptos del Recibo</h5>
                        <div style="display: flex; gap: 10px; margin-bottom: 15px; align-items: center; background: #f1f1f1; padding: 10px; border-radius: 6px;">
                            <select id="add-concepto-select" style="flex-grow: 1; padding: 8px;">
                                <option value="">Seleccionar concepto...</option>
                                ${allConcepts.map(c => `<option value="${c.Id_Concepto}">${c.Nombre_Concepto} (${c.Tipo} - Bs. ${c.Monto || '0.00'})</option>`).join('')}
                            </select>
                            <button id="add-concepto-btn" class="primary" style="padding: 8px 12px;">+ Agregar</button>
                        </div>

                        <div id="conceptos-list-container" style="background: #fff; padding: 15px; border-radius: 4px; min-height: 50px; border: 1px solid #eee;">
                            <p id="no-concepts-msg" style="color: #95a5a6; text-align: center;">No hay conceptos agregados aún</p>
                            <div id="added-concepts-list"></div>
                        </div>

                        <div id="payslip-totals" style="margin-top: 20px; padding-top: 15px; border-top: 2px solid #eee; text-align: right; font-size: 1.1em;">
                            <div>Salario Base: <strong id="total-base">Bs. 0,00</strong></div>
                            <div>Total Asignaciones: <strong id="total-asignaciones" style="color: #27ae60;">+ Bs. 0,00</strong></div>
                            <div>Total Deducciones: <strong id="total-deducciones" style="color: #e74c3c;">- Bs. 0,00</strong></div>
                            <hr style="border: none; border-top: 1px solid #eee; margin: 10px 0;">
                            <div>Neto a Pagar: <strong id="total-neto" style="font-size: 1.2em;">Bs. 0,00</strong></div>
                        </div>
                    </div>

                    <div style="margin-top: 20px; display: flex; gap: 10px;">
                        <button id="generate-payslip-btn" class="primary">💾 Generar Recibo de Pago</button>
                    </div>
                </div>
            </div>
        `;
        contentDetails.innerHTML = html;

        // --- DOM Elements ---
        const salarioBaseInput = document.getElementById('payment-salario-base');
        const addConceptoBtn = document.getElementById('add-concepto-btn');
        const addConceptoSelect = document.getElementById('add-concepto-select');

        // --- Rendering and Update functions ---
        const formatCurrencyLocal = (amount) => `Bs. ${parseFloat(amount || 0).toFixed(2).replace('.', ',')}`;

        function renderAddedConcepts() {
            const container = document.getElementById('added-concepts-list');
            const noConceptsMsg = document.getElementById('no-concepts-msg');
            if (addedConcepts.length === 0) {
                container.innerHTML = '';
                noConceptsMsg.style.display = 'block';
            } else {
                noConceptsMsg.style.display = 'none';
                container.innerHTML = addedConcepts.map((c, index) => `
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px; border-bottom: 1px solid #f0f0f0;">
                        <div>
                            <strong>${c.Nombre_Concepto}</strong>
                            <span style="font-size: 0.9em; color: #777; margin-left: 10px;">(${c.Tipo})</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <strong style="color: ${c.Tipo === 'Deducción' ? '#e74c3c' : '#27ae60'};">${formatCurrencyLocal(c.Monto)}</strong>
                            <button class="remove-concepto-btn" data-index="${index}" style="background: #e74c3c; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer;">X</button>
                        </div>
                    </div>
                `).join('');
            }
            updateTotals();
            attachRemoveConceptListeners();
        }

        function updateTotals() {
            const salarioBase = parseFloat(salarioBaseInput.value) || 0;
            let totalAsignaciones = 0;
            let totalDeducciones = 0;
            
            addedConcepts.forEach(c => {
                const monto = parseFloat(c.Monto) || 0;
                if (c.Tipo === 'Asignación' || c.Tipo === 'Bonificación') {
                    totalAsignaciones += monto;
                } else if (c.Tipo === 'Deducción') {
                    totalDeducciones += monto;
                }
            });

            const neto = salarioBase + totalAsignaciones - totalDeducciones;

            document.getElementById('total-base').textContent = formatCurrencyLocal(salarioBase);
            document.getElementById('total-asignaciones').textContent = `+ ${formatCurrencyLocal(totalAsignaciones)}`;
            document.getElementById('total-deducciones').textContent = `- ${formatCurrencyLocal(totalDeducciones)}`;
            document.getElementById('total-neto').textContent = formatCurrencyLocal(neto);
        }

        // --- Event Listeners ---
        function attachRemoveConceptListeners() {
            document.querySelectorAll('.remove-concepto-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const index = parseInt(e.target.getAttribute('data-index'));
                    addedConcepts.splice(index, 1);
                    renderAddedConcepts();
                });
            });
        }

        salarioBaseInput.addEventListener('input', updateTotals);

        addConceptoBtn.addEventListener('click', () => {
            const conceptId = addConceptoSelect.value;
            if (!conceptId) return;

            const alreadyAdded = addedConcepts.some(c => c.Id_Concepto == conceptId);
            if (alreadyAdded) {
                alert('Este concepto ya ha sido agregado.');
                return;
            }

            const conceptToAdd = allConcepts.find(c => c.Id_Concepto == conceptId);
            if (conceptToAdd) {
                addedConcepts.push(conceptToAdd);
                renderAddedConcepts();
            }
        });

        document.getElementById('generate-payslip-btn').addEventListener('click', async () => {
            const workerSelect = document.getElementById('payment-worker');
            if (!workerSelect.value) { alert('Por favor, seleccione un trabajador.'); return; }
            const periodo = document.getElementById('payment-periodo').value.trim();
            const fechaPago = document.getElementById('payment-fecha-pago').value;
            if (!periodo || !fechaPago) { alert('Por favor, complete los campos requeridos (Período y Fecha de Pago).'); return; }

            const salarioBase = parseFloat(salarioBaseInput.value) || 0;
            let totalAsignaciones = 0;
            let totalBonificaciones = 0;
            let totalDeducciones = 0;
            
            addedConcepts.forEach(c => {
                const monto = parseFloat(c.Monto) || 0;
                if (c.Tipo === 'Asignación') totalAsignaciones += monto;
                if (c.Tipo === 'Bonificación') totalBonificaciones += monto;
                if (c.Tipo === 'Deducción') totalDeducciones += monto;
            });
            const neto = salarioBase + totalAsignaciones + totalBonificaciones - totalDeducciones;
            const workerId = parseInt(workerSelect.value);
            const worker = workers.find(w => w.id === workerId);

            const newPayslip = {
                periodo: periodo,
                fechaPago: fechaPago,
                fechaInicio: document.getElementById('payment-fecha-inicio').value || fechaPago,
                fechaFin: document.getElementById('payment-fecha-fin').value || fechaPago,
                salarioBase: salarioBase,
                asignaciones: totalAsignaciones,
                bonificaciones: totalBonificaciones,
                deducciones: totalDeducciones,
                neto: neto,
                tipoNomina: 'Quincenal', // This might need to be dynamic
                trabajadorId: worker.id || null,
                trabajador: `${worker.nombres} ${worker.apellidos}`,
                cedula: worker.cedula,
                numeroRecibo: null,
                conceptos: addedConcepts
            };

            try {
                const r = await fetch('./includes/reports/payslips.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'same-origin',
                    body: JSON.stringify({ data: newPayslip })
                });
                if (!r.ok) {
                    const errorText = await r.text();
                    throw new Error(`Error al crear recibo: ${errorText}`);
                }
                const res = await r.json();
                
                alert(`Recibo de pago generado exitosamente para ${worker.nombres} ${worker.apellidos}.\nID del Recibo: ${res.id}`);
                
                workerSelect.value = '';
                document.getElementById('payment-periodo').value = '';
                document.getElementById('payment-fecha-pago').value = '';
                salarioBaseInput.value = '130';
                addedConcepts = [];
                renderAddedConcepts();

            } catch (err) {
                console.error(err);
                alert(err.message);
            }
        });
        
        renderAddedConcepts();
    }

    // --- Funciones para Tipo de Nómina ---
    function renderTipoNominaModule() {
        if (!contentDetails) return;
        
        contentDetails.innerHTML = `
            <div class="tipo-nomina-module">
                <h4>Gestión de Tipos de Nómina</h4>
                <div style="margin-bottom: 20px;">
                    <button id="btn-add-nomina" class="primary">➕ Nuevo Tipo de Nómina</button>
                </div>

                <!-- Formulario de creación (oculto por defecto) -->
                <div id="form-nomina-container" style="display:none; background:#f8f9fa; padding:20px; border-radius:8px; margin-bottom:20px; border:1px solid #e9ecef;">
                    <h5 style="margin-top:0;">Nuevo Tipo de Nómina</h5>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px;">
                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:5px; color:#34495e;">Frecuencia *</label>
                            <input type="text" id="tn-frecuencia" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;" placeholder="Ej: Semanal, Quincenal, Mensual">
                        </div>
                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:5px; color:#34495e;">Fecha Inicio (Referencia)</label>
                            <input type="date" id="tn-inicio" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;">
                        </div>
                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:5px; color:#34495e;">Fecha Fin (Referencia)</label>
                            <input type="date" id="tn-fin" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;">
                        </div>
                    </div>
                    <div style="display:flex; gap:10px;">
                        <button id="btn-save-nomina" class="primary">Guardar</button>
                        <button id="btn-cancel-nomina" style="background:#fff; border:1px solid #ccc; padding:8px 15px; border-radius:5px; cursor:pointer;">Cancelar</button>
                    </div>
                </div>

                <!-- Lista de Tipos de Nómina -->
                <div id="lista-nominas-container">
                    <p>Cargando tipos de nómina...</p>
                </div>

                <!-- Vista de Trabajadores por Nómina -->
                <div id="workers-nomina-view" style="display:none; margin-top:30px; border-top:2px solid #eee; padding-top:20px;">
                    <h4 id="workers-nomina-title" style="color:#2c3e50;">Trabajadores</h4>
                    <div id="workers-nomina-list"></div>
                </div>
            </div>
        `;

        // Event Listeners
        document.getElementById('btn-add-nomina').addEventListener('click', () => {
            document.getElementById('form-nomina-container').style.display = 'block';
            document.getElementById('tn-frecuencia').focus();
        });

        document.getElementById('btn-cancel-nomina').addEventListener('click', () => {
            document.getElementById('form-nomina-container').style.display = 'none';
            document.getElementById('tn-frecuencia').value = '';
            document.getElementById('tn-inicio').value = '';
            document.getElementById('tn-fin').value = '';
        });

        document.getElementById('btn-save-nomina').addEventListener('click', async () => {
            const freq = document.getElementById('tn-frecuencia').value.trim();
            const ini = document.getElementById('tn-inicio').value;
            const fin = document.getElementById('tn-fin').value;

            if(!freq) { 
                alert('La frecuencia es obligatoria'); 
                return; 
            }

            // Validar que la frecuencia solo contenga letras
            if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s]+$/.test(freq)) {
                alert('La frecuencia solo puede contener letras y espacios');
                return;
            }

            // Validar fechas si se proporcionan
            if (ini && fin) {
                const fechaInicio = new Date(ini);
                const fechaFin = new Date(fin);
                
                if (fechaFin < fechaInicio) {
                    alert('La fecha de fin no puede ser anterior a la fecha de inicio');
                    return;
                }
            }

            try {
                const res = await fetch('./includes/reports/create_tipo_nomina.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ Frecuencia: freq, Fecha_Inicio: ini, Fecha_Fin: fin })
                });
                const data = await res.json();
                if(res.ok) {
                    alert('Tipo de nómina creado exitosamente');
                    document.getElementById('form-nomina-container').style.display = 'none';
                    document.getElementById('tn-frecuencia').value = '';
                    loadNominas(); // Recargar lista
                } else {
                    alert(data.error || 'Error al crear el tipo de nómina');
                }
            } catch(e) { alert('Error de conexión al guardar'); }
        });

        // Cargar datos iniciales
        loadNominas();
    }

    async function loadNominas() {
        const container = document.getElementById('lista-nominas-container');
        try {
            const res = await fetch('./includes/nomina/list_tipo_nomina.php');
            const data = await res.json();
            const tipos = data.tipos || [];

            if(tipos.length === 0) {
                container.innerHTML = '<div class="alert-info">No hay tipos de nómina registrados.</div>';
                return;
            }

            let html = `
                <table style="width:100%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 5px rgba(0,0,0,0.05);">
                    <thead>
                        <tr style="background:#3498db; color:#fff;">
                            <th style="padding:12px; text-align:left;">ID</th>
                            <th style="padding:12px; text-align:left;">Frecuencia</th>
                            <th style="padding:12px; text-align:left;">Vigencia</th>
                            <th style="padding:12px; text-align:left;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            tipos.forEach(t => {
                const hasInicio = t.Fecha_Inicio && t.Fecha_Inicio !== '0000-00-00';
                const hasFin = t.Fecha_Fin && t.Fecha_Fin !== '0000-00-00';
                const vigencia = (hasInicio && hasFin)
                    ? `${new Date(t.Fecha_Inicio).toLocaleDateString()} - ${new Date(t.Fecha_Fin).toLocaleDateString()}`
                    : (hasInicio ? `${new Date(t.Fecha_Inicio).toLocaleDateString()} - Indefinida` : 'Indefinida');
                html += `
                    <tr style="border-bottom:1px solid #f0f0f0;">
                        <td style="padding:12px;">${t.Id_Tipo_Nomina}</td>
                        <td style="padding:12px;"><strong>${t.Frecuencia}</strong></td>
                        <td style="padding:12px; color:#7f8c8d;">${vigencia}</td>
                        <td style="padding:12px;">
                            <button class="btn-view-workers-nomina" data-id="${t.Id_Tipo_Nomina}" data-name="${t.Frecuencia}" style="background:#2ecc71; color:#fff; border:none; padding:8px 12px; border-radius:4px; cursor:pointer; font-weight:600;">
                                👥 Ver Trabajadores
                            </button>
                        </td>
                    </tr>
                `;
            });

            html += '</tbody></table>';
            container.innerHTML = html;

            // Listeners para botones de ver trabajadores
            container.querySelectorAll('.btn-view-workers-nomina').forEach(btn => {
                btn.addEventListener('click', () => {
                    showWorkersForNomina(btn.getAttribute('data-id'), btn.getAttribute('data-name'));
                });
            });

        } catch(e) {
            container.innerHTML = '<p style="color:red">Error cargando la lista de nóminas.</p>';
        }
    }

    async function showWorkersForNomina(id, name) {
        const view = document.getElementById('workers-nomina-view');
        const title = document.getElementById('workers-nomina-title');
        const list = document.getElementById('workers-nomina-list');

        view.style.display = 'block';
        title.textContent = `Trabajadores asignados a Nómina: ${name}`;
        list.innerHTML = '<p>Cargando trabajadores...</p>';
        view.scrollIntoView({ behavior: 'smooth' });

        try {
            // Reutilizamos list_workers.php que devuelve todos los trabajadores y filtramos en cliente
            const res = await fetch('./includes/workers/list_workers.php');
            const data = await res.json();
            const workers = data.workers || [];
            // Filtrar por Id_Tipo_Nomina
            const filtered = workers.filter(w => String(w.Id_Tipo_Nomina) === String(id));

            if(filtered.length === 0) {
                list.innerHTML = '<div class="alert-info">No hay trabajadores asignados a este tipo de nómina actualmente.</div>';
                return;
            }

            let html = `<table style="width:100%; border-collapse:collapse; margin-top:10px; background:#fff; border-radius:6px; overflow:hidden;">
                <thead>
                    <tr style="background:#ecf0f1; color:#2c3e50;">
                        <th style="padding:10px; text-align:left;">Nombre Completo</th>
                        <th style="padding:10px; text-align:left;">Cédula</th>
                        <th style="padding:10px; text-align:left;">Cargo</th>
                        <th style="padding:10px; text-align:left;">Estado</th>
                    </tr>
                </thead>
                <tbody>`;
            
            filtered.forEach(w => {
                html += `
                    <tr style="border-bottom:1px solid #eee;">
                        <td style="padding:10px;">${w.Nombre_Completo} ${w.Apellidos}</td>
                        <td style="padding:10px;">${w.Documento_Identidad}</td>
                        <td style="padding:10px;">${w.Cargo || '-'}</td>
                        <td style="padding:10px;"><span style="background:${w.Contrato_Estado === 'Activo' ? '#d4edda' : '#f8d7da'}; color:${w.Contrato_Estado === 'Activo' ? '#155724' : '#721c24'}; padding:2px 8px; border-radius:10px; font-size:0.85em;">${w.Contrato_Estado || 'N/A'}</span></td>
                    </tr>
                `;
            });
            html += '</tbody></table>';
            list.innerHTML = html;

        } catch(e) {
            list.innerHTML = '<p style="color:red">Error al cargar los trabajadores.</p>';
        }
    }

    // --- Funciones para Gestión de Conceptos ---
    function renderConceptosModule() {
        if (!contentDetails) return;
        
        contentDetails.innerHTML = `
            <div class="conceptos-module">
                <h4>Gestión de Conceptos de Nómina</h4>
                <div style="margin-bottom: 20px;">
                    <button id="btn-add-concepto" class="primary">➕ Nuevo Concepto</button>
                </div>

                <!-- Formulario de creación (oculto por defecto) -->
                <div id="form-concepto-container" style="display:none; background:#f8f9fa; padding:20px; border-radius:8px; margin-bottom:20px; border:1px solid #e9ecef;">
                    <h5 style="margin-top:0;">Nuevo Concepto de Nómina</h5>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px;">
                        <div style="grid-column:1/3;">
                            <label style="display:block; font-weight:600; margin-bottom:5px; color:#34495e;">Nombre del Concepto <span style="color:#e74c3c;">*</span></label>
                            <input type="text" id="c-nombre" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;" placeholder="Ej: Salario Base, Bono de Alimentación, Seguro Social">
                        </div>
                        <div style="grid-column:1/3;">
                            <label style="display:block; font-weight:600; margin-bottom:5px; color:#34495e;">Descripción</label>
                            <textarea id="c-descripcion" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px; min-height:80px;" placeholder="Descripción detallada del concepto"></textarea>
                        </div>
                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:5px; color:#34495e;">Tipo de Concepto <span style="color:#e74c3c;">*</span></label>
                            <select id="c-tipo" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;">
                                <option value="">Seleccione un tipo</option>
                                <option value="Asignación">Asignación</option>
                                <option value="Deducción">Deducción</option>
                                <option value="Bonificación">Bonificación</option>
                                <option value="Sin tipo">Sin tipo (solo concepto base)</option>
                            </select>
                        </div>
                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:5px; color:#34495e;">Monto (Bs.)</label>
                            <input type="number" id="c-monto" step="0.01" min="0" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;" placeholder="0.00">
                        </div>
                        <div style="grid-column:1/3;">
                            <label style="display:block; font-weight:600; margin-bottom:5px; color:#34495e;">Observaciones (para Bonificaciones)</label>
                            <textarea id="c-observaciones" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px; min-height:60px;" placeholder="Observaciones adicionales (opcional)"></textarea>
                        </div>
                    </div>
                    <div style="display:flex; gap:10px;">
                        <button id="btn-save-concepto" class="primary">💾 Guardar Concepto</button>
                        <button id="btn-cancel-concepto" style="background:#fff; border:1px solid #ccc; padding:8px 15px; border-radius:5px; cursor:pointer;">Cancelar</button>
                    </div>
                    <div id="concepto-msg" style="margin-top:10px;"></div>
                </div>

                <!-- Lista de Conceptos -->
                <div id="lista-conceptos-container">
                    <p>Cargando conceptos...</p>
                </div>
            </div>
        `;

        // Funciones de validación (definidas antes de usarse)
        function validarSoloLetras(texto) {
            // Permite letras, espacios, acentos, ñ, guiones y apóstrofes
            const regex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s\-\']+$/;
            return regex.test(texto);
        }

        function validarSoloNumeros(valor) {
            if (!valor || valor === '') {
                return false;
            }
            // Permite números enteros y decimales (con punto o coma)
            const regex = /^[0-9]+([.,][0-9]+)?$/;
            return regex.test(valor.toString().replace('.', ','));
        }

        // Configurar validación en tiempo real (una sola vez)
        function setupValidacionTiempoReal() {
            // Validación en tiempo real para el campo nombre (solo letras)
            const nombreInput = document.getElementById('c-nombre');
            if (nombreInput && !nombreInput.dataset.validacionConfigurada) {
                nombreInput.dataset.validacionConfigurada = 'true';
                
                nombreInput.addEventListener('input', function(e) {
                    const valor = e.target.value;
                    // Si contiene números o caracteres especiales no permitidos, mostrar advertencia
                    if (valor && !validarSoloLetras(valor)) {
                        e.target.style.borderColor = '#f39c12'; // Amarillo para advertencia
                    } else {
                        e.target.style.borderColor = '#ddd'; // Normal
                    }
                });

                // Prevenir entrada de números y caracteres especiales
                nombreInput.addEventListener('keypress', function(e) {
                    const char = String.fromCharCode(e.which);
                    // Permitir letras, espacios, acentos, guiones, apóstrofes y teclas de control
                    if (!/[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s\-\']/.test(char) && !e.ctrlKey && !e.metaKey && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') {
                        e.preventDefault();
                        const msgEl = document.getElementById('concepto-msg');
                        msgEl.textContent = 'El nombre solo puede contener letras, espacios y acentos';
                        msgEl.style.color = '#f39c12';
                        setTimeout(() => {
                            if (msgEl.textContent.includes('solo puede contener letras')) {
                                msgEl.textContent = '';
                            }
                        }, 3000);
                    }
                });
            }

            // Validación en tiempo real para el campo monto (solo números)
            const montoInput = document.getElementById('c-monto');
            if (montoInput && !montoInput.dataset.validacionConfigurada) {
                montoInput.dataset.validacionConfigurada = 'true';
                
                montoInput.addEventListener('input', function(e) {
                    const valor = e.target.value;
                    // Si contiene letras o caracteres especiales no permitidos, mostrar advertencia
                    if (valor && !validarSoloNumeros(valor)) {
                        e.target.style.borderColor = '#f39c12'; // Amarillo para advertencia
                    } else {
                        e.target.style.borderColor = '#ddd'; // Normal
                    }
                });

                // Prevenir entrada de letras y caracteres especiales (excepto punto y coma para decimales)
                montoInput.addEventListener('keypress', function(e) {
                    const char = String.fromCharCode(e.which);
                    const valorActual = e.target.value;
                    // Permitir números, un solo punto o coma decimal, y teclas de control
                    if (!/[0-9.,]/.test(char) && !e.ctrlKey && !e.metaKey && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') {
                        e.preventDefault();
                        const msgEl = document.getElementById('concepto-msg');
                        msgEl.textContent = 'El monto solo puede contener números y un punto o coma decimal';
                        msgEl.style.color = '#f39c12';
                        setTimeout(() => {
                            if (msgEl.textContent.includes('solo puede contener números')) {
                                msgEl.textContent = '';
                            }
                        }, 3000);
                    }
                    
                    // Prevenir múltiples puntos o comas
                    if ((char === '.' || char === ',') && (valorActual.includes('.') || valorActual.includes(','))) {
                        e.preventDefault();
                    }
                });
            }
        }

        // Event Listeners
        document.getElementById('btn-add-concepto').addEventListener('click', () => {
            document.getElementById('form-concepto-container').style.display = 'block';
            document.getElementById('c-nombre').focus();
            document.getElementById('concepto-msg').textContent = '';
            // Limpiar formulario
            document.getElementById('c-nombre').value = '';
            document.getElementById('c-descripcion').value = '';
            document.getElementById('c-tipo').value = '';
            document.getElementById('c-monto').value = '';
            document.getElementById('c-observaciones').value = '';
            
            // Limpiar estilos de error
            ['c-nombre', 'c-monto', 'c-tipo'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.style.borderColor = '#ddd';
            });

            // Configurar validación en tiempo real después de mostrar el formulario
            setTimeout(() => {
                setupValidacionTiempoReal();
            }, 100);
        });

        document.getElementById('btn-cancel-concepto').addEventListener('click', () => {
            document.getElementById('form-concepto-container').style.display = 'none';
            document.getElementById('concepto-msg').textContent = '';
        });

        document.getElementById('btn-save-concepto').addEventListener('click', async () => {
            const nombre = document.getElementById('c-nombre').value.trim();
            const descripcion = document.getElementById('c-descripcion').value.trim();
            const tipo = document.getElementById('c-tipo').value;
            const montoInput = document.getElementById('c-monto').value.trim();
            const observaciones = document.getElementById('c-observaciones').value.trim();

            const msgEl = document.getElementById('concepto-msg');
            
            // Limpiar errores visuales previos
            ['c-nombre', 'c-monto', 'c-tipo'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.style.borderColor = '#ddd';
            });

            // Validación: Nombre obligatorio
            if (!nombre) {
                msgEl.textContent = 'El nombre del concepto es obligatorio';
                msgEl.style.color = '#e74c3c';
                document.getElementById('c-nombre').style.borderColor = '#e74c3c';
                return;
            }

            // Validación: Si hay monto, se requiere un tipo
            if (montoInput && (tipo === '' || tipo === 'Sin tipo')) {
                msgEl.textContent = 'Debe seleccionar un Tipo (Asignación, Deducción o Bonificación) si ingresa un Monto.';
                msgEl.style.color = '#e74c3c';
                document.getElementById('c-tipo').style.borderColor = '#e74c3c';
                return;
            }

            // Validación: Nombre solo letras
            if (!validarSoloLetras(nombre)) {
                msgEl.textContent = 'El nombre del concepto solo puede contener letras, espacios y acentos. No se permiten números ni caracteres especiales.';
                msgEl.style.color = '#e74c3c';
                document.getElementById('c-nombre').style.borderColor = '#e74c3c';
                return;
            }

            // Validación: Longitud del nombre
            if (nombre.length < 3) {
                msgEl.textContent = 'El nombre del concepto debe tener al menos 3 caracteres';
                msgEl.style.color = '#e74c3c';
                document.getElementById('c-nombre').style.borderColor = '#e74c3c';
                return;
            }

            if (nombre.length > 100) {
                msgEl.textContent = 'El nombre del concepto no puede exceder 100 caracteres';
                msgEl.style.color = '#e74c3c';
                document.getElementById('c-nombre').style.borderColor = '#e74c3c';
                return;
            }

            // Validación: Monto requerido si hay tipo
            if (tipo && tipo !== 'Sin tipo' && !montoInput) {
                msgEl.textContent = 'El monto es requerido cuando se especifica un tipo';
                msgEl.style.color = '#e74c3c';
                document.getElementById('c-monto').style.borderColor = '#e74c3c';
                return;
            }

            // Validación: Monto solo números (si se proporciona)
            let monto = null;
            if (montoInput) {
                if (!validarSoloNumeros(montoInput)) {
                    msgEl.textContent = 'El monto solo puede contener números y un punto o coma decimal. No se permiten letras ni otros caracteres especiales.';
                    msgEl.style.color = '#e74c3c';
                    document.getElementById('c-monto').style.borderColor = '#e74c3c';
                    return;
                }
                
                // Convertir a número (acepta punto o coma como separador decimal)
                monto = parseFloat(montoInput.replace(',', '.'));
                
                // Validar que el monto sea positivo
                if (monto < 0) {
                    msgEl.textContent = 'El monto no puede ser negativo';
                    msgEl.style.color = '#e74c3c';
                    document.getElementById('c-monto').style.borderColor = '#e74c3c';
                    return;
                }
            }

            msgEl.textContent = 'Guardando...';
            msgEl.style.color = '#7f8c8d';

            try {
                const res = await fetch('./includes/reports/create_concepto.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    credentials: 'same-origin',
                    body: JSON.stringify({
                        Nombre_Concepto: nombre,
                        Descripcion: descripcion || null,
                        Tipo: tipo || null,
                        Monto: monto,
                        Observaciones: observaciones || null
                    })
                });
                
                const responseText = await res.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (jsonError) {
                    // The response is not JSON. It could be a simple success message or a PHP error.
                    if (res.ok) {
                        // Assume success because status is OK. The user report suggests this is the case.
                        msgEl.textContent = 'Concepto creado exitosamente';
                        msgEl.style.color = '#27ae60';
                        document.getElementById('form-concepto-container').style.display = 'none';
                        loadConceptos(); // Recargar lista
                        console.log('Server returned non-JSON response on success:', responseText);
                    } else {
                        // It's an error and not JSON. Display the text.
                        msgEl.textContent = `Error del servidor: ${responseText || 'Respuesta inválida'}`;
                        msgEl.style.color = '#e74c3c';
                        console.error('Error response (not JSON):', responseText);
                    }
                    return;
                }
                
                if(res.ok) {
                    msgEl.textContent = 'Concepto creado exitosamente';
                    msgEl.style.color = '#27ae60';
                    document.getElementById('form-concepto-container').style.display = 'none';
                    loadConceptos(); // Recargar lista
                } else {
                    msgEl.textContent = data.error || `Error al crear el concepto (${res.status})`;
                    msgEl.style.color = '#e74c3c';
                    console.error('Error response:', data);
                }
            } catch(e) {
                msgEl.textContent = `Error de conexión: ${e.message || 'No se pudo conectar con el servidor'}`;
                msgEl.style.color = '#e74c3c';
                console.error('Network error:', e);
            }
        });

        // Cargar datos iniciales
        loadConceptos();
    }

    async function loadConceptos() {
        const container = document.getElementById('lista-conceptos-container');
        if (!container) return;
        
        try {
            const res = await fetch('./includes/nomina/list_conceptos.php');
            const data = await res.json();
            const conceptos = data.conceptos || [];

            if(conceptos.length === 0) {
                container.innerHTML = '<div class="alert-info" style="padding:15px; background:#e8f4f8; border-radius:6px; color:#2c3e50;">No hay conceptos registrados. Crea uno nuevo usando el botón "➕ Nuevo Concepto".</div>';
                return;
            }

            let html = `
                <table style="width:100%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 5px rgba(0,0,0,0.05);">
                    <thead>
                        <tr style="background:#3498db; color:#fff;">
                            <th style="padding:12px; text-align:left;">ID</th>
                            <th style="padding:12px; text-align:left;">Nombre</th>
                            <th style="padding:12px; text-align:left;">Descripción</th>
                            <th style="padding:12px; text-align:left;">Tipo</th>
                            <th style="padding:12px; text-align:right;">Monto (Bs.)</th>
                            <th style="padding:12px; text-align:center;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            conceptos.forEach(c => {
                const tipoColor = c.Tipo === 'Asignación' ? '#2ecc71' : 
                                  c.Tipo === 'Deducción' ? '#e74c3c' : 
                                  c.Tipo === 'Bonificación' ? '#f39c12' : '#95a5a6';
                const montoDisplay = c.Monto !== null ? parseFloat(c.Monto).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, '.') : '-';
                
                html += `
                    <tr style="border-bottom:1px solid #f0f0f0;">
                        <td style="padding:12px;">${c.Id_Concepto}</td>
                        <td style="padding:12px;"><strong>${c.Nombre_Concepto}</strong></td>
                        <td style="padding:12px; color:#7f8c8d;">${c.Descripcion || '-'}</td>
                        <td style="padding:12px;">
                            <span style="background:${tipoColor}; color:#fff; padding:4px 10px; border-radius:12px; font-size:0.85em; font-weight:600;">
                                ${c.Tipo || 'Sin tipo'}
                            </span>
                        </td>
                        <td style="padding:12px; text-align:right; font-weight:600; color:#2c3e50;">
                            ${montoDisplay !== '-' ? 'Bs. ' + montoDisplay : '-'}
                        </td>
                        <td style="padding:12px; text-align:center;">
                            <button class="btn-delete-concepto" data-id="${c.Id_Concepto}" data-name="${c.Nombre_Concepto}" style="background:#e74c3c; color:#fff; border:none; padding:6px 12px; border-radius:4px; cursor:pointer; font-weight:600; font-size:0.9em;">
                                🗑️ Eliminar
                            </button>
                        </td>
                    </tr>
                `;
            });

            html += '</tbody></table>';
            container.innerHTML = html;

            // Agregar event listeners para los botones de eliminar
            container.querySelectorAll('.btn-delete-concepto').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const id = btn.getAttribute('data-id');
                    const nombre = btn.getAttribute('data-name');
                    
                    if (!confirm(`¿Está seguro de que desea eliminar el concepto "${nombre}"?\n\nEsta acción no se puede deshacer.`)) {
                        return;
                    }

                    try {
                        const res = await fetch('./includes/nomina/delete_concepto.php', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({ id: parseInt(id) })
                        });
                        const data = await res.json();
                        
                        if (res.ok) {
                            alert('Concepto eliminado exitosamente');
                            loadConceptos(); // Recargar la lista
                        } else {
                            alert(data.error || 'Error al eliminar el concepto');
                        }
                    } catch(e) {
                        alert('Error de conexión al eliminar el concepto');
                    }
                });
            });

        } catch(e) {
            container.innerHTML = '<p style="color:#e74c3c; padding:15px;">Error cargando la lista de conceptos. Por favor, recarga la página.</p>';
        }
    }

    // --- Funciones para Gestión de Cargos ---
    function renderCargosModule() {
        if (!contentDetails) return;
        
        // --- HTML Structure ---
        contentDetails.innerHTML = `
            <div class="cargos-module">
                <h4>Gestión de Cargos</h4>
                <div style="margin-bottom: 20px;">
                    <button id="btn-add-cargo" class="primary">➕ Nuevo Cargo</button>
                </div>

                <!-- Formulario de creación (oculto por defecto) -->
                <div id="form-cargo-container" style="display:none; background:#f8f9fa; padding:20px; border-radius:8px; margin-bottom:20px;">
                    <h5 style="margin-top:0;">Nuevo Cargo</h5>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px;">
                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:5px;">Nombre del Cargo *</label>
                            <input type="text" id="cargo-nombre" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;" placeholder="Ej: Gerente">
                        </div>
                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:5px;">Área</label>
                            <input type="text" id="cargo-area" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:6px;" placeholder="Ej: Tecnología (Opcional)">
                        </div>
                    </div>
                    <div style="display:flex; gap:10px;">
                        <button id="btn-save-cargo" class="primary">Guardar</button>
                        <button id="btn-cancel-cargo" style="background:#fff; border:1px solid #ccc; padding:8px 15px; border-radius:5px; cursor:pointer;">Cancelar</button>
                    </div>
                    <div id="cargo-msg" style="margin-top:10px;"></div>
                </div>

                <!-- Lista de Cargos -->
                <div id="lista-cargos-container">
                    <p>Cargando cargos...</p>
                </div>

                <!-- Vista de Trabajadores por Cargo -->
                <div id="workers-cargo-view" style="display:none; margin-top:30px; border-top:2px solid #eee; padding-top:20px;">
                    <h4 id="workers-cargo-title" style="color:#2c3e50;">Trabajadores</h4>
                    <div id="workers-cargo-list"></div>
                </div>
            </div>
        `;

        // --- Data fetching and rendering ---
        async function fetchCargos() {
            try {
                const res = await fetch('./includes/nomina/list_cargos.php', { cache: 'no-store' });
                const data = await res.json();
                return res.ok ? (data.cargos || []) : [];
            } catch (e) { return []; }
        }

        async function loadCargos() {
            const container = document.getElementById('lista-cargos-container');
            const cargos = await fetchCargos();

            if (cargos.length === 0) {
                container.innerHTML = '<div class="alert-info">No hay cargos registrados.</div>';
                return;
            }

            container.innerHTML = `
                <table style="width:100%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 5px rgba(0,0,0,0.05);">
                    <thead>
                        <tr style="background:#3498db; color:#fff;">
                            <th style="padding:12px; text-align:left;">ID</th>
                            <th style="padding:12px; text-align:left;">Cargo</th>
                            <th style="padding:12px; text-align:left;">Área</th>
                            <th style="padding:12px; text-align:center;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${cargos.map(cargo => `
                            <tr style="border-bottom:1px solid #f0f0f0;">
                                <td style="padding:12px;">${cargo.Id_Cargo}</td>
                                <td style="padding:12px;"><strong>${cargo.Nombre_profesión}</strong></td>
                                <td style="padding:12px; color:#7f8c8d;">${cargo.Area || '-'}</td>
                                <td style="padding:12px; text-align:center; display:flex; gap:8px; justify-content:center;">
                                    <button class="btn-view-workers-cargo" data-id="${cargo.Id_Cargo}" data-name="${cargo.Nombre_profesión}" style="background:#2ecc71; color:#fff; border:none; padding:8px 12px; border-radius:4px; cursor:pointer;">
                                        👥 Ver Trabajadores
                                    </button>
                                    <button class="btn-delete-cargo" data-id="${cargo.Id_Cargo}" data-name="${cargo.Nombre_profesión}" style="background:#e74c3c; color:#fff; border:none; padding:8px 12px; border-radius:4px; cursor:pointer;">
                                        🗑️ Eliminar
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;

            // Attach listeners for new buttons
            container.querySelectorAll('.btn-view-workers-cargo').forEach(btn => {
                btn.addEventListener('click', () => {
                    showWorkersForCargo(btn.dataset.id, btn.dataset.name);
                });
            });
            container.querySelectorAll('.btn-delete-cargo').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const id = btn.dataset.id;
                    const name = btn.dataset.name;
                    if (!confirm(`¿Está seguro de que desea eliminar el cargo "${name}"?\n\nEsta acción no se puede deshacer.`)) return;
                    
                    try {
                        const res = await fetch('./includes/nomina/delete_cargo.php', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({ id: parseInt(id) })
                        });
                        const data = await res.json();
                        if (res.ok) {
                            loadCargos(); // Refresh list
                        } else {
                            alert(data.error || 'Error al eliminar el cargo.');
                        }
                    } catch (e) {
                        alert('Error de conexión al eliminar el cargo.');
                    }
                });
            });
        }
        
        async function showWorkersForCargo(cargoId, cargoName) {
            const view = document.getElementById('workers-cargo-view');
            const title = document.getElementById('workers-cargo-title');
            const list = document.getElementById('workers-cargo-list');

            view.style.display = 'block';
            title.textContent = `Trabajadores con el cargo: ${cargoName}`;
            list.innerHTML = '<p>Cargando trabajadores...</p>';
            view.scrollIntoView({ behavior: 'smooth' });
            
        try {
            const res = await fetch('../includes/workers/list_workers.php', { cache: 'no-store' });
            const data = await res.json();
            const workers = res.ok ? (data.workers || []) : [];
                
                const filteredWorkers = workers.filter(w => String(w.Id_Cargo) === String(cargoId));

                if (filteredWorkers.length === 0) {
                    list.innerHTML = '<div class="alert-info">No hay trabajadores asignados a este cargo actualmente.</div>';
                    return;
                }

                list.innerHTML = `<table style="width:100%; border-collapse:collapse; margin-top:10px; background:#fff; border-radius:6px; overflow:hidden;">
                <thead>
                    <tr style="background:#ecf0f1; color:#2c3e50;">
                        <th style="padding:10px; text-align:left;">Nombre Completo</th>
                        <th style="padding:10px; text-align:left;">Cédula</th>
                        <th style="padding:10px; text-align:left;">Estado</th>
                    </tr>
                </thead>
                <tbody>
                    ${filteredWorkers.map(w => `
                        <tr style="border-bottom:1px solid #eee;">
                            <td style="padding:10px;">${w.Nombre_Completo} ${w.Apellidos}</td>
                            <td style="padding:10px;">${w.Documento_Identidad}</td>
                            <td style="padding:10px;"><span style="background:${w.Contrato_Estado === 'Activo' ? '#d4edda' : '#f8d7da'}; color:${w.Contrato_Estado === 'Activo' ? '#155724' : '#721c24'}; padding:2px 8px; border-radius:10px;">${w.Contrato_Estado}</span></td>
                        </tr>
                    `).join('')}
                </tbody></table>`;
            } catch(e) {
                list.innerHTML = '<p style="color:red">Error al cargar los trabajadores.</p>';
            }
        }
        
        // --- Attach main event listeners ---
        document.getElementById('btn-add-cargo').addEventListener('click', () => {
            document.getElementById('form-cargo-container').style.display = 'block';
            document.getElementById('cargo-nombre').focus();
        });

        document.getElementById('btn-cancel-cargo').addEventListener('click', () => {
            document.getElementById('form-cargo-container').style.display = 'none';
            document.getElementById('cargo-nombre').value = '';
            document.getElementById('cargo-area').value = '';
        });

        document.getElementById('btn-save-cargo').addEventListener('click', async () => {
            const nombre = document.getElementById('cargo-nombre').value.trim();
            const area = document.getElementById('cargo-area').value.trim();
            const msgEl = document.getElementById('cargo-msg');

            if (!nombre) {
                msgEl.textContent = 'El nombre del cargo es obligatorio.';
                msgEl.style.color = '#e74c3c';
                return;
            }
            
            msgEl.textContent = 'Guardando...';
            msgEl.style.color = '#7f8c8d';

            try {
                const res = await fetch('./includes/nomina/create_cargo.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ nombre: nombre, area: area || null })
                });
                const data = await res.json();
                if (res.ok) {
                    msgEl.textContent = '';
                    document.getElementById('cargo-nombre').value = '';
                    document.getElementById('cargo-area').value = '';
                    document.getElementById('form-cargo-container').style.display = 'none';
                    loadCargos(); // Refresh list
                    alert('Cargo creado exitosamente');
                } else {
                    msgEl.textContent = data.error || 'Error al guardar el cargo.';
                    msgEl.style.color = '#e74c3c';
                }
            } catch (e) {
                msgEl.textContent = 'Error de conexión.';
                msgEl.style.color = '#e74c3c';
            }
        });

        // --- Initial Load ---
        loadCargos();
    }

    // --- Funciones para Recibos de Pago (ahora servidas desde backend) ---
    let serverPayslips = [];
    async function initializePayslipData() {
        try{
            console.log('Fetching payslips from API...');
            const res = await fetch('./includes/reports/payslips.php', { credentials: 'same-origin', cache: 'no-store' });
            console.log('API response status:', res.status, res.ok);
            if(!res.ok){
                console.log('API response not ok, setting empty array');
                serverPayslips = [];
                return;
            }
            const rows = await res.json();
            console.log('Raw API response:', rows);
            serverPayslips = rows.map(r => ({
                id: r.Id_Payslip || (r.Data && r.Data.id) || null,
                fechaPago: (r.Data && r.Data.fechaPago) ? r.Data.fechaPago : (r.Fecha_Pago || null),
                periodo: (r.Data && r.Data.periodo) ? r.Data.periodo : (r.Data && r.Data.periodo) || '',
                trabajador: (r.Data && r.Data.trabajador) ? r.Data.trabajador : '',
                trabajadorId: (r.Data && r.Data.trabajadorId) ? r.Data.trabajadorId : (r.Id_Trabajador || null),
                cedula: (r.Data && r.Data.cedula) ? r.Data.cedula : null,
                salarioBase: (r.Data && r.Data.salarioBase) ? r.Data.salarioBase : (r.Salario_Base || 0),
                asignaciones: (r.Data && r.Data.asignaciones) ? r.Data.asignaciones : 0,
                bonificaciones: (r.Data && r.Data.bonificaciones) ? r.Data.bonificaciones : 0,
                deducciones: (r.Data && r.Data.deducciones) ? r.Data.deducciones : 0,
                neto: (r.Data && r.Data.neto) ? r.Data.neto : (r.Neto || 0),
                numeroRecibo: (r.Data && r.Data.numeroRecibo) ? r.Data.numeroRecibo : null,
                fechaInicio: (r.Data && r.Data.fechaInicio) ? r.Data.fechaInicio : null,
                fechaFin: (r.Data && r.Data.fechaFin) ? r.Data.fechaFin : null,
                conceptos: (r.Data && r.Data.conceptos) ? r.Data.conceptos : []
            }));
            console.log('Processed payslips:', serverPayslips);
        }catch(e){
            console.log('Error in initializePayslipData:', e);
            serverPayslips = [];
        }
    }

    function getPayslips() {
        try {
            return serverPayslips || [];
        } catch (e) {
            return [];
        }
    }

    function groupPayslipsByPeriod(payslips) {
        const grouped = {};
        payslips.forEach(payslip => {
            if (!grouped[payslip.periodo]) {
                grouped[payslip.periodo] = [];
            }
            grouped[payslip.periodo].push(payslip);
        });
        return grouped;
    }

    function formatCurrency(amount) {
        // Formato en bolívares venezolanos
        if (amount === null || amount === undefined || isNaN(amount)) {
            return 'Bs. 0,00';
        }
        const numAmount = parseFloat(amount);
        if (isNaN(numAmount)) {
            return 'Bs. 0,00';
        }
        // Formato: Bs. 1.234,56
        const parts = numAmount.toFixed(2).split('.');
        const integerPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        return 'Bs. ' + integerPart + ',' + parts[1];
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('es-VE', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }

    function formatCurrencyVenezuela(amount) {
        // Formato venezolano: 1.234,56 (sin símbolo, para usar en PDF)
        if (amount === null || amount === undefined || isNaN(amount) || amount === '') {
            return '0,00';
        }
        try {
            const numAmount = parseFloat(amount);
            if (isNaN(numAmount)) {
                return '0,00';
            }
            // Formato simple: separar miles con punto y decimales con coma
            const parts = numAmount.toFixed(2).split('.');
            const integerPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
            return integerPart + ',' + parts[1];
        } catch (e) {
            console.warn('Error formateando moneda:', e, 'Valor:', amount);
            // Fallback simple
            const numAmount = parseFloat(amount) || 0;
            return numAmount.toFixed(2).replace('.', ',');
        }
    }

    function formatDateShort(dateString) {
        if (!dateString) return 'N/A';
        try {
            const date = new Date(dateString);
            if (isNaN(date.getTime())) return 'N/A';
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const year = date.getFullYear();
            return `${day}/${month}/${year}`;
        } catch (e) {
            return 'N/A';
        }
    }

    async function downloadPayslipPDF(payslip, overrideConfig = null) {
        try {
            console.log('Iniciando generación de PDF para recibo:', payslip);
            
            if (typeof window.jspdf === 'undefined') {
                alert('Error: La librería jsPDF no está cargada. Por favor, recarga la página.');
                return;
            }

            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            console.log('Documento PDF creado correctamente');

        // Cargar configuración de reportes
        let cfg = {
            companyName: 'Lufra 2020',
            rif: 'J-50032437-5',
            address: 'Acarigua, Venezuela',
            phone: '+58 212-3143674',
            footer: 'Este documento es generado automáticamente por el Sistema de Nóminas Lufra 2020',
            primaryColor: '#3498db',
            logo: ''
        };
        
        if (overrideConfig) {
            cfg = { ...cfg, ...overrideConfig };
        } else {
            try {
                const r = await fetch('./includes/settings.php?key=payroll_report_config');
                if(r.ok) {
                    const saved = await r.json();
                    if(saved) cfg = { ...cfg, ...saved };
                }
            } catch(e) {}
        }

        // Configuración de colores
        const primaryColorr = [52, 152, 219];
        const primaryColor = hexToRgb(cfg.primaryColor || '#3498db');
        const darkColor = [0, 0, 0];
        const borderColor = [200, 200, 200];

        let yPos = 10;

        // === ENCABEZADO IZQUIERDA (Logo y datos de empresa) ===
        // Logo (cuadrado azul con letra L)
        doc.setFillColor(...primaryColorr);
        doc.rect(10, yPos, 15, 15, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('L', 17, yPos + 10, { align: 'center' });
        if (cfg.logo) {
            try {
                // Detectar formato (jpeg/png)
                const fmt = cfg.logo.includes('image/png') ? 'PNG' : 'JPEG';
                doc.addImage(cfg.logo, fmt, 10, yPos, 15, 15);
            } catch(err) { console.warn('Error agregando logo', err); }
        } else {
            doc.setFillColor(...primaryColor);
            doc.rect(10, yPos, 15, 15, 'F');
            doc.setTextColor(255, 255, 255);
            doc.setFontSize(12);
            doc.setFont('helvetica', 'bold');
            doc.text(cfg.companyName.charAt(0), 17, yPos + 10, { align: 'center' });
        }

        // Datos de la empresa
        doc.setTextColor(...darkColor);
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text('Lufra 2020', 28, yPos + 5);
        doc.text(cfg.companyName, 28, yPos + 5);
        
        doc.setFontSize(8);
        doc.setFont('helvetica', 'normal');
        doc.text('R.I.F.: J-50032437-5', 28, yPos + 10);
        doc.text('Dirección: Acarigua, Venezuela', 28, yPos + 14);
        doc.text('Teléfonos: +58 212-3143674', 28, yPos + 18);
        doc.text('R.I.F.: ' + cfg.rif, 28, yPos + 10);
        doc.text('Dirección: ' + cfg.address, 28, yPos + 14);
        doc.text('Teléfonos: ' + cfg.phone, 28, yPos + 18);

        // === ENCABEZADO DERECHA (Información del recibo) ===
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text('RECIBO DE PAGO', 190, yPos + 5, { align: 'right' });
        
        doc.setFontSize(8);
        doc.setFont('helvetica', 'normal');
        doc.text(`Fecha Emisión: ${formatDateShort(payslip.fechaPago || '')}`, 190, yPos + 10, { align: 'right' });
        
        // Número de recibo en caja
        doc.setDrawColor(...borderColor);
        doc.setLineWidth(0.5);
        doc.rect(160, yPos + 12, 30, 8);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        const numeroRecibo = payslip.numeroRecibo || String(payslip.id).padStart(10, '0');
        doc.text(`Número: ${numeroRecibo}`, 175, yPos + 17, { align: 'center' });

        yPos = 35;

        // === INFORMACIÓN DEL TRABAJADOR ===
        doc.setDrawColor(...borderColor);
        doc.setLineWidth(0.3);
        doc.rect(10, yPos, 90, 25);
        
        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.text('Empleado:', 12, yPos + 5);
        doc.setFont('helvetica', 'normal');
        const empleadoText = `${payslip.cedula || 'N/A'} ${payslip.trabajador || 'Trabajador'}`;
        // Truncar si es muy largo (máximo 40 caracteres)
        const empleadoTextShort = empleadoText.length > 40 ? empleadoText.substring(0, 37) + '...' : empleadoText;
        doc.text(empleadoTextShort, 12, yPos + 9);
        
        doc.setFont('helvetica', 'bold');
        doc.text('Cédula:', 12, yPos + 13);
        doc.setFont('helvetica', 'normal');
        doc.text(payslip.cedula || 'N/A', 12, yPos + 17);
        
        doc.setFont('helvetica', 'bold');
        doc.text('Sueldo Mensual:', 12, yPos + 21);
        doc.setFont('helvetica', 'normal');
        // El salario mensual es de 130 bs
        const salarioMensual = 130.00;
        doc.text('Bs. ' + formatCurrencyVenezuela(salarioMensual), 12, yPos + 25);

        // === PERÍODO DE NÓMINA ===
        doc.rect(102, yPos, 88, 25);
        doc.setFont('helvetica', 'bold');
        doc.text('Nómina desde:', 104, yPos + 5);
        doc.setFont('helvetica', 'normal');
        let fechaInicio = payslip.fechaInicio;
        if (!fechaInicio && payslip.fechaPago) {
            // Calcular inicio del período (si es quincenal, primera o segunda quincena)
            const fechaPago = new Date(payslip.fechaPago);
            const dia = fechaPago.getDate();
            if (dia <= 15) {
                // Primera quincena
                fechaInicio = new Date(fechaPago.getFullYear(), fechaPago.getMonth(), 1).toISOString().split('T')[0];
            } else {
                // Segunda quincena
                fechaInicio = new Date(fechaPago.getFullYear(), fechaPago.getMonth(), 16).toISOString().split('T')[0];
            }
        }
        doc.text(formatDateShort(fechaInicio), 104, yPos + 9);
        
        doc.setFont('helvetica', 'bold');
        doc.text('Hasta:', 104, yPos + 13);
        doc.setFont('helvetica', 'normal');
        const fechaFin = payslip.fechaFin || payslip.fechaPago;
        doc.text(formatDateShort(fechaFin), 104, yPos + 17);

        yPos = 65;

        // === TABLA DE CONCEPTOS ===
        // Encabezados de la tabla
        doc.setFillColor(240, 240, 240);
        doc.rect(10, yPos, 180, 8, 'F');
        
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(...darkColor);
        
        // Columnas: Concepto, Descripción, Asignación, Deduc/Reten
        // Ajustar posiciones para mejor alineación
        doc.text('Concepto', 12, yPos + 5.5);
        doc.text('Descripción', 45, yPos + 5.5);
        doc.text('Asignación', 125, yPos + 5.5);
        doc.text('Deduc/Reten', 155, yPos + 5.5);

        // Líneas verticales de la tabla - ajustadas para alinear con los números
        doc.setDrawColor(...borderColor);
        doc.setLineWidth(0.2);
        doc.line(40, yPos, 40, yPos + 50); // Línea después de Concepto
        doc.line(120, yPos, 120, yPos + 50); // Línea después de Descripción
        doc.line(150, yPos, 150, yPos + 50); // Línea después de Asignación

        yPos += 8;

        // Filas de conceptos (vacías por ahora, pero con estructura)
        const conceptos = payslip.conceptos || [];
        const rowHeight = 6;
        const maxRows = 7; // Máximo de filas visibles

        for (let i = 0; i < maxRows; i++) {
            if (i < conceptos.length) {
                const concepto = conceptos[i];
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(8);
                doc.text(concepto.codigo || '', 12, yPos + 4);
                doc.text(concepto.descripcion || '', 42, yPos + 4);
                // Alinear números a la derecha dentro de la columna (ancho de columna ~25mm)
                doc.text(concepto.asignacion ? formatCurrencyVenezuela(concepto.asignacion) : '0,00', 150, yPos + 4, { align: 'right' });
                doc.text(concepto.deduccion ? formatCurrencyVenezuela(concepto.deduccion) : '0,00', 180, yPos + 4, { align: 'right' });
            } else {
                // Filas vacías
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(8);
                doc.setTextColor(200, 200, 200);
                doc.text('', 12, yPos + 4);
                doc.text('', 42, yPos + 4);
                doc.text('0,00', 150, yPos + 4, { align: 'right' });
                doc.text('0,00', 180, yPos + 4, { align: 'right' });
                doc.setTextColor(...darkColor);
            }
            
            // Línea horizontal entre filas
            doc.setDrawColor(...borderColor);
            doc.line(10, yPos + rowHeight, 190, yPos + rowHeight);
            yPos += rowHeight;
        }

        // Cerrar la tabla
        doc.line(10, yPos, 190, yPos);

        yPos += 5;

        // === TOTALES ===
        // Calcular totales solo de los conceptos (asignaciones y deducciones de conceptos)
        // Reutilizar la variable conceptos ya declarada arriba
        let totalAsignacion = 0;
        let totalDeduccion = 0;
        
        conceptos.forEach(concepto => {
            if (concepto.asignacion) {
                totalAsignacion += parseFloat(concepto.asignacion) || 0;
            }
            if (concepto.deduccion) {
                totalDeduccion += parseFloat(concepto.deduccion) || 0;
            }
        });

        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.text('Total:', 125, yPos);
        doc.setFont('helvetica', 'normal');
        // Alinear totales con las columnas de números
        doc.text(formatCurrencyVenezuela(totalAsignacion), 150, yPos, { align: 'right' });
        doc.text(formatCurrencyVenezuela(totalDeduccion), 180, yPos, { align: 'right' });

        yPos += 8;

        // === NETO A PAGAR ===
        // Neto = Salario Base + Total Asignaciones - Total Deducciones
        const salarioBase = parseFloat(payslip.salarioBase) || 130.00;
        const neto = salarioBase + totalAsignacion - totalDeduccion;
        
        doc.setDrawColor(...borderColor);
        doc.setLineWidth(0.5);
        doc.rect(10, yPos, 180, 12);
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text('Neto a Pagar:', 12, yPos + 8);
        doc.text(formatCurrencyVenezuela(neto), 180, yPos + 8, { align: 'right' });

        // Pie de página
        yPos = 275;
        doc.setTextColor(150, 150, 150);
        doc.setFontSize(7);
        doc.setFont('helvetica', 'normal');
        doc.text('Este documento es generado automáticamente por el Sistema de Nóminas Lufra 2020', 105, yPos, { align: 'center' });
        doc.text(cfg.footer, 105, yPos, { align: 'center' });

        // Validar que el documento esté completo antes de guardar
        console.log('Validando documento PDF...');
        
        // Descargar con nombre de archivo seguro
        const periodoLimpio = (payslip.periodo || 'Recibo').replace(/[^a-zA-Z0-9_]/g, '_');
        const fileName = `Recibo_${periodoLimpio}_${payslip.id || '1'}.pdf`;
        console.log('Guardando PDF con nombre:', fileName);
        
        try {
            // Generar el PDF como blob primero para validar
            const pdfBlob = doc.output('blob');
            console.log('PDF generado como blob, tamaño:', pdfBlob.size, 'bytes');
            
            if (pdfBlob.size === 0) {
                throw new Error('El PDF generado está vacío');
            }
            
            // Descargar el PDF
            doc.save(fileName);
            console.log('PDF guardado exitosamente');
            
            // Mensaje de confirmación
            setTimeout(() => {
                alert('Recibo de pago descargado exitosamente: ' + fileName);
            }, 100);
            
        } catch (saveError) {
            console.error('Error al guardar el PDF:', saveError);
            // Intentar método alternativo
            const pdfDataUri = doc.output('datauristring');
            const link = document.createElement('a');
            link.href = pdfDataUri;
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            console.log('PDF descargado usando método alternativo');
        }
        
        } catch (error) {
            console.error('Error al generar el PDF:', error);
            console.error('Stack trace:', error.stack);
            alert('Error al generar el recibo de pago. Por favor, verifica la consola para más detalles.\n\nError: ' + error.message);
        }
    }

    function hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? [
            parseInt(result[1], 16),
            parseInt(result[2], 16),
            parseInt(result[3], 16)
        ] : [52, 152, 219];
    }

    async function renderPayslipHistory() {
        if (!contentDetails) return;

        const auth = sessionUser || {};
        let workerId = null;
        let workerCedula = null;

        // Si es trabajador, obtener su ID y cédula para filtrar sus propios recibos
        if (auth.role === 'Trabajador') {
            contentDetails.innerHTML = '<p>Cargando historial...</p>';
            try {
                const uRes = await fetch('./includes/users/list_users.php', { cache: 'no-store' });
                const uData = await uRes.json();
                const me = (uData.users || []).find(u => String(u.Nombre_usuario) === String(auth.username));
                if (me && me.Id_Trabajador) {
                    workerId = me.Id_Trabajador;
                    // Obtener la cédula del trabajador para filtrado adicional
                    const wRes = await fetch('./includes/workers/list_workers.php', { cache: 'no-store' });
                    if (wRes.ok) {
                        const wData = await wRes.json();
                        const worker = (wData.workers || []).find(w => String(w.Id_Trabajador) === String(workerId));
                        if (worker) workerCedula = worker.Documento_Identidad;
                    }
                }
            } catch(e) { console.error('Error obteniendo datos del trabajador:', e); }
        }

        await initializePayslipData();
        let payslips = getPayslips();

        console.log('workerId:', workerId, 'workerCedula:', workerCedula);
        console.log('payslips before filter:', payslips);

        // Filtrar si tenemos workerId (para que el trabajador solo vea lo suyo)
        if (workerId) {
            payslips = payslips.filter(p => (p.trabajadorId && String(p.trabajadorId) === String(workerId)) || (!p.trabajadorId && p.cedula && String(p.cedula) === String(workerCedula)));
        }

        console.log('payslips after filter:', payslips);

        if (payslips.length === 0) {
            contentDetails.innerHTML = `
                <div class="payslip-container">
                    <h4>Historial de Recibos de Pago</h4>
                    <div class="alert-info">
                        <p>No hay recibos de pago disponibles para este trabajador.</p>
                    </div>
                </div>
            `;
            return;
        }

        const grouped = groupPayslipsByPeriod(payslips);
        const periods = Object.keys(grouped).sort().reverse();

        let html = `
            <div class="payslip-container">
                <h4>Historial de Recibos de Pago</h4>
                <p style="color: #7f8c8d; margin-bottom: 20px;">
                    Visualiza y descarga tus recibos de pago organizados por período.
                </p>
        `;

        periods.forEach(period => {
            const periodPayslips = grouped[period];
            const totalPeriod = periodPayslips.reduce((sum, p) => sum + p.neto, 0);
            
            html += `
                <div class="period-section">
                    <div class="period-header">
                        <h5>${period}</h5>
                        <span class="period-total">Total: ${formatCurrency(totalPeriod)}</span>
                    </div>
                    <div class="payslip-list">
            `;

            periodPayslips.forEach(payslip => {
                html += `
                    <div class="payslip-card">
                        <div class="payslip-info">
                            <div class="payslip-date">
                                <strong>Fecha de Pago:</strong> ${formatDate(payslip.fechaPago)}
                            </div>
                            <div style="margin-top:6px;margin-bottom:6px;color:#555;font-size:0.95em;"><strong>Trabajador:</strong> ${payslip.trabajador || '-'} &nbsp; <strong style="margin-left:10px">Cédula:</strong> ${payslip.cedula || '-'}</div>
                            <div class="payslip-details">
                                <div class="detail-item">
                                    <span class="detail-label">Salario Base:</span>
                                    <span class="detail-value">${formatCurrency(payslip.salarioBase)}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Asignaciones:</span>
                                    <span class="detail-value positive">${formatCurrency(payslip.asignaciones)}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Bonificaciones:</span>
                                    <span class="detail-value positive">${formatCurrency(payslip.bonificaciones)}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Deducciones:</span>
                                    <span class="detail-value negative">${formatCurrency(payslip.deducciones)}</span>
                                </div>
                            </div>
                            <div class="payslip-net">
                                <span class="net-label">Neto a Pagar:</span>
                                <span class="net-amount">${formatCurrency(payslip.neto)}</span>
                            </div>
                        </div>
                        <div class="payslip-actions">
                            <button class="btn-download" data-payslip-id="${payslip.id}">
                                📄 Descargar PDF
                            </button>
                        </div>
                    </div>
                `;
            });

            html += `
                    </div>
                </div>
            `;
        });

        html += `</div>`;

        contentDetails.innerHTML = html;
        
        // Agregar event listeners a los botones de descarga
        const downloadButtons = contentDetails.querySelectorAll('.btn-download');
        downloadButtons.forEach(button => {
            button.addEventListener('click', function() {
                const payslipId = this.getAttribute('data-payslip-id');
                // Comparar como strings para evitar errores de tipo (número vs texto)
                const payslip = payslips.find(p => String(p.id) === String(payslipId));
                if (payslip) {
                    downloadPayslipPDF(payslip);
                } else {
                    console.error('Recibo no encontrado. ID buscado:', payslipId);
                    alert('No se encontró la información del recibo.');
                }
            });
        });
    }

    // --- Implementaciones Trabajador ---
    function renderWorkerModule(name){
        if(!contentDetails) return; const auth = sessionUser || {};
        if(name.toLowerCase().includes('perfil')){
            contentDetails.innerHTML = `<div><h4>Mi Perfil</h4><div id="perfil-content">Cargando datos personales...</div></div>`;

            // Si no es trabajador, mostrar el formulario simple existente
            if((auth.role||'').toLowerCase() !== 'trabajador'){
                const perfilContent = document.getElementById('perfil-content');
                perfilContent.innerHTML = `<label>Usuario: <input id="profile-username" value="${auth.username||''}"/></label><label>Rol: <input id="profile-role" value="${auth.role||''}" disabled/></label><div style="margin-top:8px"><button id="save-profile" class="primary">Guardar</button></div>`;
                document.getElementById('save-profile').addEventListener('click', ()=>{ const u = document.getElementById('profile-username').value.trim(); if(!u) return alert('Nombre requerido'); const a = sessionUser || {}; a.username = u; sessionUser = a; alert('Perfil actualizado'); });
                return;
            }

            // Para trabajadores: buscar el Id_Trabajador vinculado y mostrar SOLO datos personales
            (async ()=>{
                const perfilContent = document.getElementById('perfil-content');
                try{
                    // 1) Obtener usuario actual desde la lista de usuarios para conocer Id_Trabajador
                    const uRes = await fetch('./includes/users/list_users.php', { cache: 'no-store' });
                    const uData = await uRes.json();
                    const me = (uData.users || []).find(u => String(u.Nombre_usuario) === String(auth.username));
                    if(!me || !me.Id_Trabajador){ perfilContent.innerHTML = '<p>No hay un trabajador vinculado a este usuario. Contacta al administrador.</p>'; return; }

                    // 2) Cargar lista de trabajadores y buscar por Id_Trabajador
                    let workers = [];
                    if (typeof loadWorkersFromServer === 'function') {
                        try { workers = await loadWorkersFromServer(); } catch(e2){ console.warn('loadWorkersFromServer failed:', e2); workers = []; }
                    } else {
                        try{
                            const resW = await fetch('./includes/workers/list_workers.php', { cache: 'no-store' });
                            const dataW = await resW.json();
                            if (resW.ok && dataW.workers) workers = dataW.workers; else workers = dataW.workers || [];
                        }catch(e2){ console.warn('Direct fetch list_workers failed:', e2); workers = []; }
                    }
                    const w = (workers || []).find(x => String(x.Id_Trabajador) === String(me.Id_Trabajador));
                    if(!w){ perfilContent.innerHTML = '<p>No se encontró la información del trabajador.</p>'; return; }

                    // 3) Renderizar datos personales (solo campos personales)
                    const formatDate = d => { try{ if(!d) return '-'; return new Date(d).toLocaleDateString('es-VE'); }catch(e){return d||'-';} };

                    perfilContent.innerHTML = `
                        <div id="personal-view">
                            <div class="personal-data" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                                <div><strong>Nombre:</strong><div id="pv-nombre">${w.Nombre_Completo || '-'}</div></div>
                                <div><strong>Apellidos:</strong><div id="pv-apellidos">${w.Apellidos || '-'}</div></div>
                                <div><strong>Documento:</strong><div id="pv-documento">${w.Documento_Identidad || '-'}</div></div>
                                <div><strong>Correo personal:</strong><div id="pv-correo">${w.Correo || '-'}</div></div>
                                <div><strong>Teléfono móvil:</strong><div id="pv-telefono">${w.Telefono_Movil || '-'}</div></div>
                                <div><strong>Dirección:</strong><div id="pv-direccion">${w.Direccion || '-'}</div></div>
                                <div><strong>Fecha de nacimiento:</strong><div id="pv-nacimiento">${formatDate(w.Fecha_Nacimiento)}</div></div>
                                <div><strong>Género:</strong><div id="pv-genero">${w.Genero || '-'}</div></div>
                                <div><strong>Estado civil:</strong><div id="pv-estado">${w.Estado_Civil || '-'}</div></div>
                                <div><strong>Ingreso anterior:</strong><div id="pv-ingreso">${w.Ingreso_Anterior || '-'}</div></div>
                                </div>
                        </div>
                    `;

                }catch(e){ console.error('Error cargando perfil:', e); perfilContent.innerHTML = `<p>Error cargando datos: ${e && e.message ? e.message : 'Desconocido'}</p>`; }
            })();

            return;
        }
        if(name.toLowerCase().includes('historial')){
            renderPayslipHistory();
            return;
        }
        if(name.toLowerCase().includes('resumen')){ contentDetails.innerHTML = `<div><h4>Resumen salarial</h4><p>Salario base: $1000</p><p>Deducciones: $200</p><p><strong>Net: $800</strong></p></div>`; return; }
        if(name.toLowerCase().includes('vacacion')|| name.toLowerCase().includes('vacaciones')){
            contentDetails.innerHTML = `<div><h4>Solicitud de Vacaciones</h4><label>Desde: <input type="date" id="vac-from"/></label><label>Hasta: <input type="date" id="vac-to"/></label><button id="send-vac" class="primary">Enviar</button><div id="vac-list" style="margin-top:8px"></div></div>`;
            async function loadVacations(){ try{ const res = await fetch('./includes/reports/vacations.php'); if(!res.ok) return []; return await res.json(); }catch(e){ return []; } }
            const r = fetch('./includes/reports/vacations.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ user: auth.username, from: f, to: t }) });
            async function renderVacations(){ const arr = await loadVacations(); document.getElementById('vac-list').innerHTML = arr.length? arr.map(v=> `<div>${v.username}: ${v.from_date} -> ${v.to_date} (solicitado ${v.requested_at})</div>`).join('') : '<p>No hay solicitudes.</p>'; }
            renderVacations(); return;
        }
        contentDetails.innerHTML = `<p>Módulo '${name}' no implementado (Trabajador).</p>`;
    }

    // Helper para renderizar pagos en el perfil (reutilizable)
    async function renderProfilePays(workerId, workerCedula){
        const listEl = document.getElementById('perfil-pagos-list');
        if(!listEl) return;
        try{
            await initializePayslipData();
            const pays = getPayslips();
            const myPays = pays.filter(p => (p.trabajadorId && String(p.trabajadorId) === String(workerId)) || (!p.trabajadorId && String(p.cedula) === String(workerCedula)));
            if(!myPays.length){ listEl.innerHTML = '<p style="color:#7f8c8d">No tiene recibos registrados.</p>'; return; }
            listEl.innerHTML = `<table style="width:100%;border-collapse:collapse"><thead><tr style="background:#ecf0f1"><th style="padding:6px">Fecha</th><th style="padding:6px">Período</th><th style="padding:6px">Neto</th><th style="padding:6px"></th></tr></thead><tbody>${myPays.map(p=>`<tr><td style="padding:6px">${formatDate(p.fechaPago)}</td><td style="padding:6px">${p.periodo}</td><td style="padding:6px">${formatCurrency(p.neto)}</td><td style="padding:6px"><button class="perfil-download" data-pid="${p.id}" style="background:#3498db;color:#fff;border:none;padding:6px 8px;border-radius:4px;cursor:pointer">📄 Descargar</button></td></tr>`).join('')}</tbody></table>`;
            listEl.querySelectorAll('.perfil-download').forEach(b=> b.addEventListener('click', ()=>{ const pid = b.getAttribute('data-pid'); const pays = getPayslips(); const slip = pays.find(pp => String(pp.id) === String(pid)); if(slip) downloadPayslipPDF(slip); }));
        }catch(e){ console.warn('Error renderProfilePays', e); listEl.innerHTML = '<p style="color:#e74c3c">Error al cargar historial.</p>'; }
    }

    // --- Implementaciones SuperUsuario ---
    function renderSuperModule(name){
        if(!contentDetails) return;
        if(name.toLowerCase().includes('usuarios')){ renderSuperUserView(); return; }
        if(name.toLowerCase().includes('configur')){
            const key='payroll_global_config';
            function loadGlobalCfg(){ return fetch('./includes/settings.php?key='+encodeURIComponent(key)).then(r=> r.ok? r.text().then(t=>{ try{ return JSON.parse(t); }catch(e){ return {}; } }) : {}).catch(()=>({})); }
            loadGlobalCfg().then(cfg=>{
                contentDetails.innerHTML = `<div><h4>Configuración Global</h4><textarea id="global-cfg" style="width:100%;height:220px">${JSON.stringify(cfg,null,2)}</textarea><div style="margin-top:8px"><button id="save-global" class="primary">Guardar</button></div></div>`;
                fetch('./includes/settings.php',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ key: key, value: v }) }).then(r=>{ if(r.ok) alert('Guardado'); else alert('Error al guardar'); }).catch(()=>alert('Error al guardar'));
            });
            return;
        }
        if(name.toLowerCase().includes('logs')){
            const key = 'payroll_logs';
            fetch('./includes/settings.php?key='+encodeURIComponent(key)).then(r=> r.ok ? r.text() : Promise.resolve('[]')).then(text=>{
                let logs = [];
                try{ logs = JSON.parse(text) || []; }catch(e){ logs = []; }
                contentDetails.innerHTML = `<div><h4>Logs</h4>${logs.length? logs.map(l=> `<div>${l}</div>`).join('') : '<p>No hay logs.</p>'}<div style="margin-top:10px"><button id="download-logs" class="primary">Descargar</button></div></div>`;
                document.getElementById('download-logs').addEventListener('click', ()=>{ const arr = logs; const blob=new Blob([arr.join('\n')],{type:'text/plain'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='logs.txt'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); });
            }).catch(()=>{ contentDetails.innerHTML = `<div><h4>Logs</h4><p>No hay logs.</p></div>`; });
            return;
        }
        if(name.toLowerCase().includes('respaldo')|| name.toLowerCase().includes('respaldo')){
            contentDetails.innerHTML = `<div><h4>Respaldo de Base de Datos (simulado)</h4><button id="export-db" class="primary">Exportar JSON</button></div>`;
            document.getElementById('export-db').addEventListener('click', async ()=>{
                try{
                    const [usersRes, workersRes, novRes] = await Promise.all([
                        fetch('./includes/users/list_users.php'),
                        fetch('./includes/workers/list_workers.php'),
                        fetch('./includes/reports/novedades.php')
                    ]);
                    const users = usersRes.ok ? await usersRes.json() : {};
                    const workers = workersRes.ok ? (await workersRes.json()).workers : [];
                    const novedades = novRes.ok ? await novRes.json() : [];
                    const dump = { users, employees: workers, novedades };
                    const blob = new Blob([JSON.stringify(dump,null,2)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='backup.json'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
                }catch(e){ alert('Error generando respaldo'); }
            });
            return;
        }

        // Gestión de Usuarios - vista y CRUD simple (con edición)
        function renderSuperUserView(){
            if(!contentDetails) return;
            if(contentHeader) contentHeader.innerHTML = `<h4>Gestión de Usuarios y Roles</h4>`;
            contentDetails.innerHTML = `
                <div id="users-app">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <button id="new-user-btn" class="primary">➕ Nuevo Usuario</button>
                            <button id="refresh-users" style="margin-left:8px;">🔄 Refrescar</button>
                            <button id="create-default-su" style="margin-left:8px; background:#8e44ad; color:#fff; border:none; padding:8px 10px; border-radius:5px; cursor:pointer;">⚙️ Crear SuperUsuario por defecto</button>
                        </div>
                        <div id="users-message" style="color:#7f8c8d"></div>
                    </div>
                    <div id="user-form" style="display:none; margin-top:12px; background:#f8f9fa; padding:12px; border-radius:8px;">
                        <h5 id="user-form-title">Crear Usuario</h5>
                        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px">    
                            <input id="u-username" placeholder="Usuario"/>
                            <input id="u-email" placeholder="Correo"/>
                            <input id="u-name" placeholder="Nombre"/>
                            <select id="u-role">
                                <option value="Trabajador">Trabajador</option>
                                <option value="Administrativo">Administrativo</option>
                                <option value="SuperUsuario">SuperUsuario</option>
                            </select>
                            <select id="u-worker">
                                <option value="">— Sin trabajador —</option>
                            </select>
                            <input id="u-password" type="password" placeholder="Contraseña (dejar vacío para no cambiar)"/>
                            <input id="u-password-confirm" type="password" placeholder="Confirmar contraseña (si aplica)"/>
                        </div>
                        <div style="margin-top:8px;">
                            <button id="save-user" class="primary">Guardar</button>
                            <button id="cancel-user" style="margin-left:8px;">Cancelar</button>
                        </div>
                    </div>
                    <div id="users-list" style="margin-top:16px;"></div>
                </div>
            `;

            const usersMessage = document.getElementById('users-message');
            const newUserBtn = document.getElementById('new-user-btn');
            const userForm = document.getElementById('user-form');
            const saveBtn = document.getElementById('save-user');
            const cancelBtn = document.getElementById('cancel-user');
            const refreshBtn = document.getElementById('refresh-users');
            const formTitle = document.getElementById('user-form-title');

            let editUserId = null; // si no es null, estamos en modo edición

            function showUsersMsg(msg, type='info'){ if(usersMessage){ usersMessage.textContent = msg; usersMessage.style.color = type==='error' ? '#e74c3c' : type==='success' ? '#27ae60' : '#7f8c8d'; } }

            newUserBtn.addEventListener('click', ()=> { editUserId = null; formTitle.textContent = 'Crear Usuario'; userForm.style.display = userForm.style.display === 'none' ? 'block' : 'none'; clearForm(); });

            cancelBtn.addEventListener('click', ()=> { editUserId = null; userForm.style.display = 'none'; clearForm(); });

            refreshBtn.addEventListener('click', ()=> { loadAndRenderUsers(); });

            // Load workers to populate the worker select in user form
            window.loadWorkersForUsers = async function loadWorkersForUsers(){
                try{
                    const res = await fetch('./includes/workers/list_workers.php', { cache: 'no-store' });
                    const data = await res.json();
                    const sel = document.getElementById('u-worker');
                    if(!sel) return;
                    // clear except default
                    sel.innerHTML = '<option value="">— Sin trabajador —</option>';
                    if(res.ok && data.workers && data.workers.length){
                        data.workers.forEach(w=>{
                            const opt = document.createElement('option');
                            opt.value = w.Id_Trabajador;
                            opt.textContent = `${w.Nombre_Completo || w.Nombre} ${w.Apellidos || ''} ${w.Documento_Identidad ? '· ' + w.Documento_Identidad : ''}`;
                            sel.appendChild(opt);
                        });
                    }
                }catch(e){ /* ignore */ }
            }

            // Create default SuperUsuario button
            const createSuBtn = document.getElementById('create-default-su');
            if(createSuBtn){
                createSuBtn.addEventListener('click', async ()=>{
                    if(!confirm('Crear un usuario SuperUsuario por defecto? Se generará un usuario con contraseña temporal.')) return;
                    showUsersMsg('Creando SuperUsuario...');
                    try{
                        const res = await fetch('./includes/auth/create_superuser.php', { method: 'POST' });
                        const data = await res.json();
                        if(res.ok){
                            if(data.password){
                                showUsersMsg(`Creado: ${data.username} · contraseña: ${data.password}`,'success');
                            } else if(data.message && data.username){
                                showUsersMsg(`${data.message}: ${data.username}`,'info');
                            } else if(data.message){
                                showUsersMsg(data.message,'info');
                            }
                            loadAndRenderUsers();
                        } else {
                            showUsersMsg(data.error || 'Error creando SuperUsuario','error');
                        }
                    }catch(e){ showUsersMsg('Error de conexión','error'); }
                });
            }

            async function loadUsers(){
                try{
                    const res = await fetch('./includes/users/list_users.php', { cache: 'no-store' });
                    const data = await res.json();
                    if(res.ok && data.users) return data.users;
                    return data.users || [];
                }catch(e){
                    // No fallback to localStorage: return empty list on error
                    return [];
                }
            }

            function renderUsersTable(users){
                const el = document.getElementById('users-list');
                if(!el) return;
                if(!users || !users.length){ el.innerHTML = '<p>No hay usuarios registrados.</p>'; return; }

                const activeUsers = users.filter(u => u.Estado !== 'Inactivo');
                const inactiveUsers = users.filter(u => u.Estado === 'Inactivo');

                const buildTable = (list, title, titleColor) => {
                    if(!list.length) return '';
                    return `
                        <h5 style="margin-top:20px; color:${titleColor}; border-bottom: 2px solid ${titleColor}; padding-bottom: 5px;">${title}</h5>
                        <table style="width:100%;border-collapse:collapse; margin-bottom: 20px;">
                        <thead>
                            <tr style="background:#3498db;color:#fff;">
                                <th style="padding:8px">ID</th>
                                <th style="padding:8px">Usuario</th>
                                <th style="padding:8px">Correo</th>
                                <th style="padding:8px">Rol</th>
                                <th style="padding:8px">Estado</th>
                                <th style="padding:8px">Trabajador</th>
                                <th style="padding:8px">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>${list.map(u=>{
                            const isInactive = u.Estado === 'Inactivo';
                            const statusColor = isInactive ? '#e74c3c' : '#27ae60';
                            const statusLabel = u.Estado || 'Activo';
                            
                            return `<tr>
                                <td style="padding:8px">${u.Id_Usuario}</td>
                                <td style="padding:8px">${u.Nombre_usuario}</td>
                                <td style="padding:8px">${u.Correo}</td>
                                <td style="padding:8px">${u.Nombre_rol||''}</td>
                                <td style="padding:8px"><span style="color:${statusColor};font-weight:bold">${statusLabel}</span></td>
                                <td style="padding:8px">${u.Trabajador_Nombre||'—'}</td>
                                <td style="padding:8px">
                                    <button class="edit-user-btn" data-id="${u.Id_Usuario}" data-username="${u.Nombre_usuario}" data-email="${u.Correo}" data-role="${u.Nombre_rol||''}" data-worker-id="${u.Id_Trabajador||''}" style="background:#3498db;color:#fff;border:none;padding:6px 8px;border-radius:4px;cursor:pointer;margin-right:6px;">Editar</button>
                                    ${isInactive 
                                        ? `<button class="activate-user-btn" data-id="${u.Id_Usuario}" style="background:#27ae60;color:#fff;border:none;padding:6px 8px;border-radius:4px;cursor:pointer;">Activar</button>`
                                        : `<button class="del-user-btn" data-id="${u.Id_Usuario}" style="background:#e74c3c;color:#fff;border:none;padding:6px 8px;border-radius:4px;cursor:pointer;">Desactivar</button>`
                                    }
                                </td>
                            </tr>`;
                        }).join('')}</tbody></table>`;
                };

                let html = '';
                if(activeUsers.length) html += buildTable(activeUsers, 'Usuarios Activos', '#2c3e50');
                else html += '<p>No hay usuarios activos.</p>';

                if(inactiveUsers.length) html += buildTable(inactiveUsers, 'Usuarios Inactivos', '#e74c3c');

                el.innerHTML = html;
                attachUserListeners();
            }

            function attachUserListeners(){
                document.querySelectorAll('.del-user-btn').forEach(b=>{
                    b.addEventListener('click', async ()=>{
                        if(!confirm('¿Desactivar usuario?')) return;
                        const id = b.getAttribute('data-id');
                        try{
                            const res = await fetch('./includes/auth/delete_user.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id }) });
                            const data = await res.json();
                            if(res.ok){ showUsersMsg('Usuario desactivado','success'); if(window.loadWorkersForUsers) window.loadWorkersForUsers(); loadAndRenderUsers(); } else { showUsersMsg(data.error || 'Error al desactivar', 'error'); }
                        }catch(e){ showUsersMsg('Error de conexión', 'error'); }
                    });
                });

                document.querySelectorAll('.activate-user-btn').forEach(b=>{
                    b.addEventListener('click', async ()=>{
                        if(!confirm('¿Reactivar usuario?')) return;
                        const id = b.getAttribute('data-id');
                        try{
                            const res = await fetch('./includes/auth/activate_user.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id }) });
                            const data = await res.json();
                            if(res.ok){ showUsersMsg('Usuario activado','success'); if(window.loadWorkersForUsers) window.loadWorkersForUsers(); loadAndRenderUsers(); } else { showUsersMsg(data.error || 'Error al activar', 'error'); }
                        }catch(e){ showUsersMsg('Error de conexión', 'error'); }
                    });
                });

                document.querySelectorAll('.edit-user-btn').forEach(b=>{
                    b.addEventListener('click', ()=>{
                        editUserId = b.getAttribute('data-id');
                        // prefills: name (fallback to username) and username (important for update)
                        document.getElementById('u-name').value = b.getAttribute('data-name') || b.getAttribute('data-username') || '';
                        document.getElementById('u-email').value = b.getAttribute('data-email') || '';
                        document.getElementById('u-username').value = b.getAttribute('data-username') || '';
                        // seleccionar el rol
                        const roleVal = b.getAttribute('data-role') || 'Trabajador';
                        document.getElementById('u-role').value = roleVal;
                        // seleccionar trabajador vinculado
                        const workerId = b.getAttribute('data-worker-id') || '';
                        if(document.getElementById('u-worker')) document.getElementById('u-worker').value = workerId;
                        document.getElementById('u-password').value = '';
                        document.getElementById('u-password-confirm').value = '';
                        formTitle.textContent = 'Editar Usuario (ID: ' + editUserId + ')';
                        userForm.style.display = 'block';
                    });
                });
            }

            function clearForm(){
                document.getElementById('u-name').value = '';
                document.getElementById('u-email').value = '';
                document.getElementById('u-username').value = '';
                document.getElementById('u-role').value = 'Trabajador';
                document.getElementById('u-password').value = '';
                document.getElementById('u-password-confirm').value = '';
                editUserId = null;
                formTitle.textContent = 'Crear Usuario';
            }

            async function loadAndRenderUsers(){ showUsersMsg('Cargando...'); const users = await loadUsers(); renderUsersTable(users); showUsersMsg(''); }

            saveBtn.addEventListener('click', async ()=>{
                const name = document.getElementById('u-name').value.trim();
                const email = document.getElementById('u-email').value.trim();
                const username = document.getElementById('u-username').value.trim();
                const password = document.getElementById('u-password').value;
                const passwordConfirm = document.getElementById('u-password-confirm').value;
                const role = document.getElementById('u-role').value;

                // Require username even when editing (backend expects it)
                if(!name || !email || !username || !role){ showUsersMsg('Completa los campos requeridos','error'); return; }
                // For creation, password confirmation is required
                if(!editUserId && (!password || !passwordConfirm)){ showUsersMsg('Completa los campos requeridos (contraseña)','error'); return; }

                const emailOK = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
                if(!emailOK){ showUsersMsg('Correo inválido','error'); return; }
                if(password || passwordConfirm){ if(password !== passwordConfirm){ showUsersMsg('Las contraseñas no coinciden','error'); return; } }
                if(password){ const failed = [ (pw)=> pw.length >= 8, (pw)=> /[a-z]/.test(pw), (pw)=> /[A-Z]/.test(pw), (pw)=> /[0-9]/.test(pw), (pw)=> /[!@#$%^&*]/.test(pw) ].filter(fn => !fn(password)); if(failed.length){ showUsersMsg('Contraseña no cumple requisitos','error'); return; } }

                try{
                    const workerVal = document.getElementById('u-worker') ? document.getElementById('u-worker').value : '';

                    // Build payload consistently
                    const payload = { name, email, username, role, Id_Trabajador: workerVal || '' };
                    if(password) payload.password = password;

                    console.log('Saving user', { editUserId, payload });

                    if(editUserId){
                        // actualizar
                        payload.id = editUserId;
                        const res = await fetch('../includes/auth/update_user.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
                        let data;
                        try { data = await res.json(); } catch(parseErr){ data = { error: await res.text() } }
                        if(res.ok){ showUsersMsg('Usuario actualizado','success'); clearForm(); userForm.style.display='none'; loadWorkersForUsers(); loadAndRenderUsers(); } else { console.error('Update failed', res.status, data); showUsersMsg(data.error || `Error al actualizar (${res.status})`, 'error'); }
                    } else {
                        // crear
                        const res = await fetch('../includes/auth/register.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
                        let data;
                        try { data = await res.json(); } catch(parseErr){ data = { error: await res.text() } }
                        if(res.ok){ showUsersMsg('Usuario creado','success'); clearForm(); userForm.style.display='none'; loadWorkersForUsers(); loadAndRenderUsers(); } else { console.error('Create failed', res.status, data); showUsersMsg(data.error || `Error al crear (${res.status})`, 'error'); }
                    }
                }catch(e){ console.error('Connection error', e); showUsersMsg('Error de conexión: ' + (e && e.message ? e.message : ''),'error'); }
            });

            loadWorkersForUsers();
            loadAndRenderUsers();
        }

        contentDetails.innerHTML = `<p>Módulo '${name}' no implementado (SuperUsuario).</p>`;
    }

    // Mostrar usuario y logout
    const auth = sessionUser || {};
    const usernameDisplay = document.getElementById('username-display');
    if(usernameDisplay && auth) usernameDisplay.textContent = auth.username || auth.role || '';
    const logoutBtn = document.getElementById('logout-btn');
    if(logoutBtn) logoutBtn.addEventListener('click', logout);
    
    // Cargar vista según rol autenticado (fallback administrativo)
    if (typeof loadRoleView === 'function') {
        loadRoleView((auth && auth.role) ? auth.role : 'Administrativo');
    } else {
        // Si la función aún no está disponible, será invocada cuando se inicialice la interfaz (initPayrollPage)
        console.warn('loadRoleView no está disponible todavía; se inicializará con initPayrollPage');
    }
}

function initLoginPage() {
    // Corregir enlace de estilos si es necesario (login.html may use styles.css)
    const form = document.getElementById('loginForm') || document.getElementById('login-form') || document.getElementById('login-form');
    if(!form) return;

    form.addEventListener('submit', function(e){
        e.preventDefault();
        const userInput = document.getElementById('username');
        const passInput = document.getElementById('password');
        const username = userInput ? userInput.value.trim() : 'demo';
        const password = passInput ? passInput.value : '';

        // Cuenta demo: admin/admin -> rol Administrativo
        if((username === 'admin' && password === 'admin') || (username === 'demo' && password === 'demo')){
            setAuth({ username: username, role: 'Administrativo', logged: true });
            // mostrar éxito si existe
            const successCard = document.getElementById('successCard');
            if(successCard){ successCard.style.display = ''; }
            // redirigir
            window.location.href = 'index.php';
            return;
        }

        // Autenticación simple local: cualquier usuario con contraseña no vacía será trabajador
        if(username && password.length > 0){
            setAuth({ username: username, role: 'Trabajador', logged: true });
            window.location.href = 'index.php';
            return;
        }

        const message = document.getElementById('message') || document.getElementById('regMessage');
        if(message) message.textContent = 'Usuario o contraseña inválidos.';
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    const pathname = window.location.pathname.toLowerCase();

    // Si estamos en login page -> inicializar login
    if(document.getElementById('loginForm') || pathname.endsWith('login.php')){
        initLoginPage();
        return;
    }

    // Comprobar sesión en el backend
    const auth = await checkSessionAsync();
    sessionUser = auth;
    // Depuración ligera: muestra lo que devolvió el servidor
    console.debug('checkSession:', auth);

    // Si estamos en Index (o en cualquier otra página del sistema) -> verificar auth
    if(document.getElementById('content-header') || pathname.endsWith('index.php')){
        if(!auth){
            // no autenticado -> redirigir a la página de login sin mensaje (para evitar bucle visual)
            window.location.replace('Login.php');
            return;
        }
        // inicializar interfaz administrativa
        initPayrollPage();
    }
});

// Asegurar que al usar el botón "Atrás" o al restaurar desde bfcache también se verifique la sesión
async function ensureAuthOnShow(event){
    // Evitar verificación si ya estamos en el login (previene bucle de redirección)
    if(document.getElementById('loginForm') || window.location.pathname.toLowerCase().includes('login.php')) return;

    const a = await checkSessionAsync();
    if(!a){
        // Mostrar alerta solo si se navega desde el historial (Atrás/Adelante)
        const isHistoryNav = (event.type === 'pageshow' && event.persisted) || event.type === 'popstate';
        if(isHistoryNav) {
            try{ alert('Sesión expirada. Por favor, ingresa de nuevo.'); }catch(e){}
            window.location.replace('Login.php?expired=1');
        } else {
            window.location.replace('Login.php');
        }
    }
}
window.addEventListener('pageshow', ensureAuthOnShow);
window.addEventListener('popstate', ensureAuthOnShow);
