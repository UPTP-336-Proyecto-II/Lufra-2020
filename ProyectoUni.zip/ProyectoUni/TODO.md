# TODO: Fix file connections in ProyectoUni

## Files to fix require_once 'config.php' to '../config/config.php'
- [x] includes/workers/update_worker.php
- [x] includes/users/create_superuser.php
- [x] includes/users/activate_user.php
- [x] includes/workers/list_workers.php
- [x] includes/workers/delete_worker.php
- [x] includes/workers/deactivate_worker.php
- [x] includes/workers/add_worker.php
- [x] includes/workers/activate_worker.php
- [x] includes/users/create_superuser_cli.php (special: __DIR__ . '/config.php' to __DIR__ . '/../config/config.php')
- [x] includes/reports/novedades.php
- [x] includes/reports/vacations.php
- [x] includes/users/update_user.php
- [x] includes/reports/payslips.php
- [x] includes/users/settings.php
- [x] includes/users/list_users.php
- [x] includes/users/list_niveles.php
- [x] includes/users/delete_user.php
- [x] includes/users/registrar.php
- [x] includes/nomina/list_tipo_nomina.php
- [x] includes/nomina/list_conceptos.php
- [x] includes/nomina/list_cargos.php
- [x] includes/nomina/delete_concepto.php
- [x] includes/nomina/delete_cargo.php
- [x] includes/nomina/create_concepto.php
- [x] includes/nomina/create_cargo.php
- [x] includes/nomina/create_tipo_nomina.php
- [x] includes/auth/login.php

## Check other files for connections
- [x] admin.php (HTML, links to assets/)
- [x] homepage.php (HTML, links to assets/ - fixed image paths)
- [x] Login.php (HTML, links to assets/ - fixed CSS, JS, image, and href paths)
- [x] superusuario.php (HTML, links to assets/ - fixed CSS, JS, and href paths)
- [x] trabajador.php (HTML, links to assets/ - fixed CSS and JS paths)
- [x] assets/css/ files (fixed image paths in utilities.css)
- [x] assets/js/ files (checked, no issues found)
