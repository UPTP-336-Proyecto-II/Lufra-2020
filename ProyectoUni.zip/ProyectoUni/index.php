<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- TITULO DE LA PÁGINA -->
    <title>Homepage Lufra 2020</title>
    <meta name="title" content="Portfolio Template - Open source" />
    <meta
      name="description"
      content="Build or customize your portfolio website using this super easy template. Free to use if you are a member of the community or a contributor to this project"
    />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta
      property="og:url"
      content="https://github.com/CommunityPro/portfolio-html"
    />
    <meta property="og:title" content="Portfolio Template - Open source" />
    <meta
      property="og:description"
      content="Build or customize your portfolio website using this super easy template. Free to use if you are a member of the community or a contributor to this project"
    />
    <meta
      property="og:image"
      content="https://user-images.githubusercontent.com/62628408/150613011-b78a7f5a-0af1-4312-aab0-0022e7258693.png"
    />

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta
      property="twitter:url"
      content="https://github.com/CommunityPro/portfolio-html"
    />
    <meta property="twitter:title" content="Portfolio Template - Open source" />
    <meta
      property="twitter:description"
      content="Build or customize your portfolio website using this super easy template. Free to use if you are a member of the community or a contributor to this project"
    />
    <meta
      property="twitter:image"
      content="https://user-images.githubusercontent.com/62628408/150613011-b78a7f5a-0af1-4312-aab0-0022e7258693.png"
    />

    <!-- Link -->
    <link
      rel="apple-touch-icon"
      sizes="180x180"
      href="assets/favicon/apple-touch-icon.png"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="/assets/favicon/favicon-16x16.png"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="32x32"
      href="assets/favicon/favicon-32x32.png"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="192x192"
      href="assets/favicon/android-chrome-192x192.png"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="512x512"
      href="assets/favicon/android-chrome-512x512.png"
    />
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />
    <link rel="manifest" href="assets/img/favicon/site.webmanifest" />
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"
      integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/utilities.css" />
  </head>
  <body>
    <header id="hero">
      <!-- Navbar -->
      <nav class="navbar">
        <div class="container">
          <!-- Logo -->
          <h1 id="logo">
            <a href="https://github.com/UPTP-336-Proyecto-II/Lufra-2020" target="_blank"
              ><img src="assets/img/icono repositorio UPTP.jpg" alt="Your Logo"
            /></a>
          </h1>
          <!-- Navbar links -->
          <ul class="nav-menu">
            <li><a class="nav-link" href="#conocenos">CONÓCENOS</a></li>
            <li><a class="nav-link" href="#productos">PRODUCTOS</a></li>
            <li><a class="nav-link" href="#footer">CONTACTOS</a></li>
            <li><a class="nav-link" href="#"></a></li>
            <li>
              <a
                class="nav-link btn btn-primary"
                href="Login.php"
                >Ingresar <i class="fas fa-arrow-right"></i
              ></a>
            </li>
<!-- Agregar el acceso al login cuando esté listo -Adrian-->
            <!-- Toggle switch -->
            <div class="theme-switch">
              <input type="checkbox" id="switch" />
              <label class="toggle-icons" for="switch">
                <img class="moon" src="assets/img/moon.svg" />
                <img class="sun" src="assets/img/sun.svg" />
              </label>
            </div>
            <!-- Hamburger menu -->
          </ul>
          <div class="hamburger">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
          </div>
        </div>
      </nav>

      <section class="header-container">
        <img
          class="profile-image"
          src="assets/img/logolufra2.jpeg"
          alt=""
        />
        <h1>Hola, somos Lufra 2020</h1>

        <div class="content-text">
          <h2>Venta de lubricantes, filtros y repuestos agricolas</h2>
          <br>

          <p>
            Somos tienda física, ubicados en Acarigua sector centro, en la calle 32 entre avenidas 37 y 38 bella vista 1.
          </p>
        </div>
        <a
          href="#conocenos"
          class="btn btn-secondary"
          target=""
          >Conócenos</a
        >
      </section>
    </header>

    <!-- informacion de la comunidad -->
    <section id="conocenos" class="project-container container">
      <div class="division"></div>
      <div class="content-text">
        <h2 style="color:green;"><b><u>¿Quiénes somos?</u></b></h2><!-- estilos aplicados en html -->
        <br>
        <p><b>Lufra 2020, C.A. es una empresa venezolana dedicada a la venta de aceites, filtros y misceláneos para vehículos livianos, camiones y maquinaria pesada. Con un enfoque en calidad, disponibilidad y atención personalizada, la empresa se ha consolidado como un proveedor confiable para transportistas, talleres y particulares que buscan soluciones rápidas y seguras para el mantenimiento de sus unidades.</b></p>
<br>
<p><b>Además de su amplio catálogo de productos —que incluye lubricantes certificados, filtros de aire, aceite y combustible, así como productos complementarios para el cuidado automotriz—, Lufra 2020, C.A. también ofrece servicios especializados de fabricación de mangueras hidráulicas a medida y cambios de aceite, brindando una atención integral que responde a las necesidades del sector automotor.</b></p>
<br>
<h2 style="color: green;"><b><u>Misión</u></b></h2>
        <br>
        <p><b>Ofrecer productos automotrices de alta calidad, especialmente aceites, filtros, misceláneos, mangueras hidráulicas y servicios de cambio de aceite, que garanticen el rendimiento y la durabilidad de vehículos livianos y pesados, brindando atención personalizada y soluciones confiables a nuestros clientes en todo el territorio nacional</b>.</p>
<br>
<h2 style="color: green;"><b><u>Visión</u></b></h2>
<br>
<p><b>Ser reconocidos como la empresa líder en el occidente venezolano en la distribución de repuestos automotrices y prestación de servicios técnicos, destacando por su responsabilidad, variedad de productos, asesoría técnica y compromiso con el mantenimiento seguro de cada vehículo</b>.</p>
      </div>

    <!-- Projects -->
    <section id="productos" class="project-container container">
      <div class="division"></div>
      <div class="content-text">
        <h2 style="color: green;"><b>Productos</b></h2>
        <p><b>Observa algunos de nuestros productos:</b></p>
      </div>

      <article class="project">
        <!-- Se agregaron las imágenes de los productos - Kelvis -->
        <!-- Project 1 -->
        <div href="" class="card">
          
          <div class="project-info">
            <div class="project-bio">
        <h3>Filtro de transmisión</h3>
              <p>AR94510</p>
            </div>

            <div class="project-link">
              <a href="https://api.whatsapp.com/send?phone=+584121542114&text=*Buen%20d%C3%ADa%20%F0%9F%91%8B%F0%9F%8F%8D%EF%B8%8F.%20Quiero%20mas%20informaci%C3%B3n%20sobre%20el%20siguiente%20producto:*%20%F0%9F%91%89https://www.instagram.com/p/CG5Kmp5H1Xq/?utm_source=ig_web_copy_link&igsh=NTc4MTIwNjQ2YQ==%20%F0%9F%91%88%20" target="_blank"><i class="fab fa-whatsapp"></i></a>
              <a href="https://www.instagram.com/p/CG5Kmp5H1Xq/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==" target="_blank"><i class="fas fa-globe"></i></a>
            </div>
          </div>
        </div>

        <!-- Project 2 -->
        <div href="" class="card">
          
          <div class="project-info">
            <div class="project-bio">
              <h3>Filtro de combustible</h3>
              <p>RE62419</p>
            </div>

            <div class="project-link">
              <a href="https://api.whatsapp.com/send?phone=+584121542114&text=*Buen%20d%C3%ADa%20%F0%9F%91%8B%F0%9F%8F%8D%EF%B8%8F.%20Quiero%20mas%20informaci%C3%B3n%20sobre%20el%20siguiente%20producto:*%20%F0%9F%91%89https://www.instagram.com/p/CGdGsdnHSVW/?utm_source=ig_web_copy_link&igsh=NTc4MTIwNjQ2YQ==" target="_blank"><i class="fab fa-whatsapp"></i></a>
              <a href="https://www.instagram.com/p/CGdGsdnHSVW/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==" target="_blank"><i class="fas fa-globe"></i></a>
            </div>
          </div>
        </div>

        <!-- Porject 3 -->
        <div href="" class="card">
          
          <div class="project-info">
            <div class="project-bio">
              <h3>Filtro de aceite</h3>
              <p>RE504836</p>
            </div>

            <div class="project-link">
              <a href="https://api.whatsapp.com/send?phone=+584121542114&text=*Buen%20d%C3%ADa%20%F0%9F%91%8B%F0%9F%8F%8D%EF%B8%8F.%20Quiero%20mas%20informaci%C3%B3n%20sobre%20el%20siguiente%20producto:*%20%F0%9F%91%89https://www.instagram.com/p/CHX1DV1ngO0/?utm_source=ig_web_copy_link&igsh=NTc4MTIwNjQ2YQ==" target="_blank"><i class="fab fa-whatsapp"></i></a>
              <a href="https://www.instagram.com/p/CHX1DV1ngO0/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==" target="_blank"><i class="fas fa-globe"></i></a>
            </div>
          </div>
        </div>

        <!-- Project 4 -->
        <div href="" class="card">
          
          <div class="project-info">
            <div class="project-bio">
              <h3>Filtro de aire</h3>
              <p>AL150288</p>
            </div>

            <div class="project-link">
              <a href="https://api.whatsapp.com/send?phone=+584121542114&text=*Buen%20d%C3%ADa%20%F0%9F%91%8B%F0%9F%8F%8D%EF%B8%8F.%20Quiero%20mas%20informaci%C3%B3n%20sobre%20el%20siguiente%20producto:*%20%F0%9F%91%89https://www.instagram.com/p/CHLgsxUH4Sc/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==" target="_blank"><i class="fab fa-whatsapp"></i></a>
              <a href="https://www.instagram.com/p/CHLgsxUH4Sc/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==" target="_blank"><i class="fas fa-globe"></i></a>
            </div>
          </div>
        </div>

        <!-- Project 5 -->
        <div href="" class="card">
          
          <div class="project-info">
            <div class="project-bio">
              <h3>Filtro de aceite hidráulico</h3>
              <p>AE43494</p>
            </div>

            <div class="project-link">
              <a href="https://api.whatsapp.com/send?phone=+584121542114&text=*Buen%20d%C3%ADa%20%F0%9F%91%8B%F0%9F%8F%8D%EF%B8%8F.%20Quiero%20mas%20informaci%C3%B3n%20sobre%20el%20siguiente%20producto:*%20%F0%9F%91%89https://www.instagram.com/p/CG-F2TNnf7S/?utm_source=ig_web_copy_link&igsh=NTc4MTIwNjQ2YQ==://www.instagram.com/p/CHLgsxUH4Sc/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==" target="_blank"><i class="fab fa-whatsapp"></i></a>
              <a href="https://www.instagram.com/p/CG-F2TNnf7S/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==" target="_blank"><i class="fas fa-globe"></i></a>
            </div>
          </div>
        </div>

        <!-- Project 6 -->
        <div href="" class="card">
          
          <div class="project-info">
            <div class="project-bio">
              <h3>Aceites</h3>
              <p>Mineral, Sintético,</p>
                <p>Semi-sintético</p>
            </div>

            <div class="project-link">
              <a href="https://api.whatsapp.com/send?phone=+584121542114&text=*Buen%20d%C3%ADa%20%F0%9F%91%8B%F0%9F%8F%8D%EF%B8%8F.%20Quiero%20mas%20informaci%C3%B3n%20sobre%20el%20siguiente%20producto:*%20%F0%9F%91%89https://www.instagram.com/p/CBoXoF5ntCq/?utm_source=ig_web_copy_link&igsh=NTc4MTIwNjQ2YQ==" target="_blank"><i class="fab fa-whatsapp"></i></a>
              <a href="https://www.instagram.com/p/CBoXoF5ntCq/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==" target="_blank"><i class="fas fa-globe"></i></a>
            </div>
          </div>
        </div>
      </article>

    </section>

    <footer id="footer">
      <div class="container">
        <a href="mailto:lufra2020ca@gmail.com" target="_blank"><b>lufra2020ca@gmail.com</b></a><br>
        <a href="https://wa.me/584121542114" target="_blank" style="color: green;"><b><u>Contáctanos aquí</u></b></a>
        <!-- Social links -->
        <div class="social">
          <a href="https://www.instagram.com/lufra_2020?igsh=N3h6MWtjbTJha3ly" target="_blank"
            ><img src="./assets/img/icons8-instagram-50.png" alt="Instagram"
          /></a>
          <a href="https://wa.me/584121542114" target="_blank"
            ><img src="./assets/img/icons8-whatsapp-50.png" alt="WhatsApp" style="margin-left: 15px;"
          /></a>
          <br>
          <!--  DESCOMENTAR CUANDO HAYAN OTRAS REDES
            <a href="#" target="_blank"><img src="./assets/twitter-icon.svg" alt="Twitter" /></a>
          <a href="#" target="_blank"
            ><img src="./assets/linkedin-icon.svg" alt="Linkedin"
          /></a> 
          <a href="#" target="_blank"><img src="./assets/github-icon.svg" alt="GitHub" /></a>
          <a href="#" target="_blank"
            ><img src="./assets/hashnode-icon.svg" alt="Hashnode" 
          /></a> -->
        </div>
        <!-- Attribution -->
        <div class="attribution">
          <a
            href="https://github.com/CommunityPro/portfolio-html"
            target="_blank"
            rel="noopener noreferrer"
          >
            <img
              src="https://user-images.githubusercontent.com/62628408/157202263-9174da24-b19a-4017-9b7c-a1d26ae8f014.svg"
              alt="attribution"
              width="150px"
            />
          </a>
        </div>
        <p>Copyright &copy; Communitypro <span id="datee"></span>, All rights reserved</p>
      </div>
    </footer>
    <script src="assets/js/script.js"></script>
  </body>
</html>
 <!-- FALTA MODIFICAR EL FAVICON, CUANDO DESCUBRA CÓMO, LO CAMBIO -ADRIAN -->
<!-- se agregarán más detalles como imágenes en carrusel cuando se sepa como agregarlas -->