<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Nóminas - SuperUsuario</title>
    <link rel="stylesheet" href="assets/css/Sistema.css">
</head>
<body>

    <div class="sidebar">
        <h3>Sistema de Nóminas</h3>
        <div id="user-info" style="text-align:center; padding:10px;">
            <p id="username-display" style="margin:0; font-weight:600;"></p>
            <button id="logout-btn" style="margin-top:8px; padding:6px 10px; border-radius:4px; border:none; background:#e74c3c; color:white; cursor:pointer;">Cerrar sesión</button>
        </div>
        
        <div id="module-navigation"></div>

        <div style="padding: 10px; border-top: 1px solid rgba(255,255,255,0.2); margin-top: 10px;">
            <a href="includes/reports/generar_reporte.php" style="text-decoration: none; color: white; font-family: sans-serif; display: flex; align-items: center; gap: 10px; padding: 10px; border-radius: 4px; transition: background 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='transparent'">
                <span style="font-size: 18px;">📊</span>
                <span style="font-size: 14px; font-weight: 500;">Generar Reportes</span>
            </a>
        </div>
    </div>

    <div class="main-content">
        <h1>Panel de SuperUsuario</h1>
        
        <div class="content-box">
            <div id="content-header"></div>
            <div id="content-details"></div>
        </div>
    </div>

    <script src="assets/js/Sistema.js"></script>
</body>
</html>