<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

try {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT Id_Tipo_Nomina, Frecuencia, Fecha_Inicio, Fecha_Fin FROM tipo_nomina ORDER BY Id_Tipo_Nomina ASC");
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($r = $result->fetch_assoc()) $rows[] = $r;
    echo json_encode(['tipos' => $rows]);
    $stmt->close();
    closeDBConnection($conn);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>