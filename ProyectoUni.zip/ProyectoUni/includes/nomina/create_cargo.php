<?php
header('Content-Type: application/json');
require_once 'config.php';

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['Administrativo', 'SuperUsuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$nombre = isset($input['nombre']) ? trim($input['nombre']) : null;
$area = isset($input['area']) ? trim($input['area']) : null;

if (empty($nombre)) {
    http_response_code(400);
    echo json_encode(['error' => 'El nombre del cargo es obligatorio.']);
    exit;
}

try {
    $conn = getDBConnection();
    
    // Check if cargo already exists
    $stmt = $conn->prepare("SELECT Id_Cargo FROM cargo WHERE Nombre_profesión = ?");
    $stmt->bind_param('s', $nombre);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        http_response_code(409); // Conflict
        echo json_encode(['error' => 'Ya existe un cargo con ese nombre.']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $stmt->close();

    // Insert new cargo
    $stmt = $conn->prepare("INSERT INTO cargo (Nombre_profesión, Area) VALUES (?, ?)");
    $stmt->bind_param('ss', $nombre, $area);

    if ($stmt->execute()) {
        $newId = $conn->insert_id;
        echo json_encode(['message' => 'Cargo creado exitosamente.', 'id' => $newId]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to create cargo.']);
    }

    $stmt->close();
    closeDBConnection($conn);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>