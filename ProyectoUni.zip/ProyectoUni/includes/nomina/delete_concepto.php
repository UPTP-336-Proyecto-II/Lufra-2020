<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

// Verificar sesión y rol (solo Administrativo / SuperUsuario pueden eliminar conceptos)
session_start();
if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No authenticated']);
    exit;
}
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
if (!in_array($role, ['Administrativo', 'SuperUsuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing id']);
    exit;
}

$id = intval($input['id']);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid id']);
    exit;
}

try {
    $conn = getDBConnection();
    $conn->autocommit(false); // Iniciar transacción

    // Verificar que el concepto existe
    $stmt = $conn->prepare("SELECT Id_Concepto FROM concepto WHERE Id_Concepto = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Concepto no encontrado']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $stmt->close();

    // Eliminar registros relacionados primero (asignaciones, deducciones, bonificaciones)
    // Eliminar asignaciones
    $stmt = $conn->prepare("DELETE FROM asignaciones WHERE Id_Concepto = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    // Eliminar deducciones
    $stmt = $conn->prepare("DELETE FROM deducciones WHERE Id_Concepto = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    // Eliminar bonificaciones
    $stmt = $conn->prepare("DELETE FROM bonificaciones WHERE Id_Concepto = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    // Eliminar el concepto base
    $stmt = $conn->prepare("DELETE FROM concepto WHERE Id_Concepto = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        $conn->commit();
        echo json_encode(['message' => 'Concepto eliminado exitosamente']);
    } else {
        $conn->rollback();
        http_response_code(404);
        echo json_encode(['error' => 'Concepto no encontrado']);
    }
    
    $stmt->close();
    closeDBConnection($conn);

} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollback();
        closeDBConnection($conn);
    }
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>

