<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once 'config.php';

// Verificar sesión y rol (solo Administrativo / SuperUsuario pueden crear conceptos)
session_start();
if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No authenticated']);
    exit;
}
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
if (!in_array($role, ['Administrativo', 'SuperUsuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

// Campos requeridos
$Nombre_Concepto = isset($input['Nombre_Concepto']) ? trim($input['Nombre_Concepto']) : null;
$Descripcion = isset($input['Descripcion']) ? trim($input['Descripcion']) : null;
$Tipo = isset($input['Tipo']) ? trim($input['Tipo']) : null; // 'Asignación', 'Deducción', 'Bonificación'
$Monto = isset($input['Monto']) ? $input['Monto'] : null;
$Observaciones = isset($input['Observaciones']) ? trim($input['Observaciones']) : null;

// Función para validar solo letras (y espacios, acentos, etc.)
function validarSoloLetras($texto) {
    // Permite letras, espacios, acentos, ñ, guiones y apóstrofes
    return preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s\-\']+$/u', $texto);
}



// Validación básica
if (!$Nombre_Concepto) {
    http_response_code(400);
    echo json_encode(['error' => 'El nombre del concepto es obligatorio']);
    exit;
}

// Validar que el nombre solo contenga letras (y espacios, acentos, etc.)
if (!validarSoloLetras($Nombre_Concepto)) {
    http_response_code(400);
    echo json_encode(['error' => 'El nombre del concepto solo puede contener letras, espacios y acentos. No se permiten números ni caracteres especiales.']);
    exit;
}

// Validar longitud del nombre
if (strlen($Nombre_Concepto) < 3) {
    http_response_code(400);
    echo json_encode(['error' => 'El nombre del concepto debe tener al menos 3 caracteres']);
    exit;
}

if (strlen($Nombre_Concepto) > 100) {
    http_response_code(400);
    echo json_encode(['error' => 'El nombre del concepto no puede exceder 100 caracteres']);
    exit;
}

if ($Tipo && !in_array($Tipo, ['Asignación', 'Deducción', 'Bonificación', 'Sin tipo'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Tipo inválido. Debe ser: Asignación, Deducción o Bonificación']);
    exit;
}

// Si se especifica un tipo, el monto es requerido (excepto para algunos conceptos base)
if ($Tipo && $Tipo !== 'Sin tipo' && $Monto === null) {
    http_response_code(400);
    echo json_encode(['error' => 'El monto es requerido cuando se especifica un tipo']);
    exit;
}

// Validar que el monto sea un número válido (si se proporciona)
if ($Monto !== null) {
    if (!is_numeric($Monto)) {
        http_response_code(400);
        echo json_encode(['error' => 'El monto debe ser un valor numérico.']);
        exit;
    }

    // Convertir a float para asegurar el tipo de dato correcto
    $Monto = floatval($Monto);

    if ($Monto < 0) {
        http_response_code(400);
        echo json_encode(['error' => 'El monto no puede ser negativo']);
        exit;
    }
}

try {
    $conn = getDBConnection();
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['error' => 'Error de conexión a la base de datos']);
        exit;
    }
    $conn->autocommit(false); // Iniciar transacción

    // Verificar si ya existe un concepto con el mismo nombre
    $stmt = $conn->prepare("SELECT Id_Concepto FROM concepto WHERE Nombre_Concepto = ?");
    $stmt->bind_param('s', $Nombre_Concepto);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Ya existe un concepto con ese nombre']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $stmt->close();

    // Insertar concepto base
    $stmt = $conn->prepare("INSERT INTO concepto (Nombre_Concepto, Descripción) VALUES (?, ?)");
    $stmt->bind_param('ss', $Nombre_Concepto, $Descripcion);
    if (!$stmt->execute()) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(['error' => 'Error al crear el concepto']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $Id_Concepto = $conn->insert_id;
    $stmt->close();

    // Si se especificó un tipo, crear el registro correspondiente
    if ($Tipo && $Tipo !== 'Sin tipo') {
        $stmt = null;
        $success = false;
        
        if ($Tipo === 'Asignación') {
            $stmt = $conn->prepare("INSERT INTO asignaciones (Id_Concepto, Monto) VALUES (?, ?)");
            if ($stmt) {
                $stmt->bind_param('id', $Id_Concepto, $Monto);
                $success = $stmt->execute();
            }
        } elseif ($Tipo === 'Deducción') {
            $stmt = $conn->prepare("INSERT INTO deducciones (Id_Concepto, Monto) VALUES (?, ?)");
            if ($stmt) {
                $stmt->bind_param('id', $Id_Concepto, $Monto);
                $success = $stmt->execute();
            }
        } elseif ($Tipo === 'Bonificación') {
            // Para bonificaciones, usar la descripción del concepto o null
            $descBonificacion = $Descripcion ? $Descripcion : null;
            $obsBonificacion = $Observaciones ? $Observaciones : null;
            $stmt = $conn->prepare("INSERT INTO bonificaciones (Id_Concepto, Descripción, Monto, Observaciones) VALUES (?, ?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param('isds', $Id_Concepto, $descBonificacion, $Monto, $obsBonificacion);
                $success = $stmt->execute();
            }
        }

        if (!$success) {
            $conn->rollback();
            http_response_code(500);
            $errorMsg = 'Error al crear el registro de tipo';
            if ($stmt && $conn->error) {
                $errorMsg .= ': ' . $conn->error;
            } elseif ($stmt && $stmt->error) {
                $errorMsg .= ': ' . $stmt->error;
            }
            if ($stmt) $stmt->close();
            closeDBConnection($conn);
            echo json_encode(['error' => $errorMsg]);
            exit;
        }
        if ($stmt) $stmt->close();
    }

    $conn->commit();
    echo json_encode([
        'message' => 'Concepto creado exitosamente',
        'Id_Concepto' => $Id_Concepto
    ]);
    closeDBConnection($conn);

} catch (Exception $e) {
    if (isset($conn)) {
        if ($conn->in_transaction) {
            $conn->rollback();
        }
        closeDBConnection($conn);
    }
    http_response_code(500);
    // En producción, no mostrar detalles del error. En desarrollo, sí.
    $errorMessage = 'Database error';
    if (defined('DEBUG') && DEBUG) {
        $errorMessage .= ': ' . $e->getMessage();
    }
    echo json_encode(['error' => $errorMessage]);
}
?>

