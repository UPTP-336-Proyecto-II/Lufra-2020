<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

try {
    $conn = getDBConnection();
    
    // Obtener conceptos con información de sus tipos (asignación, deducción, bonificación)
    $sql = "SELECT 
                c.Id_Concepto,
                c.Nombre_Concepto,
                c.Descripción AS Descripcion,
                CASE 
                    WHEN a.Id_Asignacion IS NOT NULL THEN 'Asignación'
                    WHEN d.Id_Deduccion IS NOT NULL THEN 'Deducción'
                    WHEN b.Id_Bonificacion IS NOT NULL THEN 'Bonificación'
                    ELSE 'Sin tipo'
                END AS Tipo,
                COALESCE(a.Monto, d.Monto, b.Monto, NULL) AS Monto,
                b.Observaciones AS Observaciones_Bonificacion
            FROM concepto c
            LEFT JOIN asignaciones a ON c.Id_Concepto = a.Id_Concepto
            LEFT JOIN deducciones d ON c.Id_Concepto = d.Id_Concepto
            LEFT JOIN bonificaciones b ON c.Id_Concepto = b.Id_Concepto
            ORDER BY c.Id_Concepto ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($r = $result->fetch_assoc()) {
        $rows[] = $r;
    }
    echo json_encode(['conceptos' => $rows]);
    $stmt->close();
    closeDBConnection($conn);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>

