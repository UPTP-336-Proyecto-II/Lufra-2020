<?php
header('Content-Type: application/json');
require_once 'config.php';

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['Administrativo', 'SuperUsuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$id = isset($input['id']) ? (int)$input['id'] : 0;

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid cargo ID']);
    exit;
}

try {
    $conn = getDBConnection();
    
    // Check if any worker is assigned to this cargo
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM trabajador WHERE Id_Cargo = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();

    if ($row['count'] > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'No se puede eliminar el cargo porque tiene ' . $row['count'] . ' trabajador(es) asignado(s).']);
        closeDBConnection($conn);
        exit;
    }

    // Delete cargo
    $stmt = $conn->prepare("DELETE FROM cargo WHERE Id_Cargo = ?");
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Cargo eliminado exitosamente.']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Cargo not found.']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to delete cargo.']);
    }

    $stmt->close();
    closeDBConnection($conn);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>