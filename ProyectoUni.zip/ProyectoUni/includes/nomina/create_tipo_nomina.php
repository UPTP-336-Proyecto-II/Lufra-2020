<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

// Verificar sesión y rol (solo Administrativo / SuperUsuario pueden crear tipos de nómina)
session_start();
if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No authenticated']);
    exit;
}
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
if (!in_array($role, ['Administrativo', 'SuperUsuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

$Frecuencia = isset($input['Frecuencia']) ? trim($input['Frecuencia']) : '';
$Fecha_Inicio = isset($input['Fecha_Inicio']) ? trim($input['Fecha_Inicio']) : '';
$Fecha_Fin = isset($input['Fecha_Fin']) ? trim($input['Fecha_Fin']) : '';

if ($Frecuencia === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Frecuencia is required']);
    exit;
}

// Validar que la frecuencia solo contenga letras y espacios
if (!preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s]+$/u', $Frecuencia)) {
    http_response_code(400);
    echo json_encode(['error' => 'La frecuencia solo puede contener letras y espacios']);
    exit;
}

// Validar fechas si se proporcionan ambas
if ($Fecha_Inicio !== '' && $Fecha_Inicio !== '0000-00-00' && $Fecha_Fin !== '' && $Fecha_Fin !== '0000-00-00') {
    $fechaInicio = new DateTime($Fecha_Inicio);
    $fechaFin = new DateTime($Fecha_Fin);
    
    if ($fechaFin < $fechaInicio) {
        http_response_code(400);
        echo json_encode(['error' => 'La fecha de fin no puede ser anterior a la fecha de inicio']);
        exit;
    }
}

// Tabla tiene NOT NULL: si no llegan fechas, usar '0000-00-00' (igual que el dump SQL)
if ($Fecha_Inicio === '') $Fecha_Inicio = '0000-00-00';
if ($Fecha_Fin === '') $Fecha_Fin = '0000-00-00';

try {
    $conn = getDBConnection();

    // Evitar duplicados exactos por Frecuencia (opcional, pero ayuda UX)
    $chk = $conn->prepare("SELECT Id_Tipo_Nomina FROM tipo_nomina WHERE LOWER(Frecuencia) = LOWER(?) LIMIT 1");
    $chk->bind_param('s', $Frecuencia);
    $chk->execute();
    $res = $chk->get_result();
    if ($res && $res->num_rows > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Ya existe un tipo de nómina con esa frecuencia']);
        $chk->close();
        closeDBConnection($conn);
        exit;
    }
    $chk->close();

    $stmt = $conn->prepare("INSERT INTO tipo_nomina (Frecuencia, Fecha_Inicio, Fecha_Fin) VALUES (?, ?, ?)");
    $stmt->bind_param('sss', $Frecuencia, $Fecha_Inicio, $Fecha_Fin);
    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['error' => 'Error inserting tipo_nomina']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }

    $newId = $conn->insert_id;
    $stmt->close();
    closeDBConnection($conn);
    echo json_encode(['message' => 'Tipo de nómina creado', 'Id_Tipo_Nomina' => $newId]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>

