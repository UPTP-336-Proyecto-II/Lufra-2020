<?php
// CLI script to create default SuperUsuario
if (php_sapi_name() !== 'cli') {
    echo "This script must be run from the command line.\n";
    exit(1);
}
require_once __DIR__ . '/config.php';

// Parse args: --username=, --password=
$options = array_slice($argv, 1);
$username = 'superadmin';
$password = 'Admin@1234';
foreach ($options as $opt) {
    if (strpos($opt, '--username=') === 0) $username = substr($opt, strlen('--username='));
    if (strpos($opt, '--password=') === 0) $password = substr($opt, strlen('--password='));
}

try {
    $conn = getDBConnection();

    // find role id for SuperUsuario
    $stmt = $conn->prepare("SELECT Id_rol FROM roles WHERE Nombre_rol = 'SuperUsuario' LIMIT 1");
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        echo "Role 'SuperUsuario' not found in roles table. Aborting.\n";
        $stmt->close();
        closeDBConnection($conn);
        exit(1);
    }
    $row = $res->fetch_assoc();
    $roleId = $row['Id_rol'];
    $stmt->close();

    // Check if any SuperUsuario exists
    $stmt = $conn->prepare("SELECT Id_Usuario, Nombre_usuario, Correo FROM usuario WHERE Id_rol = ? LIMIT 1");
    $stmt->bind_param('i', $roleId);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $existing = $res->fetch_assoc();
        echo "A SuperUsuario already exists:\n";
        echo "  id: " . $existing['Id_Usuario'] . "\n";
        echo "  username: " . $existing['Nombre_usuario'] . "\n";
        echo "  email: " . $existing['Correo'] . "\n";
        $stmt->close();
        closeDBConnection($conn);
        exit(0);
    }
    $stmt->close();

    // ensure unique username
    $baseUser = $username;
    $i = 1;
    while (true) {
        $stmt = $conn->prepare("SELECT Id_Usuario FROM usuario WHERE Nombre_usuario = ? LIMIT 1");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $r = $stmt->get_result();
        if ($r->num_rows === 0) { $stmt->close(); break; }
        $stmt->close();
        $username = $baseUser . $i;
        $i++;
    }

    $email = $username . '@example.com';
    $hashed = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO usuario (Id_rol, Nombre_usuario, Correo, Contraseña) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('isss', $roleId, $username, $email, $hashed);
    if (!$stmt->execute()) {
        echo "Error inserting SuperUsuario: " . $stmt->error . "\n";
        $stmt->close();
        closeDBConnection($conn);
        exit(1);
    }

    $newId = $conn->insert_id;
    $stmt->close();
    closeDBConnection($conn);

    echo "SuperUsuario created successfully:\n";
    echo "  id: $newId\n";
    echo "  username: $username\n";
    echo "  password: $password\n";
    echo "  email: $email\n";
    echo "Please change the password after first login.\n";
    exit(0);

} catch (Exception $e) {
    echo "Database error: " . $e->getMessage() . "\n";
    exit(1);
}
?>