<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';
try{
    $conn = getDBConnection();
    $conn->query("CREATE TABLE IF NOT EXISTS settings (
        `skey` VARCHAR(200) NOT NULL PRIMARY KEY,
        `svalue` LONGTEXT DEFAULT NULL,
        updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    if($_SERVER['REQUEST_METHOD'] === 'GET'){
        if(isset($_GET['key'])){
            $key = $_GET['key'];
            $stmt = $conn->prepare("SELECT svalue FROM settings WHERE skey = ?");
            $stmt->bind_param('s', $key);
            $stmt->execute();
            $res = $stmt->get_result();
            if($row = $res->fetch_assoc()){
                echo $row['svalue'];
            } else { http_response_code(404); echo json_encode(['error'=>'Not found']); }
            exit;
        }
        $res = $conn->query("SELECT skey, svalue FROM settings"); $out = [];
        while($r=$res->fetch_assoc()) $out[$r['skey']] = json_decode($r['svalue'], true);
        echo json_encode($out);
        exit;
    }

    // POST -> set key
    $body = json_decode(file_get_contents('php://input'), true);
    if(!$body || !isset($body['key']) || !isset($body['value'])){ http_response_code(400); echo json_encode(['error'=>'Missing key/value']); exit; }
    $key = $body['key']; $value = json_encode($body['value'], JSON_UNESCAPED_UNICODE);
    $stmt = $conn->prepare("INSERT INTO settings (skey,svalue) VALUES (?,?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)");
    $stmt->bind_param('ss', $key, $value);
    if($stmt->execute()){ echo json_encode(['message'=>'Saved']); } else { http_response_code(500); echo json_encode(['error'=>'Save failed']); }
    exit;
}catch(Exception $e){ http_response_code(500); echo json_encode(['error'=>$e->getMessage()]); }
?>