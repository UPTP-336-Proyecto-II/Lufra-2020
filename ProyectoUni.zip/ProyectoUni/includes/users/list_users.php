<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/config.php';

try {
    $conn = getDBConnection();

    // Asegurar que existe la columna Estado (Migración automática)
    $checkCol = $conn->query("SHOW COLUMNS FROM usuario LIKE 'Estado'");
    if ($checkCol->num_rows === 0) {
        $conn->query("ALTER TABLE usuario ADD COLUMN Estado VARCHAR(20) DEFAULT 'Activo'");
    }

    $stmt = $conn->prepare("SELECT u.Id_Usuario, u.Nombre_usuario, u.Correo, u.Estado, r.Nombre_rol, u.Id_Trabajador, t.Nombre_Completo AS Trabajador_Nombre FROM usuario u LEFT JOIN roles r ON u.Id_rol = r.Id_rol LEFT JOIN trabajador t ON u.Id_Trabajador = t.Id_Trabajador ORDER BY u.Id_Usuario ASC");
    $stmt->execute();
    $result = $stmt->get_result();

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }

    echo json_encode(['users' => $users]);

    $stmt->close();
    closeDBConnection($conn);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}

?>