<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/config.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing id']);
    exit;
}

$id = intval($input['id']);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid id']);
    exit;
}

$name = isset($input['name']) ? trim($input['name']) : null;
$email = isset($input['email']) ? trim($input['email']) : null;
$username = isset($input['username']) ? trim($input['username']) : null;
$role = isset($input['role']) ? $input['role'] : null;
$password = isset($input['password']) && $input['password'] !== '' ? $input['password'] : null;

if (!$name || !$email || !$username || !$role) {
    http_response_code(400);
    echo json_encode(['error' => 'All fields are required (except password when unchanged)']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email format']);
    exit;
}

try {
    $conn = getDBConnection();

    // check uniqueness (exclude current id)
    $stmt = $conn->prepare("SELECT Id_Usuario FROM usuario WHERE (Nombre_usuario = ? OR Correo = ?) AND Id_Usuario != ?");
    $stmt->bind_param("ssi", $username, $email, $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Username or email already in use by another account']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $stmt->close();

    // get role id
    $stmt = $conn->prepare("SELECT Id_rol FROM roles WHERE Nombre_rol = ?");
    $stmt->bind_param("s", $role);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid role']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $roleData = $res->fetch_assoc();
    $roleId = $roleData['Id_rol'];
    $stmt->close();

    // Optional: worker linking
    $Id_Trabajador = isset($input['Id_Trabajador']) && $input['Id_Trabajador'] !== '' ? intval($input['Id_Trabajador']) : null;

    // If a worker is provided, ensure it's not already linked to another user (excluding this user)
    if ($Id_Trabajador !== null) {
        $stmt = $conn->prepare("SELECT Id_Usuario FROM usuario WHERE Id_Trabajador = ? AND Id_Usuario != ?");
        $stmt->bind_param("ii", $Id_Trabajador, $id);
        $stmt->execute();
        $r = $stmt->get_result();
        if ($r->num_rows > 0) {
            http_response_code(400);
            echo json_encode(['error' => 'El trabajador ya tiene un usuario asignado']);
            $stmt->close();
            closeDBConnection($conn);
            exit;
        }
        $stmt->close();
    }

    // build update
    if ($password) {
        // validate password strength
        if (strlen($password) < 8 || !preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[!@#$%^&*]/', $password)) {
            http_response_code(400);
            echo json_encode(['error' => 'Password does not meet requirements']);
            closeDBConnection($conn);
            exit;
        }
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        if ($Id_Trabajador !== null) {
            $stmt = $conn->prepare("UPDATE usuario SET Id_rol = ?, Nombre_usuario = ?, Correo = ?, Contraseña = ?, Id_Trabajador = ? WHERE Id_Usuario = ?");
            $stmt->bind_param("isssii", $roleId, $username, $email, $hashed, $Id_Trabajador, $id);
        } else {
            $stmt = $conn->prepare("UPDATE usuario SET Id_rol = ?, Nombre_usuario = ?, Correo = ?, Contraseña = ?, Id_Trabajador = NULL WHERE Id_Usuario = ?");
            $stmt->bind_param("isssi", $roleId, $username, $email, $hashed, $id);
        }
    } else {
        if ($Id_Trabajador !== null) {
            $stmt = $conn->prepare("UPDATE usuario SET Id_rol = ?, Nombre_usuario = ?, Correo = ?, Id_Trabajador = ? WHERE Id_Usuario = ?");
            $stmt->bind_param("issii", $roleId, $username, $email, $Id_Trabajador, $id);
        } else {
            $stmt = $conn->prepare("UPDATE usuario SET Id_rol = ?, Nombre_usuario = ?, Correo = ?, Id_Trabajador = NULL WHERE Id_Usuario = ?");
            $stmt->bind_param("issi", $roleId, $username, $email, $id);
        }
    }

    if ($stmt->execute()) {
        echo json_encode(['message' => 'Usuario actualizado exitosamente', 'id' => $id, 'username' => $username, 'role' => $role, 'Id_Trabajador' => $Id_Trabajador]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Error updating user']);
    }

    $stmt->close();
    closeDBConnection($conn);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}

?>