<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once 'config.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing id']);
    exit;
}

$id = intval($input['id']);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid id']);
    exit;
}

try {
    $conn = getDBConnection();

    // Check user exists and obtain role
    $stmt = $conn->prepare("SELECT u.Id_Usuario, r.Nombre_rol FROM usuario u LEFT JOIN roles r ON u.Id_rol = r.Id_rol WHERE u.Id_Usuario = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Usuario no encontrado']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }

    $row = $res->fetch_assoc();
    $userRole = $row['Nombre_rol'] ?? '';
    $stmt->close();

    // If user is SuperUsuario, ensure at least one remains
    if (strtolower($userRole) === 'superusuario') {
        $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM usuario u JOIN roles r ON u.Id_rol = r.Id_rol WHERE r.Nombre_rol = 'SuperUsuario'");
        $stmt->execute();
        $cntRes = $stmt->get_result();
        $cntRow = $cntRes->fetch_assoc();
        $count = intval($cntRow['cnt'] ?? 0);
        $stmt->close();

        if ($count <= 1) {
            http_response_code(400);
            echo json_encode(['error' => 'No se puede desactivar al último SuperUsuario']);
            closeDBConnection($conn);
            exit;
        }
    }

    $stmt = $conn->prepare("UPDATE usuario SET Estado = 'Inactivo' WHERE Id_Usuario = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo json_encode(['message' => 'Usuario desactivado']);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Usuario no encontrado']);
    }

    $stmt->close();
    closeDBConnection($conn);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}

?>