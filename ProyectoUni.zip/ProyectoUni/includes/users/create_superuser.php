<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

try {
    $conn = getDBConnection();

    // Get SuperUsuario role id
    $stmt = $conn->prepare("SELECT Id_rol FROM roles WHERE Nombre_rol = 'SuperUsuario' LIMIT 1");
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        http_response_code(500);
        echo json_encode(['error' => 'Role SuperUsuario not found']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $row = $res->fetch_assoc();
    $roleId = $row['Id_rol'];
    $stmt->close();

    // Check if any SuperUsuario already exists
    $stmt = $conn->prepare("SELECT Id_Usuario, Nombre_usuario, Correo FROM usuario WHERE Id_rol = ? LIMIT 1");
    $stmt->bind_param('i', $roleId);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $existing = $res->fetch_assoc();
        echo json_encode(['message' => 'SuperUsuario already exists', 'id' => $existing['Id_Usuario'], 'username' => $existing['Nombre_usuario'], 'email' => $existing['Correo']]);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $stmt->close();

    // Create default credentials (ensure unique username)
    $baseUser = 'superadmin';
    $username = $baseUser;
    $i = 1;
    while (true) {
        $stmt = $conn->prepare("SELECT Id_Usuario FROM usuario WHERE Nombre_usuario = ? LIMIT 1");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $r = $stmt->get_result();
        if ($r->num_rows === 0) { $stmt->close(); break; }
        $stmt->close();
        $username = $baseUser . $i;
        $i++;
    }

    $password = 'Admin@1234'; // default password - change after first login
    $email = $username . '@example.com';
    $hashed = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO usuario (Id_rol, Nombre_usuario, Correo, Contraseña) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('isss', $roleId, $username, $email, $hashed);
    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['error' => 'Error creating SuperUsuario']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }

    $newId = $conn->insert_id;
    $stmt->close();
    closeDBConnection($conn);

    echo json_encode(['message' => 'SuperUsuario created', 'id' => $newId, 'username' => $username, 'password' => $password, 'email' => $email]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>