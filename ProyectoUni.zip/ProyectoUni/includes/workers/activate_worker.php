<?php
header('Content-Type: application/json');
require_once '../config/config.php';

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['Administrativo', 'SuperUsuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$workerId = isset($input['id']) ? (int)$input['id'] : 0;

if ($workerId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid worker ID']);
    exit;
}

try {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("UPDATE contrato_trabajadores SET Estado = 'Activo' WHERE Id_Trabajador = ?");
    $stmt->bind_param('i', $workerId);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Worker activated successfully.']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Worker not found or already active.']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to activate worker.']);
    }

    $stmt->close();
    closeDBConnection($conn);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>