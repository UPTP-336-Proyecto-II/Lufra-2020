<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

// Verificar sesión y rol (solo Administrativo / SuperUsuario pueden desactivar trabajadores)
session_start();
if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No authenticated']);
    exit;
}
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
if (!in_array($role, ['Administrativo', 'SuperUsuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing id']);
    exit;
}

$id = intval($input['id']);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid id']);
    exit;
}

try {
    $conn = getDBConnection();
    
    // Verificar que el trabajador existe
    $stmt = $conn->prepare("SELECT Id_Trabajador FROM trabajador WHERE Id_Trabajador = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Trabajador no encontrado']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $stmt->close();

    // Actualizar el estado del contrato más reciente a "Inactivo"
    $stmt = $conn->prepare("UPDATE contrato_trabajadores SET Estado = 'Inactivo' WHERE Id_Trabajador = ? AND Id_registro = (SELECT Id_registro FROM (SELECT Id_registro FROM contrato_trabajadores WHERE Id_Trabajador = ? ORDER BY Fecha_registro DESC LIMIT 1) AS temp)");
    $stmt->bind_param('ii', $id, $id);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        echo json_encode(['message' => 'Trabajador desactivado exitosamente']);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'No se pudo desactivar el trabajador']);
    }
    
    $stmt->close();
    closeDBConnection($conn);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>

