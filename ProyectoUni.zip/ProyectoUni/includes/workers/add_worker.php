<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

// Verificar sesión y rol (solo Administrativo / SuperUsuario pueden crear trabajadores)
session_start();
if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No authenticated']);
    exit;
}
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
if (!in_array($role, ['Administrativo', 'SuperUsuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

// Required worker fields
$Id_Cargo = isset($input['Id_Cargo']) ? intval($input['Id_Cargo']) : null;
$Id_Nivel_Educativo = isset($input['Id_Nivel_Educativo']) ? intval($input['Id_Nivel_Educativo']) : null;
$Nombre_Completo = isset($input['Nombre_Completo']) ? trim($input['Nombre_Completo']) : null;
$Apellidos = isset($input['Apellidos']) ? trim($input['Apellidos']) : null;
$Fecha_Nacimiento = isset($input['Fecha_Nacimiento']) ? $input['Fecha_Nacimiento'] : null;
$Genero = isset($input['Genero']) ? $input['Genero'] : null;
$Documento_Identidad = isset($input['Documento_Identidad']) ? trim($input['Documento_Identidad']) : null;
$Correo = isset($input['Correo']) ? trim($input['Correo']) : null;
$Telefono_Movil = isset($input['Telefono_Movil']) ? trim($input['Telefono_Movil']) : null;
$Direccion = isset($input['Direccion']) ? trim($input['Direccion']) : null;
$Estado_Civil = isset($input['Estado_Civil']) ? trim($input['Estado_Civil']) : null;
$Ingreso_Anterior = isset($input['Ingreso_Anterior']) ? trim($input['Ingreso_Anterior']) : null;
$Fecha_de_Ingreso = isset($input['Fecha_de_Ingreso']) ? $input['Fecha_de_Ingreso'] : null;

// Contract fields
$Id_Tipo_Nomina = isset($input['Id_Tipo_Nomina']) ? intval($input['Id_Tipo_Nomina']) : null;
$Observaciones = isset($input['Observaciones']) ? trim($input['Observaciones']) : null;
$Estado = isset($input['Estado']) ? trim($input['Estado']) : 'Activo';

// Funciones de validación
function validarSoloLetras($texto) {
    return preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s\-\']+$/u', $texto);
}

function validarSoloNumeros($valor) {
    return preg_match('/^[0-9]+$/', $valor);
}

function validarCedula($cedula) {
    // Formato: V-12345678 o E-12345678
    return preg_match('/^[VE]-[0-9]{6,10}$/', $cedula);
}

function validarTelefono($telefono) {
    if (empty($telefono)) return true; // Opcional
    return preg_match('/^[0-9\-\s]+$/', $telefono);
}

function validarFecha($fecha, $tipo) {
    if (empty($fecha)) return ['valido' => true];
    
    $fechaObj = new DateTime($fecha);
    $hoy = new DateTime();
    $hoy->setTime(0, 0, 0);
    
    if ($tipo === 'nacimiento') {
        if ($fechaObj > $hoy) {
            return ['valido' => false, 'mensaje' => 'La fecha de nacimiento no puede ser futura'];
        }
        
        // Validar mayoría de edad (18 años)
        $mayorEdad = clone $hoy;
        $mayorEdad->modify('-18 years');
        if ($fechaObj > $mayorEdad) {
            return ['valido' => false, 'mensaje' => 'El trabajador debe ser mayor de edad (18 años)'];
        }

        $edadMaxima = clone $hoy;
        $edadMaxima->modify('-120 years');
        if ($fechaObj < $edadMaxima) {
            return ['valido' => false, 'mensaje' => 'La fecha de nacimiento no es válida'];
        }
    } else if ($tipo === 'ingreso') {
        if ($fechaObj > $hoy) {
            return ['valido' => false, 'mensaje' => 'La fecha de ingreso no puede ser futura'];
        }
    }
    
    return ['valido' => true];
}

// Basic validation
if (!$Id_Cargo || !$Id_Nivel_Educativo || !$Nombre_Completo || !$Apellidos || !$Documento_Identidad || !$Fecha_de_Ingreso || !$Id_Tipo_Nomina) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

// Validar nombres (solo letras)
if (!validarSoloLetras($Nombre_Completo)) {
    http_response_code(400);
    echo json_encode(['error' => 'El nombre solo puede contener letras, espacios y acentos']);
    exit;
}

if (strlen($Nombre_Completo) < 2) {
    http_response_code(400);
    echo json_encode(['error' => 'El nombre debe tener al menos 2 caracteres']);
    exit;
}

// Validar apellidos (solo letras)
if (!validarSoloLetras($Apellidos)) {
    http_response_code(400);
    echo json_encode(['error' => 'Los apellidos solo pueden contener letras, espacios y acentos']);
    exit;
}

if (strlen($Apellidos) < 2) {
    http_response_code(400);
    echo json_encode(['error' => 'Los apellidos deben tener al menos 2 caracteres']);
    exit;
}

// Validar cédula
if (!validarCedula($Documento_Identidad)) {
    http_response_code(400);
    echo json_encode(['error' => 'La cédula debe tener el formato V-12345678 o E-12345678 (solo números después del guión)']);
    exit;
}

// Validar teléfono
if ($Telefono_Movil && !validarTelefono($Telefono_Movil)) {
    http_response_code(400);
    echo json_encode(['error' => 'El teléfono solo puede contener números, guiones y espacios']);
    exit;
}

// Validar fechas
if ($Fecha_Nacimiento) {
    $validacionNac = validarFecha($Fecha_Nacimiento, 'nacimiento');
    if (!$validacionNac['valido']) {
        http_response_code(400);
        echo json_encode(['error' => $validacionNac['mensaje']]);
        exit;
    }
}

$validacionIngreso = validarFecha($Fecha_de_Ingreso, 'ingreso');
if (!$validacionIngreso['valido']) {
    http_response_code(400);
    echo json_encode(['error' => $validacionIngreso['mensaje']]);
    exit;
}

try {
    $conn = getDBConnection();

    // Check duplicate Documento_Identidad
    $stmt = $conn->prepare("SELECT Id_Trabajador FROM trabajador WHERE Documento_Identidad = ?");
    $stmt->bind_param('s', $Documento_Identidad);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Documento de identidad ya registrado']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $stmt->close();

    // Insert trabajador
    $stmt = $conn->prepare("INSERT INTO trabajador (Id_Cargo, Id_Nivel_Educativo, Id_Contacto_Emergencia, Nombre_Completo, Apellidos, Fecha_Nacimiento, Genero, Documento_Identidad, Correo, Telefono_Movil, Direccion, Estado_Civil, Ingreso_Anterior, Fecha_de_Ingreso) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $null = null; // placeholder for Id_Contacto_Emergencia, not implemented now
    $stmt->bind_param('iiisssssssisss', $Id_Cargo, $Id_Nivel_Educativo, $null, $Nombre_Completo, $Apellidos, $Fecha_Nacimiento, $Genero, $Documento_Identidad, $Correo, $Telefono_Movil, $Direccion, $Estado_Civil, $Ingreso_Anterior, $Fecha_de_Ingreso);

    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['error' => 'Error inserting trabajador']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }

    $Id_Trabajador = $conn->insert_id;
    $stmt->close();

    // Insert contrato_trabajadores
    $stmt = $conn->prepare("INSERT INTO contrato_trabajadores (Id_Trabajador, Id_Tipo_Nomina, Observaciones, Estado) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('iiss', $Id_Trabajador, $Id_Tipo_Nomina, $Observaciones, $Estado);
    if (!$stmt->execute()) {
        // roll back: remove trabajador
        $errStmt = $conn->prepare("DELETE FROM trabajador WHERE Id_Trabajador = ?");
        $errStmt->bind_param('i', $Id_Trabajador);
        $errStmt->execute();
        $errStmt->close();

        http_response_code(500);
        echo json_encode(['error' => 'Error inserting contrato']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }

    $Id_contrato = $conn->insert_id;
    $stmt->close();

    echo json_encode(['message' => 'Trabajador y contrato registrados', 'Id_Trabajador' => $Id_Trabajador, 'Id_contrato' => $Id_contrato]);
    closeDBConnection($conn);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>