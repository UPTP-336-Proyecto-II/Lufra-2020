<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['Id_Trabajador'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Id_Trabajador is required']);
    exit;
}

$Id_Trabajador = intval($input['Id_Trabajador']);
if ($Id_Trabajador <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid Id_Trabajador']);
    exit;
}

// Allowed personal fields
$Nombre_Completo = isset($input['Nombre_Completo']) ? trim($input['Nombre_Completo']) : null;
$Apellidos = isset($input['Apellidos']) ? trim($input['Apellidos']) : null;
$Fecha_Nacimiento = isset($input['Fecha_Nacimiento']) ? $input['Fecha_Nacimiento'] : null;
$Genero = isset($input['Genero']) ? trim($input['Genero']) : null;
$Documento_Identidad = isset($input['Documento_Identidad']) ? trim($input['Documento_Identidad']) : null;
$Correo = isset($input['Correo']) ? trim($input['Correo']) : null;
$Telefono_Movil = isset($input['Telefono_Movil']) ? trim($input['Telefono_Movil']) : null;
$Direccion = isset($input['Direccion']) ? trim($input['Direccion']) : null;
$Estado_Civil = isset($input['Estado_Civil']) ? trim($input['Estado_Civil']) : null;
$Ingreso_Anterior = isset($input['Ingreso_Anterior']) ? trim($input['Ingreso_Anterior']) : null;

try {
    $conn = getDBConnection();

    // If Documento_Identidad provided, ensure it's not used by another trabajador
    if ($Documento_Identidad) {
        $stmt = $conn->prepare("SELECT Id_Trabajador FROM trabajador WHERE Documento_Identidad = ? AND Id_Trabajador != ?");
        $stmt->bind_param('si', $Documento_Identidad, $Id_Trabajador);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Documento de identidad ya registrado en otro trabajador']);
            $stmt->close();
            closeDBConnection($conn);
            exit;
        }
        $stmt->close();
    }

    // Build update statement (only personal fields)
    $stmt = $conn->prepare("UPDATE trabajador SET Nombre_Completo = ?, Apellidos = ?, Fecha_Nacimiento = ?, Genero = ?, Documento_Identidad = ?, Correo = ?, Telefono_Movil = ?, Direccion = ?, Estado_Civil = ?, Ingreso_Anterior = ? WHERE Id_Trabajador = ?");
    $stmt->bind_param('ssssssssssi', $Nombre_Completo, $Apellidos, $Fecha_Nacimiento, $Genero, $Documento_Identidad, $Correo, $Telefono_Movil, $Direccion, $Estado_Civil, $Ingreso_Anterior, $Id_Trabajador);

    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['error' => 'Error updating trabajador']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }
    $stmt->close();

    // Return updated trabajador
    $stmt = $conn->prepare("SELECT Id_Trabajador, Id_Cargo, Id_Nivel_Educativo, Nombre_Completo, Apellidos, Fecha_Nacimiento, Genero, Documento_Identidad, Correo, Telefono_Movil, Direccion, Estado_Civil, Ingreso_Anterior, Fecha_de_Ingreso FROM trabajador WHERE Id_Trabajador = ?");
    $stmt->bind_param('i', $Id_Trabajador);
    $stmt->execute();
    $res = $stmt->get_result();
    $worker = $res->fetch_assoc();
    $stmt->close();

    echo json_encode(['message' => 'Datos personales actualizados', 'worker' => $worker]);
    closeDBConnection($conn);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>