<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';

try {
    $conn = getDBConnection();
    // Return worker basic info and last contract (include personal fields)
    $sql = "SELECT t.Id_Trabajador, t.Id_Cargo, t.Nombre_Completo, t.Apellidos, t.Documento_Identidad, t.Correo, t.Telefono_Movil, t.Direccion, t.Fecha_Nacimiento, t.Genero, t.Estado_Civil, t.Fecha_de_Ingreso, c.Id_registro, c.Id_Tipo_Nomina, tn.Frecuencia, c.Fecha_registro, c.Observaciones, c.Estado AS Contrato_Estado, ca.Nombre_profesión AS Cargo, n.Nombre_Nivel AS Nivel_Educativo
            FROM trabajador t
            LEFT JOIN cargo ca ON t.Id_Cargo = ca.Id_Cargo
            LEFT JOIN nivel_educativo n ON t.Id_Nivel_Educativo = n.Id_Nivel_Educativo
            LEFT JOIN contrato_trabajadores c ON c.Id_registro = (
                SELECT cr.Id_registro FROM contrato_trabajadores cr WHERE cr.Id_Trabajador = t.Id_Trabajador ORDER BY cr.Fecha_registro DESC LIMIT 1
            )
            LEFT JOIN tipo_nomina tn ON tn.Id_Tipo_Nomina = c.Id_Tipo_Nomina
            ORDER BY t.Id_Trabajador ASC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($r = $result->fetch_assoc()) $rows[] = $r;
    echo json_encode(['workers' => $rows]);
    $stmt->close();
    closeDBConnection($conn);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>