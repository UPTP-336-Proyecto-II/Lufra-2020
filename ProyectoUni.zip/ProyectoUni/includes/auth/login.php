<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Se corrigió el path al archivo de configuración - Kelvin
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['username']) || !isset($input['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Username and password are required']);
    exit;
}

$username = trim($input['username']);
$password = $input['password'];

if (empty($username) || empty($password)) {
    http_response_code(400);
    echo json_encode(['error' => 'Username and password cannot be empty']);
    exit;
}

try {
    $conn = getDBConnection();

    // Get user with role
    // Check Estado column existence first to avoid errors if migration hasn't run via list_users yet
    // However, assuming list_users runs or we handle it gracefully. 
    // Ideally, we select * or handle the column if it exists. 
    // For simplicity, we assume the column exists or we check it.
    
    // Let's just select * to get all columns including Estado if it exists
    $stmt = $conn->prepare("
        SELECT u.*, r.Nombre_rol
        FROM usuario u
        JOIN roles r ON u.Id_rol = r.Id_rol
        WHERE u.Nombre_usuario = ?
    ");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        http_response_code(401);
        echo json_encode(['error' => 'Usuario no encontrado']);
        $stmt->close();
        closeDBConnection($conn);
        exit;
    }

    $user = $result->fetch_assoc();
    $stmt->close();

    // Check if user is inactive
    if (isset($user['Estado']) && $user['Estado'] === 'Inactivo') {
        http_response_code(401);
        echo json_encode(['error' => 'Usuario inactivo. Contacte al administrador.']);
        closeDBConnection($conn);
        exit;
    }

    // Verify password (assuming passwords are hashed with password_hash)
    if (!password_verify($password, $user['Contraseña'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Contraseña incorrecta']);
        closeDBConnection($conn);
        exit;
    }

    // Crear sesión en el servidor y establecer cookie HttpOnly (no exponer token al cliente)
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => 'localhost',
        'secure' => false, // cambiar a true en producción con HTTPS
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
    session_regenerate_id(true);
    $_SESSION['id'] = $user['Id_Usuario'];
    $_SESSION['username'] = $user['Nombre_usuario'];
    $_SESSION['role'] = $user['Nombre_rol'];
    $_SESSION['iat'] = time();

    echo json_encode([
        'message' => 'Login exitoso',
        'role' => $user['Nombre_rol']
    ]);

    closeDBConnection($conn);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
