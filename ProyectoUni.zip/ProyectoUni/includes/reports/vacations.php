<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);
require_once '../config/config.php';
try{
    $conn = getDBConnection();
    $conn->query("CREATE TABLE IF NOT EXISTS vacations (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        from_date DATE NOT NULL,
        to_date DATE NOT NULL,
        requested_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    if($_SERVER['REQUEST_METHOD'] === 'GET'){
        $res = $conn->query("SELECT * FROM vacations ORDER BY requested_at DESC");
        $out = [];
        while($r=$res->fetch_assoc()) $out[] = $r;
        echo json_encode($out);
        exit;
    }

    $body = json_decode(file_get_contents('php://input'), true);
    if(!$body || !isset($body['user']) || !isset($body['from']) || !isset($body['to'])){ http_response_code(400); echo json_encode(['error'=>'Missing fields']); exit; }
    $user = $body['user']; $from = $body['from']; $to = $body['to'];
    $stmt = $conn->prepare("INSERT INTO vacations (username, from_date, to_date) VALUES (?,?,?)");
    $stmt->bind_param('sss', $user, $from, $to);
    if($stmt->execute()){ echo json_encode(['message'=>'Created','id'=>$stmt->insert_id]); } else { http_response_code(500); echo json_encode(['error'=>'Insert failed']); }
    exit;
}catch(Exception $e){ http_response_code(500); echo json_encode(['error'=>$e->getMessage()]); }
?>