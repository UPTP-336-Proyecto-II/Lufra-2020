<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/config.php';

try {
    $conn = getDBConnection();

    // Ensure table exists (simple migration)
    $createSql = "CREATE TABLE IF NOT EXISTS payslips (
        Id_Payslip INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        Fecha_Pago DATE NOT NULL,
        Salario_Base DECIMAL(10,2) DEFAULT NULL,
        Neto DECIMAL(10,2) DEFAULT NULL,
        Id_Trabajador INT DEFAULT NULL,
        Data LONGTEXT DEFAULT NULL,
        Created_At TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        Updated_At TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    $conn->query($createSql);

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        // Optional: ?id= or ?trabajador= filter
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT * FROM payslips WHERE Id_Payslip = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $res = $stmt->get_result();
            $row = $res->fetch_assoc();
            if (!$row) { http_response_code(404); echo json_encode(['error'=>'Not found']); exit; }
            $row['Data'] = $row['Data'] ? json_decode($row['Data'], true) : null;
            echo json_encode($row);
            exit;
        }

        if (isset($_GET['trabajador'])) {
            $t = intval($_GET['trabajador']);
            $stmt = $conn->prepare("SELECT * FROM payslips WHERE Id_Trabajador = ? ORDER BY Fecha_Pago DESC, Id_Payslip DESC");
            $stmt->bind_param("i", $t);
            $stmt->execute();
            $res = $stmt->get_result();
            $out = [];
            while($r = $res->fetch_assoc()){ $r['Data'] = $r['Data'] ? json_decode($r['Data'], true) : null; $out[] = $r; }
            echo json_encode($out);
            exit;
        }

        $res = $conn->query("SELECT * FROM payslips ORDER BY Fecha_Pago DESC, Id_Payslip DESC");
        $out = [];
        while($r = $res->fetch_assoc()){ $r['Data'] = $r['Data'] ? json_decode($r['Data'], true) : null; $out[] = $r; }
        echo json_encode($out);
        exit;
    }

    // Read JSON body
    $body = json_decode(file_get_contents('php://input'), true);

    if ($method === 'POST') {
        // Create new payslip
        if (!$body || !isset($body['data'])) { http_response_code(400); echo json_encode(['error'=>'Missing data']); exit; }
        $data = $body['data'];
        $fecha = isset($data['fechaPago']) ? $data['fechaPago'] : date('Y-m-d');
        $salario = isset($data['salarioBase']) ? floatval($data['salarioBase']) : null;
        $neto = isset($data['neto']) ? floatval($data['neto']) : null;
        $trab = isset($data['trabajadorId']) ? intval($data['trabajadorId']) : (isset($body['trabajador']) ? intval($body['trabajador']) : null);
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);

        $stmt = $conn->prepare("INSERT INTO payslips (Fecha_Pago, Salario_Base, Neto, Id_Trabajador, Data) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sddis", $fecha, $salario, $neto, $trab, $json);
        if ($stmt->execute()) {
            $id = $stmt->insert_id;
            http_response_code(201);
            echo json_encode(['message'=>'Created','id'=>$id]);
        } else {
            http_response_code(500);
            echo json_encode(['error'=>'Insert failed']);
        }
        $stmt->close();
        exit;
    }

    if ($method === 'PUT') {
        if (!isset($_GET['id'])) { http_response_code(400); echo json_encode(['error'=>'Missing id']); exit; }
        $id = intval($_GET['id']);
        if (!$body || !isset($body['data'])) { http_response_code(400); echo json_encode(['error'=>'Missing data']); exit; }
        $data = $body['data'];
        $fecha = isset($data['fechaPago']) ? $data['fechaPago'] : null;
        $salario = isset($data['salarioBase']) ? floatval($data['salarioBase']) : null;
        $neto = isset($data['neto']) ? floatval($data['neto']) : null;
        $trab = isset($data['trabajadorId']) ? intval($data['trabajadorId']) : null;
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);

        $stmt = $conn->prepare("UPDATE payslips SET Fecha_Pago = COALESCE(?, Fecha_Pago), Salario_Base = COALESCE(?, Salario_Base), Neto = COALESCE(?, Neto), Id_Trabajador = COALESCE(?, Id_Trabajador), Data = COALESCE(?, Data) WHERE Id_Payslip = ?");
        $stmt->bind_param("sddisi", $fecha, $salario, $neto, $trab, $json, $id);
        if ($stmt->execute()) {
            echo json_encode(['message'=>'Updated']);
        } else {
            http_response_code(500);
            echo json_encode(['error'=>'Update failed']);
        }
        $stmt->close();
        exit;
    }

    if ($method === 'DELETE') {
        if (!isset($_GET['id'])) { http_response_code(400); echo json_encode(['error'=>'Missing id']); exit; }
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("DELETE FROM payslips WHERE Id_Payslip = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo json_encode(['message'=>'Deleted']);
        } else {
            http_response_code(500);
            echo json_encode(['error'=>'Delete failed']);
        }
        $stmt->close();
        exit;
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error'=>'Server error: ' . $e->getMessage()]);
}

?>