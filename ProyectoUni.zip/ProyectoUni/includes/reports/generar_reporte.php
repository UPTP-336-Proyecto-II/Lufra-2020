<?php
// --- CONFIGURACIÓN DEL REPORTE ---
date_default_timezone_set('America/Caracas'); 
$fecha_emision = date('d/m/Y h:i A'); 
$total_registros = 3; 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Usuarios - LUFRA200</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #333; margin: 30px; background-color: #fdfdfd; }
        
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #0070c0; padding-bottom: 15px; margin-bottom: 25px; }
        .logo-area h1 { margin: 0; color: #2c3e50; font-size: 2.2rem; letter-spacing: -1px; }
        .logo-area p { margin: 0; color: #7f8c8d; font-size: 0.9rem; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
        .card { background: white; border: 1px solid #e1e4e8; border-radius: 10px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .card h4 { margin: 0 0 10px 0; color: #34495e; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 1px; }
        
        .card-dark { background: #2c3e50; color: white; border: none; }
        .card-dark h4 { color: #bdc3c7; }
        .card-value-white { font-size: 2.5rem; font-weight: bold; color: #ffffff !important; margin-top: 5px; }

        .role-bar-container { background: #eee; height: 10px; border-radius: 5px; margin-top: 15px; overflow: hidden; display: flex; }
        .role-bar-admin { background: #0070c0; width: 33%; } 
        .role-bar-worker { background: #27ae60; width: 67%; } 

        table { width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        th { background: #2c3e50; color: white; padding: 15px; text-align: left; font-size: 0.8rem; text-transform: uppercase; }
        td { padding: 12px 15px; border-bottom: 1px solid #f1f1f1; font-size: 0.85rem; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: bold; }
        .permiso-tag { background: #f0f0f0; color: #444; border: 1px solid #ccc; margin-right: 3px; }
        .status-active { color: #27ae60; font-weight: bold; }
        .status-active::before { content: '● '; }

        .footer { margin-top: 50px; padding-top: 20px; border-top: 1px solid #eee; display: flex; justify-content: space-between; color: #95a5a6; font-size: 0.75rem; }
        
        /* Estilos para botones */
        .btn { padding: 12px 25px; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 1rem; border: none; margin: 0 5px; transition: opacity 0.3s; }
        .btn-print { background: #0070c0; color: white; }
        .btn-back { background: #7f8c8d; color: white; text-decoration: none; display: inline-block; }
        .btn:hover { opacity: 0.8; }

        @media print { 
            .no-print { display: none; } 
            body { margin: 0; } 
            .card-dark { background-color: #2c3e50 !important; -webkit-print-color-adjust: exact; } 
        }
    </style>
</head>
<body>

<div class="header">
    <div class="logo-area">
        <h1>LUFRA2020</h1>
        <p>RIF: J-50032437-5 | Reporte de Usuarios</p> 
    </div>
    <div style="text-align: right;">
        <p style="margin: 0; font-weight: bold; color: #2c3e50;">EMITIDO EL</p>
        <p style="margin: 0; font-size: 1.1rem;"><?php echo $fecha_emision; ?></p>
    </div>
</div>

<div class="stats-grid">
    <div class="card">
        <h4>Distribución de Personal</h4>
        <p style="margin: 2px 0;">Admins: <strong>1</strong> | Trabajadores: <strong>2</strong></p>
        <div class="role-bar-container">
            <div class="role-bar-admin" title="Admins"></div>
            <div class="role-bar-worker" title="Trabajadores"></div>
        </div>
        <p style="font-size: 0.65rem; color: #999; margin-top: 5px;">Azul: Admins | Verde: Trabajadores</p>
    </div>
    
    <div class="card">
        <h4>Estado de Seguridad</h4>
        <p style="margin: 2px 0;">Cuentas Activas: <strong class="status-active">3</strong></p>
        <p style="margin: 2px 0;">Estado Global: <strong style="color: #27ae60;">Protegido</strong></p>
    </div>
    
    <div class="card card-dark">
        <h4>Total Usuarios Registrados</h4>
        <div class="card-value-white"><?php echo $total_registros; ?></div> 
    </div>
</div>

<table>
    <thead>
        <tr>
            <th>Usuario</th>
            <th>Rol</th>
            <th>Estado</th>
            <th>Permisos de Acceso</th>
            <th>Última Conexión</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>superadmin</strong></td>
            <td><span class="badge" style="background:#0070c0; color:white;">SUPERADMIN</span></td>
            <td><span class="status-active">Activo</span></td>
            <td>
                <span class="badge permiso-tag">Total</span>
                <span class="badge permiso-tag">Nómina</span>
                <span class="badge permiso-tag">Auditoría</span>
            </td>
            <td>12/01/2026 09:15 AM</td>
        </tr>
        <tr>
            <td><strong>Kelvis_1</strong></td>
            <td><span class="badge" style="background:#3498db; color:white;">ADMIN</span></td>
            <td><span class="status-active">Activo</span></td>
            <td>
                <span class="badge permiso-tag">Lectura</span>
                <span class="badge permiso-tag">Escritura</span>
                <span class="badge permiso-tag">Nómina</span>
            </td>
            <td>12/01/2026 12:03 PM</td>
        </tr>
        <tr>
            <td><strong>Kelvis_2</strong></td>
            <td><span class="badge" style="background:#27ae60; color:white;">TRABAJADOR</span></td>
            <td><span class="status-active">Activo</span></td>
            <td>
                <span class="badge permiso-tag">Lectura Perfil</span>
            </td>
            <td>11/01/2026 09:05 PM</td>
        </tr>
    </tbody>
</table>

<div class="footer">
    <div>
        <p>Reporte informativo generado para fines de control administrativo interno.</p>
        <p>© 2026 LUFRA200 - Gestión de Nómina Integral.</p>
    </div>
    <div style="text-align: right;">
        <p>Código REP: LFR-<?php echo strtoupper(substr(md5(time()), 0, 8)); ?></p>
        <p>Documento digital sin necesidad de firmas ni sellos.</p>
    </div>
</div>

<div class="no-print" style="margin-top: 30px; text-align: center;">
    <button onclick="window.history.back();" class="btn btn-back">
        ⬅️ Volver a la Ventana Anterior
    </button>
    
    <button onclick="window.print()" class="btn btn-print">
        🖨️ Imprimir Reporte de Usuarios
    </button>
</div>

</body>
</html>