<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

require_once '../config/config.php';

try{
    $conn = getDBConnection();
    $conn->query("CREATE TABLE IF NOT EXISTS novedades (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        emp VARCHAR(255) NOT NULL,
        tipo VARCHAR(255) NOT NULL,
        monto DECIMAL(12,2) DEFAULT 0,
        fecha DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    if($_SERVER['REQUEST_METHOD'] === 'GET'){
        $res = $conn->query("SELECT * FROM novedades ORDER BY fecha DESC");
        $out = [];
        while($r = $res->fetch_assoc()) $out[] = $r;
        echo json_encode($out);
        exit;
    }

    // POST -> create
    $body = json_decode(file_get_contents('php://input'), true);
    if(!$body || !isset($body['emp']) || !isset($body['tipo'])){ http_response_code(400); echo json_encode(['error'=>'Missing fields']); exit; }
    $emp = $body['emp']; $tipo = $body['tipo']; $monto = isset($body['amt']) ? floatval($body['amt']) : 0;
    $stmt = $conn->prepare("INSERT INTO novedades (emp,tipo,monto) VALUES (?,?,?)");
    $stmt->bind_param('ssd', $emp, $tipo, $monto);
    if($stmt->execute()){ echo json_encode(['message'=>'Created','id'=>$stmt->insert_id]); } else { http_response_code(500); echo json_encode(['error'=>'Insert failed']); }
    $stmt->close();
    exit;

}catch(Exception $e){ http_response_code(500); echo json_encode(['error'=>$e->getMessage()]); }
?>